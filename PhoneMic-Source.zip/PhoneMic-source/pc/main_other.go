//go:build !windows

// Headless build used only for testing on Linux: a simulated sound card pulls
// audio from the jitter buffer in real time and saves it as raw float32.
package main

import (
	"encoding/binary"
	"flag"
	"fmt"
	"math"
	"os"
	"time"
)

func main() {
	port := flag.Int("port", 8443, "port")
	rate := flag.Int("rate", 48000, "simulated device rate")
	out := flag.String("out", "out.f32", "captured audio file")
	secs := flag.Float64("secs", 15, "capture seconds")
	flag.Parse()

	eng := NewEngine(30)
	eng.Configure(*rate, "Simulated CABLE Input", true)
	srv := NewServer(eng, *port)
	ips := LocalIPs()
	fmt.Println("IPs:", ips)
	go func() { fmt.Println("server:", srv.Run(ips)); os.Exit(1) }()

	f, _ := os.Create(*out)
	block := make([]float32, *rate/100)
	raw := make([]byte, 4*len(block))
	start := time.Now()
	for n := 1; time.Since(start).Seconds() < *secs; n++ {
		eng.Buffer().Read(block)
		for i, v := range block {
			binary.LittleEndian.PutUint32(raw[4*i:], math.Float32bits(v))
		}
		f.Write(raw)
		if n%100 == 0 {
			u, d := eng.Buffer().Stats()
			fmt.Printf("peer=%q bytes=%d buffer=%.1fms underruns=%d drops=%d\n", srv.Peer(), srv.BytesIn(), eng.Buffer().LevelMs(), u, d)
		}
		time.Sleep(time.Until(start.Add(time.Duration(n) * 10 * time.Millisecond)))
	}
	f.Close()
}
