//go:build windows

// Anti-aliased drawing through GDI+ (part of every Windows since XP).
// Used for icons, rounded cards/buttons and the level meter so edges are smooth
// at any DPI. If GDI+ can't start, the plain GDI code paths are used instead.
package main

import (
	"math"
	"syscall"
	"unsafe"
)

var (
	gdiplus                    = syscall.NewLazyDLL("gdiplus.dll")
	procGdiplusStartup         = gdiplus.NewProc("GdiplusStartup")
	procGdipCreateFromHDC      = gdiplus.NewProc("GdipCreateFromHDC")
	procGdipDeleteGraphics     = gdiplus.NewProc("GdipDeleteGraphics")
	procGdipSetSmoothingMode   = gdiplus.NewProc("GdipSetSmoothingMode")
	procGdipSetPixelOffsetMode = gdiplus.NewProc("GdipSetPixelOffsetMode")
	procGdipCreatePen1         = gdiplus.NewProc("GdipCreatePen1")
	procGdipDeletePen          = gdiplus.NewProc("GdipDeletePen")
	procGdipSetPenStartCap     = gdiplus.NewProc("GdipSetPenStartCap")
	procGdipSetPenEndCap       = gdiplus.NewProc("GdipSetPenEndCap")
	procGdipSetPenLineJoin     = gdiplus.NewProc("GdipSetPenLineJoin")
	procGdipCreateSolidFill    = gdiplus.NewProc("GdipCreateSolidFill")
	procGdipCreateLineBrush    = gdiplus.NewProc("GdipCreateLineBrush")
	procGdipDeleteBrush        = gdiplus.NewProc("GdipDeleteBrush")
	procGdipDrawLines          = gdiplus.NewProc("GdipDrawLines")
	procGdipFillEllipse        = gdiplus.NewProc("GdipFillEllipse")
	procGdipDrawEllipse        = gdiplus.NewProc("GdipDrawEllipse")
	procGdipCreatePath         = gdiplus.NewProc("GdipCreatePath")
	procGdipDeletePath         = gdiplus.NewProc("GdipDeletePath")
	procGdipAddPathArc         = gdiplus.NewProc("GdipAddPathArc")
	procGdipAddPathLine        = gdiplus.NewProc("GdipAddPathLine")
	procGdipClosePathFigure    = gdiplus.NewProc("GdipClosePathFigure")
	procGdipFillPath           = gdiplus.NewProc("GdipFillPath")
	procGdipDrawPath           = gdiplus.NewProc("GdipDrawPath")
	gdipReady                  bool
)

type pointF struct{ X, Y float32 }

func f32(v float64) uintptr { return uintptr(math.Float32bits(float32(v))) }

// argb turns a GDI COLORREF (0x00BBGGRR) into a GDI+ ARGB with the given alpha.
func argb(c uintptr, alpha uint8) uintptr {
	r, g, b := c&0xFF, (c>>8)&0xFF, (c>>16)&0xFF
	return uintptr(alpha)<<24 | r<<16 | g<<8 | b
}

func startGdiplus() {
	if procGdiplusStartup.Find() != nil {
		return
	}
	in := struct {
		version                  uint32
		callback                 uintptr
		suppressBackgroundThread int32
		suppressExternalCodecs   int32
	}{version: 1}
	var token uintptr
	r, _, _ := procGdiplusStartup.Call(uintptr(unsafe.Pointer(&token)), uintptr(unsafe.Pointer(&in)), 0)
	gdipReady = r == 0
}

// gp wraps one GDI+ drawing session on a device context.
type gp struct {
	g   uintptr
	dpi float64
}

func (a *App) gpBegin(hdc uintptr) *gp {
	var g uintptr
	procGdipCreateFromHDC.Call(hdc, uintptr(unsafe.Pointer(&g)))
	procGdipSetSmoothingMode.Call(g, 4)   // SmoothingModeAntiAlias
	procGdipSetPixelOffsetMode.Call(g, 4) // PixelOffsetModeHalf: coordinates are pixel edges, like GDI rects
	return &gp{g: g, dpi: float64(a.dpi) / 96}
}

func (c *gp) end() { procGdipDeleteGraphics.Call(c.g) }

func (c *gp) s(v float64) float64 { return v * c.dpi }

func (c *gp) pen(color uintptr, alpha uint8, width float64) uintptr {
	var pen uintptr
	procGdipCreatePen1.Call(argb(color, alpha), f32(math.Max(1, c.s(width))), 2, uintptr(unsafe.Pointer(&pen))) // UnitPixel
	procGdipSetPenStartCap.Call(pen, 2)                                                                         // LineCapRound
	procGdipSetPenEndCap.Call(pen, 2)
	procGdipSetPenLineJoin.Call(pen, 2) // LineJoinRound
	return pen
}

func (c *gp) brush(color uintptr, alpha uint8) uintptr {
	var br uintptr
	procGdipCreateSolidFill.Call(argb(color, alpha), uintptr(unsafe.Pointer(&br)))
	return br
}

// lines strokes a polyline given as x,y pairs at 96 DPI.
func (c *gp) lines(color uintptr, width float64, pts ...float64) {
	ps := make([]pointF, 0, len(pts)/2)
	for i := 0; i+1 < len(pts); i += 2 {
		ps = append(ps, pointF{float32(c.s(pts[i])), float32(c.s(pts[i+1]))})
	}
	pen := c.pen(color, 255, width)
	procGdipDrawLines.Call(c.g, pen, uintptr(unsafe.Pointer(&ps[0])), uintptr(len(ps)))
	procGdipDeletePen.Call(pen)
}

func (c *gp) fillCircle(color uintptr, alpha uint8, cx, cy, r float64) {
	br := c.brush(color, alpha)
	procGdipFillEllipse.Call(c.g, br, f32(c.s(cx-r)), f32(c.s(cy-r)), f32(c.s(2*r)), f32(c.s(2*r)))
	procGdipDeleteBrush.Call(br)
}

func (c *gp) strokeCircle(color uintptr, width, cx, cy, r float64) {
	pen := c.pen(color, 255, width)
	procGdipDrawEllipse.Call(c.g, pen, f32(c.s(cx-r)), f32(c.s(cy-r)), f32(c.s(2*r)), f32(c.s(2*r)))
	procGdipDeletePen.Call(pen)
}

// roundPath builds a rounded rectangle in device pixels; rad is the corner radius.
func roundPath(x, y, w, h, rad float64) uintptr {
	var path uintptr
	procGdipCreatePath.Call(0, uintptr(unsafe.Pointer(&path)))
	rad = math.Min(rad, math.Min(w, h)/2)
	if rad <= 0.5 {
		procGdipAddPathLine.Call(path, f32(x), f32(y), f32(x+w), f32(y))
		procGdipAddPathLine.Call(path, f32(x+w), f32(y), f32(x+w), f32(y+h))
		procGdipAddPathLine.Call(path, f32(x+w), f32(y+h), f32(x), f32(y+h))
	} else {
		d := rad * 2
		procGdipAddPathArc.Call(path, f32(x), f32(y), f32(d), f32(d), f32(180), f32(90))
		procGdipAddPathArc.Call(path, f32(x+w-d), f32(y), f32(d), f32(d), f32(270), f32(90))
		procGdipAddPathArc.Call(path, f32(x+w-d), f32(y+h-d), f32(d), f32(d), f32(0), f32(90))
		procGdipAddPathArc.Call(path, f32(x), f32(y+h-d), f32(d), f32(d), f32(90), f32(90))
	}
	procGdipClosePathFigure.Call(path)
	return path
}

// roundRect fills (and optionally outlines with a crisp 1px line) a rounded rectangle at 96 DPI.
func (c *gp) roundRect(fill uintptr, fillAlpha uint8, border uintptr, x, y, w, h, rad float64) {
	X, Y, W, H, R := c.s(x), c.s(y), c.s(w), c.s(h), c.s(rad)
	if fillAlpha > 0 {
		path := roundPath(X, Y, W, H, R)
		br := c.brush(fill, fillAlpha)
		procGdipFillPath.Call(c.g, br, path)
		procGdipDeleteBrush.Call(br)
		procGdipDeletePath.Call(path)
	}
	if border != ^uintptr(0) {
		lw := math.Max(1, math.Round(c.dpi))
		path := roundPath(X+lw/2, Y+lw/2, W-lw, H-lw, R-lw/2)
		var pen uintptr
		procGdipCreatePen1.Call(argb(border, 255), f32(lw), 2, uintptr(unsafe.Pointer(&pen)))
		procGdipDrawPath.Call(c.g, pen, path)
		procGdipDeletePen.Call(pen)
		procGdipDeletePath.Call(path)
	}
}

// strokeRound outlines a rounded rectangle (96 DPI) with a round-joined pen.
func (c *gp) strokeRound(color uintptr, width, x, y, w, h, rad float64) {
	path := roundPath(c.s(x), c.s(y), c.s(w), c.s(h), c.s(rad))
	pen := c.pen(color, 255, width)
	procGdipDrawPath.Call(c.g, pen, path)
	procGdipDeletePen.Call(pen)
	procGdipDeletePath.Call(path)
}

// gradientRound fills a rounded rectangle with a left-to-right gradient.
func (c *gp) gradientRound(from, to uintptr, x, y, w, h, rad float64) {
	X, Y, W, H := c.s(x), c.s(y), c.s(w), c.s(h)
	if W < 1 {
		return
	}
	p1, p2 := pointF{float32(X - 1), 0}, pointF{float32(X + W + 1), 0}
	var br uintptr
	procGdipCreateLineBrush.Call(uintptr(unsafe.Pointer(&p1)), uintptr(unsafe.Pointer(&p2)),
		argb(from, 255), argb(to, 255), 0, uintptr(unsafe.Pointer(&br)))
	path := roundPath(X, Y, W, H, c.s(rad))
	procGdipFillPath.Call(c.g, br, path)
	procGdipDeletePath.Call(path)
	procGdipDeleteBrush.Call(br)
}

// crescent fills a moon shape: circle (cx,cy,R) minus circle (ix,iy,r).
func (c *gp) crescent(color uintptr, cx, cy, R, ix, iy, r float64) {
	d := math.Hypot(ix-cx, iy-cy)
	phi := math.Atan2(iy-cy, ix-cx)
	alpha := math.Acos((d*d + R*R - r*r) / (2 * d * R))
	beta := math.Acos((d*d + r*r - R*R) / (2 * d * r))
	psi := math.Atan2(cy-iy, cx-ix)
	deg := 180 / math.Pi
	var path uintptr
	procGdipCreatePath.Call(0, uintptr(unsafe.Pointer(&path)))
	// Outer arc: the visible rim, away from the cut-out circle.
	procGdipAddPathArc.Call(path, f32(c.s(cx-R)), f32(c.s(cy-R)), f32(c.s(2*R)), f32(c.s(2*R)),
		f32((phi+alpha)*deg), f32(360-2*alpha*deg))
	// Inner arc back, bulging toward the outer centre. It starts where the outer arc ended
	// (outer angle phi-alpha), which on the inner circle is psi+beta.
	procGdipAddPathArc.Call(path, f32(c.s(ix-r)), f32(c.s(iy-r)), f32(c.s(2*r)), f32(c.s(2*r)),
		f32((psi+beta)*deg), f32(-2*beta*deg))
	procGdipClosePathFigure.Call(path)
	br := c.brush(color, 255)
	procGdipFillPath.Call(c.g, br, path)
	procGdipDeleteBrush.Call(br)
	procGdipDeletePath.Call(path)
}
