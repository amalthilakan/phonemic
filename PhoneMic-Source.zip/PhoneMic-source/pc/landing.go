package main

// Plain-HTTP pages the QR code points to (no certificate warning):
//   /     tries to open the PhoneMic Android app with this PC's details
//         (the app asks the user to confirm before connecting);
//   /get  shown when the app isn't installed: asks whether to download it.

import (
	"fmt"
	"html"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const pageStyle = `<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0f1115">
<style>
:root{--bg:#0f1115;--panel:#171a21;--line:#262b35;--text:#e8eaf0;--dim:#8b93a5;--accent:#3ddc97;--ink:#062a1b}
*{box-sizing:border-box}html,body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:420px;margin:0 auto;padding:28px 16px 40px;display:flex;flex-direction:column;gap:16px;min-height:100dvh}
.logo{width:64px;height:64px;border-radius:18px;background:#12a16b;display:grid;place-items:center;margin:8px auto 0}
.logo svg{width:36px;height:36px}
h1{font-size:22px;margin:0;text-align:center}
p{margin:0;color:var(--dim);text-align:center}
.pc{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px 16px;text-align:center}
.pc b{display:block;font-size:17px}.pc span{color:var(--dim);font-size:13px}
a.btn{display:block;text-align:center;text-decoration:none;font-weight:700;font-size:16px;padding:14px;border-radius:12px;background:var(--accent);color:var(--ink)}
a.btn.alt{background:var(--panel);color:var(--text);border:1px solid var(--line);font-weight:600}
ol{margin:0;padding-left:20px;color:var(--dim)}li{margin:4px 0}
small{color:var(--dim);text-align:center;font-size:12.5px}
.col{display:flex;flex-direction:column;gap:12px}.hide{display:none!important}
</style>`

const logoSVG = `<div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3" fill="#fff"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8.5 21h7"/></svg></div>`

func (s *Server) landingInfo(r *http.Request) (name, host string) {
	host = r.Host
	if h, _, err := net.SplitHostPort(r.Host); err == nil {
		host = h
	}
	return hostName(), host
}

func (s *Server) handleLanding(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	name, host := s.landingInfo(r)
	intent := s.intentURL(r)
	browserURL := fmt.Sprintf("https://%s:%d/", host, s.port)

	// Android: answer the QR scan with a redirect straight into the app. Chrome opens
	// PhoneMic directly when it's installed, or goes to /get (download) when it isn't.
	// "?page" shows the manual page instead (used by the button on /get).
	if isAndroid(r) && !r.URL.Query().Has("page") {
		w.Header().Set("Cache-Control", "no-store")
		http.Redirect(w, r, intent, http.StatusFound)
		return
	}

	page := `<!doctype html><html lang="en"><head>` + pageStyle + `<title>PhoneMic</title></head><body><main>
` + logoSVG + `
<h1>Connect to this PC</h1>
<div class="pc"><b>{{NAME}}</b><span>{{HOST}}</span></div>
<div id="android" class="col hide">
  <p>Tap below to open the PhoneMic app.</p>
  <a class="btn" id="open" href="{{INTENT}}">Open in PhoneMic app</a>
  <a class="btn alt" href="/get">I don't have the app yet</a>
  <small>The app will ask you to confirm before it connects.</small>
</div>
<div id="other" class="col hide">
  <p>The PhoneMic app is for Android. On this device you can use the microphone straight from the browser.</p>
  <a class="btn" href="{{BROWSER}}">Use the mic in this browser</a>
  <small>You'll see a certificate warning: tap <b>Show Details &rarr; visit this website</b> (iPhone) or <b>Advanced &rarr; Proceed</b>. It's your own PC.</small>
</div>
</main>
<script>
var android = /Android/i.test(navigator.userAgent);
document.getElementById(android ? 'android' : 'other').classList.remove('hide');
</script></body></html>`
	page = strings.NewReplacer(
		"{{NAME}}", html.EscapeString(name), "{{HOST}}", html.EscapeString(host),
		"{{INTENT}}", html.EscapeString(intent), "{{BROWSER}}", html.EscapeString(browserURL),
	).Replace(page)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Write([]byte(page))
}

func isAndroid(r *http.Request) bool {
	return strings.Contains(strings.ToLower(r.UserAgent()), "android")
}

// intentURL opens phonemic://connect?host=..&port=..&name=.. in the app, falling back to /get.
func (s *Server) intentURL(r *http.Request) string {
	name, host := s.landingInfo(r)
	q := url.Values{}
	q.Set("host", host)
	q.Set("port", fmt.Sprint(s.UDPPort()))
	q.Set("name", name)
	fallback := fmt.Sprintf("http://%s:%d/get", host, s.landingPort())
	return "intent://connect?" + q.Encode() + "#Intent;scheme=phonemic;package=app.phonemic.mic;S.browser_fallback_url=" +
		url.QueryEscape(fallback) + ";end"
}

func (s *Server) handleGet(w http.ResponseWriter, r *http.Request) {
	name, host := s.landingInfo(r)
	browserURL := fmt.Sprintf("https://%s:%d/", host, s.port)
	page := `<!doctype html><html lang="en"><head>` + pageStyle + `<title>Get PhoneMic</title></head><body><main>
` + logoSVG + `
<h1>Download the PhoneMic app?</h1>
<p>PhoneMic isn't installed on this phone yet. It turns your phone into a wireless microphone for <b style="color:var(--text)">{{NAME}}</b>.</p>
<a class="btn" href="/PhoneMic.apk" download="PhoneMic.apk">Download app ({{SIZE}})</a>
<ol>
  <li>Tap <b>Download</b>. If Chrome asks, choose <b>Download anyway</b>.</li>
  <li>Open the file and allow installing apps from Chrome when Android asks.</li>
  <li>Open PhoneMic - it finds {{NAME}} by itself. Or scan the QR code again.</li>
</ol>
<a class="btn alt" href="{{INTENT}}">I already have the app - open it</a>
<a class="btn alt" href="{{BROWSER}}">No thanks, use the browser instead</a>
<small>The app comes straight from your PC ({{HOST}}), not from the internet.</small>
</main></body></html>`
	page = strings.NewReplacer(
		"{{NAME}}", html.EscapeString(name), "{{HOST}}", html.EscapeString(host),
		"{{BROWSER}}", html.EscapeString(browserURL), "{{INTENT}}", html.EscapeString(s.intentURL(r)), "{{SIZE}}", fmt.Sprintf("%d KB", (len(apkFile)+512)/1024),
	).Replace(page)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Write([]byte(page))
}

func (s *Server) landingPort() int { return s.port - 1 }

// LandingURL is what the QR code encodes.
func (s *Server) LandingURL(ip string) string {
	return fmt.Sprintf("http://%s:%d/", ip, s.landingPort())
}

func (s *Server) runLanding() error {
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handleLanding)
	mux.HandleFunc("/get", s.handleGet)
	mux.HandleFunc("/PhoneMic.apk", s.handleAPK)
	srv := &http.Server{Addr: fmt.Sprintf(":%d", s.landingPort()), Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	ln, err := net.Listen("tcp", srv.Addr)
	if err != nil {
		return err
	}
	go srv.Serve(ln)
	return nil
}
