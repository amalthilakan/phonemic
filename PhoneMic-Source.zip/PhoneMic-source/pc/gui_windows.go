//go:build windows

// Native Win32 window for PhoneMic (no frameworks, no runtime to install).
// Every control is drawn by hand so the light and dark themes look consistent.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	qrcode "github.com/skip2/go-qrcode"
)

var (
	user32                = syscall.NewLazyDLL("user32.dll")
	procRegisterClassExW  = user32.NewProc("RegisterClassExW")
	procCreateWindowExW   = user32.NewProc("CreateWindowExW")
	procDefWindowProcW    = user32.NewProc("DefWindowProcW")
	procGetMessageW       = user32.NewProc("GetMessageW")
	procTranslateMessage  = user32.NewProc("TranslateMessage")
	procDispatchMessageW  = user32.NewProc("DispatchMessageW")
	procPostQuitMessage   = user32.NewProc("PostQuitMessage")
	procPostMessageW      = user32.NewProc("PostMessageW")
	procShowWindow        = user32.NewProc("ShowWindow")
	procUpdateWindow      = user32.NewProc("UpdateWindow")
	procBeginPaint        = user32.NewProc("BeginPaint")
	procEndPaint          = user32.NewProc("EndPaint")
	procGetClientRect     = user32.NewProc("GetClientRect")
	procInvalidateRect    = user32.NewProc("InvalidateRect")
	procFillRect          = user32.NewProc("FillRect")
	procDrawTextW         = user32.NewProc("DrawTextW")
	procSetTimer          = user32.NewProc("SetTimer")
	procKillTimer         = user32.NewProc("KillTimer")
	procLoadCursorW       = user32.NewProc("LoadCursorW")
	procSetCursor         = user32.NewProc("SetCursor")
	procLoadIconW         = user32.NewProc("LoadIconW")
	procAdjustWindowRect  = user32.NewProc("AdjustWindowRect")
	procGetSystemMetrics  = user32.NewProc("GetSystemMetrics")
	procGetDC             = user32.NewProc("GetDC")
	procReleaseDC         = user32.NewProc("ReleaseDC")
	procSetProcessDPIAwa  = user32.NewProc("SetProcessDPIAware")
	procCreatePopupMenu   = user32.NewProc("CreatePopupMenu")
	procAppendMenuW       = user32.NewProc("AppendMenuW")
	procTrackPopupMenu    = user32.NewProc("TrackPopupMenu")
	procDestroyMenu       = user32.NewProc("DestroyMenu")
	procClientToScreen    = user32.NewProc("ClientToScreen")
	procTrackMouseEvent   = user32.NewProc("TrackMouseEvent")
	procSetWindowPos      = user32.NewProc("SetWindowPos")
	procSetForegroundWind = user32.NewProc("SetForegroundWindow")
	procSetWindowLongPtrW = user32.NewProc("SetWindowLongPtrW")
	procGetWindowRect     = user32.NewProc("GetWindowRect")
	procScreenToClient    = user32.NewProc("ScreenToClient")

	gdi32                      = syscall.NewLazyDLL("gdi32.dll")
	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procGetDeviceCaps          = gdi32.NewProc("GetDeviceCaps")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")
	procEllipse                = gdi32.NewProc("Ellipse")

	shell32           = syscall.NewLazyDLL("shell32.dll")
	procShellExecuteW = shell32.NewProc("ShellExecuteW")

	advapi32         = syscall.NewLazyDLL("advapi32.dll")
	procRegGetValueW = advapi32.NewProc("RegGetValueW")

	dwmapi                    = syscall.NewLazyDLL("dwmapi.dll")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")

	procGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
	procLoadLibraryW     = kernel32.NewProc("LoadLibraryW")
	procGetProcAddress   = kernel32.NewProc("GetProcAddress")
)

const (
	wsOverlapped   = 0x00000000
	wsCaption      = 0x00C00000
	wsSysMenu      = 0x00080000
	wsMinimizeBox  = 0x00020000
	wsClipChildren = 0x02000000

	wmDestroy       = 0x0002
	wmPaint         = 0x000F
	wmEraseBkgnd    = 0x0014
	wmSettingChange = 0x001A
	wmSetCursor     = 0x0020
	wmTimer         = 0x0113
	wmMouseMove     = 0x0200
	wmLButtonDown   = 0x0201
	wmLButtonUp     = 0x0202
	wmMouseLeave    = 0x02A3
	wmApp           = 0x8000
	wmClose         = 0x0010
	wmNcHitTest     = 0x0084
	wmNcLButtonDbl  = 0x00A3
	wmExitSizeMove  = 0x0232

	wsPopup = 0x80000000

	dtCenter     = 0x01
	dtVCenter    = 0x04
	dtWordBreak  = 0x10
	dtSingleLine = 0x20
	dtNoPrefix   = 0x800
	dtEndEllipsi = 0x8000

	idAddress = 101
	idDevice  = 102
	idBuffer  = 103
	idGetVB   = 104
	idCopy    = 105
	idTheme   = 106
	idSafe    = 107
	idWidget  = 108
	idExpand  = 109
	idClose   = 110
	idReveal  = 111
)

type rect struct{ L, T, R, B int32 }

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type msgT struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      [2]int32
	private uint32
}

type paintStruct struct {
	hdc         uintptr
	fErase      int32
	rcPaint     rect
	fRestore    int32
	fIncUpdate  int32
	rgbReserved [32]byte
}

type trackMouseEventT struct {
	cbSize      uint32
	dwFlags     uint32
	hwndTrack   uintptr
	dwHoverTime uint32
}

func rgb(r, g, b uint8) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

// ---------------------------------------------------------------- themes

type palette struct {
	bg, card, cardLine, text, dim, line        uintptr
	accent, accentText, accentL                uintptr
	warn, warnL, bad, badL, grayL              uintptr
	field, fieldHover, fieldLine               uintptr
	button, buttonHover, primary, primaryHover uintptr
	primaryText                                uintptr
}

var lightPal = palette{
	bg: rgb(0xF4, 0xF5, 0xF8), card: rgb(0xFF, 0xFF, 0xFF), cardLine: rgb(0xE6, 0xE8, 0xEC),
	text: rgb(0x1B, 0x1F, 0x27), dim: rgb(0x6B, 0x72, 0x80), line: rgb(0xE3, 0xE6, 0xEB),
	accent: rgb(0x12, 0xA1, 0x6B), accentText: rgb(0x0E, 0x8A, 0x5B), accentL: rgb(0xDF, 0xF6, 0xEC),
	warn: rgb(0xB4, 0x5A, 0x00), warnL: rgb(0xFF, 0xF1, 0xDC), bad: rgb(0xC6, 0x28, 0x28), badL: rgb(0xFD, 0xE7, 0xE7),
	grayL: rgb(0xEA, 0xEC, 0xF0),
	field: rgb(0xFF, 0xFF, 0xFF), fieldHover: rgb(0xF3, 0xF5, 0xF8), fieldLine: rgb(0xD5, 0xD9, 0xE0),
	button: rgb(0xFF, 0xFF, 0xFF), buttonHover: rgb(0xF0, 0xF2, 0xF5),
	primary: rgb(0x12, 0xA1, 0x6B), primaryHover: rgb(0x0F, 0x8F, 0x5F), primaryText: rgb(0xFF, 0xFF, 0xFF),
}

var darkPal = palette{
	bg: rgb(0x11, 0x13, 0x18), card: rgb(0x1A, 0x1D, 0x24), cardLine: rgb(0x26, 0x2A, 0x33),
	text: rgb(0xE8, 0xEA, 0xF0), dim: rgb(0x8B, 0x93, 0xA5), line: rgb(0x2A, 0x2F, 0x3A),
	accent: rgb(0x3D, 0xDC, 0x97), accentText: rgb(0x3D, 0xDC, 0x97), accentL: rgb(0x13, 0x3A, 0x2B),
	warn: rgb(0xFF, 0xB5, 0x47), warnL: rgb(0x36, 0x29, 0x14), bad: rgb(0xFF, 0x6B, 0x6B), badL: rgb(0x3A, 0x18, 0x18),
	grayL: rgb(0x23, 0x27, 0x30),
	field: rgb(0x20, 0x24, 0x2C), fieldHover: rgb(0x27, 0x2C, 0x36), fieldLine: rgb(0x33, 0x39, 0x45),
	button: rgb(0x23, 0x27, 0x30), buttonHover: rgb(0x2C, 0x31, 0x3C),
	primary: rgb(0x3D, 0xDC, 0x97), primaryHover: rgb(0x5A, 0xE6, 0xA9), primaryText: rgb(0x06, 0x2A, 0x1B),
}

var themeChoices = []struct{ key, label string }{
	{"auto", "Auto (match Windows)"},
	{"light", "Light"},
	{"dark", "Dark"},
}

// windowsUsesDark reads the "Choose your app mode" setting.
func windowsUsesDark() bool {
	var v uint32
	size := uint32(4)
	r, _, _ := procRegGetValueW.Call(0x80000001, // HKEY_CURRENT_USER
		uintptr(unsafe.Pointer(u16(`Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`))),
		uintptr(unsafe.Pointer(u16("AppsUseLightTheme"))), 0x10, // RRF_RT_REG_DWORD
		0, uintptr(unsafe.Pointer(&v)), uintptr(unsafe.Pointer(&size)))
	return r == 0 && v == 0
}

// setMenuDarkMode makes popup menus follow our theme (undocumented uxtheme
// ordinals used by Explorer/Notepad; silently skipped where unavailable).
func setMenuDarkMode(dark bool) {
	h, _, _ := procLoadLibraryW.Call(uintptr(unsafe.Pointer(u16("uxtheme.dll"))))
	if h == 0 {
		return
	}
	setPreferredAppMode, _, _ := procGetProcAddress.Call(h, 135)
	flushMenuThemes, _, _ := procGetProcAddress.Call(h, 136)
	if setPreferredAppMode == 0 {
		return
	}
	mode := uintptr(3) // ForceLight
	if dark {
		mode = 2 // ForceDark
	}
	syscall.SyscallN(setPreferredAppMode, mode)
	if flushMenuThemes != 0 {
		syscall.SyscallN(flushMenuThemes)
	}
}

func (a *App) applyTheme() {
	a.dark = a.cfg.Theme == "dark" || (a.cfg.Theme != "light" && windowsUsesDark())
	if a.dark {
		a.pal = &darkPal
	} else {
		a.pal = &lightPal
	}
	setMenuDarkMode(a.dark)
	if a.hwnd != 0 && procDwmSetWindowAttribute.Find() == nil {
		v := int32(0)
		if a.dark {
			v = 1
		}
		r, _, _ := procDwmSetWindowAttribute.Call(a.hwnd, 20, uintptr(unsafe.Pointer(&v)), 4) // DWMWA_USE_IMMERSIVE_DARK_MODE
		if r != 0 {
			procDwmSetWindowAttribute.Call(a.hwnd, 19, uintptr(unsafe.Pointer(&v)), 4) // older Windows 10 builds
		}
		procSetWindowPos.Call(a.hwnd, 0, 0, 0, 0, 0, 0x0001|0x0002|0x0004|0x0020) // redraw the title bar
	}
	if a.hwnd != 0 {
		procInvalidateRect.Call(a.hwnd, 0, 0)
	}
}

// ---------------------------------------------------------------- settings

const winW, winH = 460, 660 // client size at 96 DPI

type settings struct {
	DeviceID string  `json:"device_id"`
	BufferMs float64 `json:"buffer_ms"`
	IP       string  `json:"ip"`
	Theme    string  `json:"theme"`
	SafeMode bool    `json:"safe_mode"`
	Widget   bool    `json:"widget"`
	WidgetOK bool    `json:"widget_pos_set"`
	WidgetX  int32   `json:"widget_x"`
	WidgetY  int32   `json:"widget_y"`
}

func settingsPath() string { return filepath.Join(configDir(), "settings.json") }

func loadSettings() settings {
	s := settings{BufferMs: 30, Theme: "auto"}
	if b, err := os.ReadFile(settingsPath()); err == nil {
		json.Unmarshal(b, &s)
	}
	if s.BufferMs <= 0 {
		s.BufferMs = 30
	}
	if s.Theme == "" {
		s.Theme = "auto"
	}
	return s
}

func (s settings) save() {
	b, _ := json.MarshalIndent(s, "", "  ")
	os.WriteFile(settingsPath(), b, 0o644)
}

// ---------------------------------------------------------------- app state

type hitRect struct{ id, x, y, w, h int }

type App struct {
	hwnd, hinst                  uintptr
	dpi                          int
	fTitle, fBody, fBold, fSmall uintptr
	fURL                         uintptr
	eng                          *Engine
	srv                          *Server
	port                         int
	ips                          []string
	ip                           string
	host                         string
	qr                           [][]bool
	devices                      []AudioDevice
	deviceIdx                    int
	bufferIdx                    int
	renderer                     *Renderer
	cfg                          settings
	errMu                        sync.Mutex
	serverErr                    string
	meter                        float64
	kbps                         float64
	lastBytes                    int64
	lastT                        time.Time
	copiedUntil                  time.Time
	dark                         bool
	pal                          *palette
	hits                         []hitRect
	hover, pressed               int
	tracking                     bool
	cursorArrow, cursorHand      uintptr
	widget                       bool      // small always-on-top icon bar
	mainRect                     rect      // full window position, restored when leaving widget mode
	revealUntil                  time.Time // safe mode: QR code shown until then
	dwmRound                     bool      // Windows 11 rounds the widget and draws its border
}

var app *App

var bufferChoices = []struct {
	ms    float64
	label string
}{
	{15, "15 ms  -  lowest delay"},
	{20, "20 ms"},
	{30, "30 ms  -  recommended"},
	{50, "50 ms"},
	{80, "80 ms  -  weak Wi-Fi"},
}

func (a *App) S(v int) int32 { return int32(v * a.dpi / 96) }

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func (a *App) font(pt int, weight int) uintptr {
	h, _, _ := procCreateFontW.Call(uintptr(-int32(pt*a.dpi/72)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0,
		uintptr(unsafe.Pointer(u16("Segoe UI"))))
	return h
}

func main() {
	runtime.LockOSThread()
	port := flag.Int("port", 8443, "network port")
	flag.Parse()

	procSetProcessDPIAwa.Call()
	procCoInitializeEx.Call(0, 2) // STA for the UI thread
	startGdiplus()

	a := &App{port: *port, cfg: loadSettings(), lastT: time.Now()}
	app = a
	a.applyTheme()
	a.hinst, _, _ = procGetModuleHandleW.Call(0)
	hdc, _, _ := procGetDC.Call(0)
	d, _, _ := procGetDeviceCaps.Call(hdc, 90) // LOGPIXELSY
	procReleaseDC.Call(0, hdc)
	a.dpi = int(d)
	if a.dpi <= 0 {
		a.dpi = 96
	}
	a.fTitle = a.font(17, 700)
	a.fURL = a.font(13, 600)
	a.fBody = a.font(10, 400)
	a.fBold = a.font(10, 600)
	a.fSmall = a.font(9, 400)
	a.cursorArrow, _, _ = procLoadCursorW.Call(0, 32512)
	a.cursorHand, _, _ = procLoadCursorW.Call(0, 32649)

	a.eng = NewEngine(a.cfg.BufferMs)
	a.ips = LocalIPs()
	a.host = hostName()
	a.ip = a.ips[0]
	for _, ip := range a.ips {
		if ip == a.cfg.IP {
			a.ip = ip
		}
	}
	a.srv = NewServer(a.eng, a.port)
	a.makeQR()

	a.bufferIdx = 2
	for i, c := range bufferChoices {
		if c.ms == a.cfg.BufferMs {
			a.bufferIdx = i
		}
	}
	a.eng.SetTarget(bufferChoices[a.bufferIdx].ms)

	className := u16("PhoneMicWindow")
	icon, _, _ := procLoadIconW.Call(a.hinst, 2)
	wc := wndClassEx{
		lpfnWndProc: syscall.NewCallback(wndProc), hInstance: a.hinst, hIcon: icon, hIconSm: icon,
		hCursor: a.cursorArrow, lpszClassName: className,
	}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	style := uintptr(wsOverlapped | wsCaption | wsSysMenu | wsMinimizeBox | wsClipChildren)
	rc := rect{0, 0, a.S(winW), a.S(winH)}
	procAdjustWindowRect.Call(uintptr(unsafe.Pointer(&rc)), style, 0)
	w, h := rc.R-rc.L, rc.B-rc.T
	sw, _, _ := procGetSystemMetrics.Call(0)
	sh, _, _ := procGetSystemMetrics.Call(1)
	x, y := (int32(sw)-w)/2, (int32(sh)-h)/2
	if y < 0 {
		y = 0
	}
	a.hwnd, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(u16("PhoneMic"))),
		style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, a.hinst, 0)
	a.applyTheme() // now that the window exists: dark title bar
	procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&a.mainRect)))
	if a.cfg.Widget {
		a.setWidget(true)
	}

	a.fillDevices()
	a.startAudio()

	go func() {
		err := a.srv.Run(a.ips)
		msg := fmt.Sprint(err)
		if strings.Contains(strings.ToLower(msg), "only one usage") || strings.Contains(msg, "address already in use") {
			msg = fmt.Sprintf("Ports %d-%d are already in use. Is PhoneMic already open?", a.port-1, a.port+1)
		}
		a.errMu.Lock()
		a.serverErr = msg
		a.errMu.Unlock()
		procPostMessageW.Call(a.hwnd, wmApp, 0, 0)
	}()

	procSetTimer.Call(a.hwnd, 1, 80, 0)
	procShowWindow.Call(a.hwnd, 1)
	procUpdateWindow.Call(a.hwnd)

	var m msgT
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	a.renderer.Stop()
}

func (a *App) qrURL() string { return a.srv.LandingURL(a.ip) }

func (a *App) makeQR() {
	q, err := qrcode.New(a.qrURL(), qrcode.Medium)
	if err != nil {
		a.qr = nil
		return
	}
	q.DisableBorder = true
	a.qr = q.Bitmap()
}

// ---------------------------------------------------------------- audio devices

func (a *App) fillDevices() {
	devs, def, err := ListOutputDevices()
	if err != nil {
		a.eng.SetAudioError(err.Error())
	}
	a.devices = devs
	pick := -1
	for i, d := range devs {
		if d.ID == a.cfg.DeviceID {
			pick = i
		}
	}
	if pick < 0 { // first run: prefer the virtual cable, else the default speakers
		for i, d := range devs {
			if IsVirtualCable(d.Name) && strings.Contains(strings.ToLower(d.Name), "cable input") {
				pick = i
				break
			}
		}
	}
	if pick < 0 {
		for i, d := range devs {
			if IsVirtualCable(d.Name) {
				pick = i
				break
			}
		}
	}
	if pick < 0 {
		for i, d := range devs {
			if d.ID == def {
				pick = i
			}
		}
	}
	if pick < 0 && len(devs) > 0 {
		pick = 0
	}
	a.deviceIdx = pick
}

func (a *App) startAudio() {
	a.renderer.Stop()
	a.renderer = nil
	if a.deviceIdx < 0 || a.deviceIdx >= len(a.devices) {
		a.eng.SetAudioError("No audio output devices found.")
		return
	}
	d := a.devices[a.deviceIdx]
	r, err := StartRenderer(d.ID, a.eng)
	if err != nil {
		a.eng.SetAudioError("Could not open " + d.Name + ": " + err.Error())
		return
	}
	a.renderer = r
	a.cfg.DeviceID = d.ID
	a.cfg.save()
}

// ---------------------------------------------------------------- drawing primitives
// All coordinates are at 96 DPI and scaled with S().

const (
	padX      = 24
	rowLabelW = 120
	rowY0     = 412
	rowGap    = 38
	boxY      = 578
)

func (a *App) text(hdc uintptr, s string, font uintptr, color uintptr, x, y, w, h int, flags uintptr) {
	procSelectObject.Call(hdc, font)
	procSetTextColor.Call(hdc, color)
	rc := rect{a.S(x), a.S(y), a.S(x + w), a.S(y + h)}
	p, _ := syscall.UTF16FromString(s)
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(&p[0])), uintptr(len(p)-1), uintptr(unsafe.Pointer(&rc)), flags|dtNoPrefix)
}

func fillPx(hdc uintptr, color uintptr, l, t, r, b int32) {
	br, _, _ := procCreateSolidBrush.Call(color)
	rc := rect{l, t, r, b}
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), br)
	procDeleteObject.Call(br)
}

func (a *App) fill(hdc uintptr, color uintptr, x, y, w, h int) {
	fillPx(hdc, color, a.S(x), a.S(y), a.S(x+w), a.S(y+h))
}

// round draws a filled rounded rectangle; border < 0 means no outline.
func (a *App) round(hdc uintptr, color uintptr, x, y, w, h, r int) {
	a.roundB(hdc, color, ^uintptr(0), x, y, w, h, r)
}

func (a *App) roundB(hdc uintptr, color, border uintptr, x, y, w, h, r int) {
	if gdipReady { // smooth anti-aliased corners
		c := a.gpBegin(hdc)
		c.roundRect(color, 255, border, float64(x), float64(y), float64(w), float64(h), float64(r)*0.6)
		c.end()
		return
	}
	br, _, _ := procCreateSolidBrush.Call(color)
	var pen uintptr
	if border == ^uintptr(0) {
		pen, _, _ = procGetStockObject.Call(8) // NULL_PEN
	} else {
		pen, _, _ = procCreatePen.Call(0, uintptr(a.S(1)), border)
	}
	ob, _, _ := procSelectObject.Call(hdc, br)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procRoundRect.Call(hdc, uintptr(a.S(x)), uintptr(a.S(y)), uintptr(a.S(x+w)+1), uintptr(a.S(y+h)+1), uintptr(a.S(r)), uintptr(a.S(r)))
	procSelectObject.Call(hdc, ob)
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(br)
	if border != ^uintptr(0) {
		procDeleteObject.Call(pen)
	}
}

// px converts a 96-DPI float coordinate to device pixels.
func (a *App) px(v float64) uintptr { return uintptr(int32(math.Round(v * float64(a.dpi) / 96))) }

func (a *App) polyline(hdc uintptr, color uintptr, width float64, pts ...float64) {
	if gdipReady { // anti-aliased, round caps and joins
		c := a.gpBegin(hdc)
		c.lines(color, width, pts...)
		c.end()
		return
	}
	pen, _, _ := procCreatePen.Call(0, uintptr(math.Max(1, math.Round(width*float64(a.dpi)/96))), color)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procMoveToEx.Call(hdc, a.px(pts[0]), a.px(pts[1]), 0)
	for i := 2; i+1 < len(pts); i += 2 {
		procLineTo.Call(hdc, a.px(pts[i]), a.px(pts[i+1]))
	}
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(pen)
}

func (a *App) circle(hdc uintptr, color uintptr, cx, cy, r float64) {
	if gdipReady {
		c := a.gpBegin(hdc)
		c.fillCircle(color, 255, cx, cy, r)
		c.end()
		return
	}
	br, _, _ := procCreateSolidBrush.Call(color)
	pen, _, _ := procGetStockObject.Call(8) // NULL_PEN
	ob, _, _ := procSelectObject.Call(hdc, br)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procEllipse.Call(hdc, a.px(cx-r), a.px(cy-r), a.px(cx+r)+1, a.px(cy+r)+1)
	procSelectObject.Call(hdc, ob)
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(br)
}

// themeIcon draws a moon (switch to dark) or a sun (switch to light).
func (a *App) themeIcon(hdc uintptr, cx, cy float64) {
	p := a.pal
	bg := p.button
	if a.hover == idTheme {
		bg = p.buttonHover
	}
	if gdipReady { // refined sun / moon
		c := a.gpBegin(hdc)
		if a.dark {
			c.strokeCircle(p.text, 1.6, cx, cy, 3.4)
			for i := 0; i < 8; i++ {
				ang := float64(i) * math.Pi / 4
				c.lines(p.text, 1.6, cx+math.Cos(ang)*6.2, cy+math.Sin(ang)*6.2, cx+math.Cos(ang)*7.9, cy+math.Sin(ang)*7.9)
			}
		} else {
			c.crescent(p.text, cx, cy, 7, cx+3.8, cy-3.2, 5.6)
		}
		c.end()
		return
	}
	if a.dark {
		a.circle(hdc, p.text, cx, cy, 3.6)
		for i := 0; i < 8; i++ {
			ang := float64(i) * math.Pi / 4
			a.polyline(hdc, p.text, 1.4, cx+math.Cos(ang)*5.8, cy+math.Sin(ang)*5.8, cx+math.Cos(ang)*8, cy+math.Sin(ang)*8)
		}
	} else {
		a.circle(hdc, p.text, cx, cy, 7)
		a.circle(hdc, bg, cx+3.6, cy-3, 6.2)
	}
}

func (a *App) addHit(id, x, y, w, h int) { a.hits = append(a.hits, hitRect{id, x, y, w, h}) }

// field draws a dropdown-style selector.
func (a *App) field(hdc uintptr, id int, x, y, w, h int, label string) {
	p := a.pal
	bg := p.field
	if a.hover == id {
		bg = p.fieldHover
	}
	a.roundB(hdc, bg, p.fieldLine, x, y, w, h, 8)
	a.text(hdc, label, a.fBody, p.text, x+10, y, w-36, h, dtSingleLine|dtVCenter|dtEndEllipsi)
	cy := float64(y) + float64(h)/2
	cxr := float64(x+w) - 17
	a.polyline(hdc, p.dim, 1.6, cxr-5, cy-2.5, cxr, cy+2.5, cxr+5, cy-2.5)
	a.addHit(id, x, y, w, h)
}

func (a *App) button(hdc uintptr, id int, label string, x, y, w, h int, primary bool) {
	p := a.pal
	bg, fg, border := p.button, p.text, p.fieldLine
	if a.hover == id {
		bg = p.buttonHover
	}
	if primary {
		bg, fg, border = p.primary, p.primaryText, ^uintptr(0)
		if a.hover == id {
			bg = p.primaryHover
		}
	}
	a.roundB(hdc, bg, border, x, y, w, h, 8)
	a.text(hdc, label, a.fBold, fg, x, y, w, h, dtSingleLine|dtVCenter|dtCenter)
	a.addHit(id, x, y, w, h)
}

// ---------------------------------------------------------------- painting

func (a *App) paint(hdc uintptr) {
	p := a.pal
	a.hits = a.hits[:0]
	procSetBkMode.Call(hdc, 1)
	if a.widget {
		a.paintWidget(hdc)
		return
	}
	a.fill(hdc, p.bg, 0, 0, winW, winH)

	// Header: title, theme / safe mode / widget buttons, status pill
	a.text(hdc, "PhoneMic", a.fTitle, p.text, padX, 16, 120, 34, dtSingleLine|dtVCenter)
	a.iconGroup(hdc, 140, 19, 28, []int{idTheme, idSafe, idWidget}, map[int]bool{idSafe: a.cfg.SafeMode})
	a.themeIcon(hdc, 157, 33)
	a.eyeIcon(hdc, a.iconColor(a.cfg.SafeMode), 192, 33, a.cfg.SafeMode)
	a.compactIcon(hdc, p.text, 227, 33)

	peer, via := a.srv.PeerInfo()
	a.errMu.Lock()
	serverErr := a.mask(a.serverErr)
	a.errMu.Unlock()
	_, devName, virtual, _, audioErr := a.eng.Snapshot()
	audioErr = a.mask(audioErr)
	pillText, pillBg, pillFg := "Waiting for phone", p.grayL, p.dim
	switch {
	case serverErr != "":
		pillText, pillBg, pillFg = "Not running", p.badL, p.bad
	case peer != "":
		shown := peer
		if a.cfg.SafeMode {
			shown = "Phone connected"
		}
		pillText, pillBg, pillFg = "Live  "+shown, p.accentL, p.accentText
		if via == "browser" {
			pillText += "  (browser)"
		}
	}
	a.round(hdc, pillBg, 252, 20, winW-padX-252, 26, 26)
	a.text(hdc, "●  "+pillText, a.fBold, pillFg, 258, 20, winW-padX-264, 26, dtSingleLine|dtVCenter|dtCenter|dtEndEllipsi)

	// Step 1 card: QR code
	a.roundB(hdc, p.card, p.cardLine, 14, 60, winW-28, 336, 14)
	a.text(hdc, "1   Scan with your phone's camera", a.fBold, p.text, padX, 64, 316, 22, dtSingleLine|dtVCenter)
	copyLabel := "Copy link"
	if !a.copiedUntil.IsZero() {
		copyLabel = "Copied!"
	}
	a.button(hdc, idCopy, copyLabel, winW-padX-86, 63, 86, 24, false)
	hostLine := a.host + "   ·   " + a.ip
	if a.cfg.SafeMode {
		hostLine = "Safe mode   ·   " + maskedIP
	}
	a.text(hdc, hostLine, a.fURL, p.accentText, padX, 92, winW-padX*2, 26, dtSingleLine|dtVCenter|dtCenter|dtEndEllipsi)
	a.text(hdc, "Opens the PhoneMic app and asks to connect - or offers to download it.", a.fSmall, p.dim,
		padX, 116, winW-padX*2, 18, dtSingleLine|dtVCenter|dtCenter)
	qrHidden := a.cfg.SafeMode && a.revealUntil.IsZero()
	if qrHidden {
		// The QR code contains this PC's address, so safe mode covers it until clicked.
		qx := (winW - 184) / 2
		bg := p.grayL
		if a.hover == idReveal {
			bg = p.fieldHover
		}
		a.roundB(hdc, bg, p.cardLine, qx, 140, 184, 184, 12)
		a.eyeIcon(hdc, p.dim, float64(winW)/2, 206, true)
		a.text(hdc, "QR code hidden", a.fBold, p.text, qx, 222, 184, 22, dtSingleLine|dtVCenter|dtCenter)
		a.text(hdc, "Click to show for 20 s", a.fSmall, p.dim, qx, 244, 184, 18, dtSingleLine|dtVCenter|dtCenter)
		a.addHit(idReveal, qx, 140, 184, 184)
	}
	if a.qr != nil && !qrHidden {
		n := len(a.qr)
		total := a.S(184)
		mod := total / int32(n+4)
		size := mod * int32(n+4)
		ox := (a.S(winW) - size) / 2
		oy := a.S(140)
		// QR codes must stay dark-on-white to scan reliably, also in dark mode.
		fillPx(hdc, rgb(0xFF, 0xFF, 0xFF), ox, oy, ox+size, oy+size)
		qz := mod * 2
		ink := rgb(0x11, 0x13, 0x18)
		for yy, row := range a.qr {
			for xx := 0; xx < n; {
				if !row[xx] {
					xx++
					continue
				}
				start := xx
				for xx < n && row[xx] {
					xx++
				}
				l := ox + qz + int32(start)*mod
				t := oy + qz + int32(yy)*mod
				fillPx(hdc, ink, l, t, l+int32(xx-start)*mod, t+mod)
			}
		}
	}
	helpText := "Already have the app? Just open it - it finds this PC by itself.\nNo Android phone? The same QR code lets you use the browser."
	if a.cfg.SafeMode && !a.revealUntil.IsZero() {
		helpText = fmt.Sprintf("Safe mode: QR code hides again in %d s.", int(math.Ceil(time.Until(a.revealUntil).Seconds())))
	}
	a.text(hdc, helpText, a.fSmall, p.dim, padX, 334, winW-padX*2, 60, dtCenter|dtWordBreak)

	// Settings rows
	cx, cw := padX+rowLabelW, winW-padX*2-rowLabelW
	labels := []string{"PC address", "Send audio to", "Delay buffer"}
	for i, l := range labels {
		a.text(hdc, l, a.fBody, p.dim, padX, rowY0+rowGap*i, rowLabelW-8, 28, dtSingleLine|dtVCenter)
	}
	addrLabel := a.ip
	if a.cfg.SafeMode {
		addrLabel = maskedIP
	}
	a.field(hdc, idAddress, cx, rowY0, cw, 28, addrLabel)
	devLabel := "No audio outputs found"
	if a.deviceIdx >= 0 && a.deviceIdx < len(a.devices) {
		devLabel = a.devices[a.deviceIdx].Name
	}
	a.field(hdc, idDevice, cx, rowY0+rowGap, cw, 28, devLabel)
	a.field(hdc, idBuffer, cx, rowY0+rowGap*2, cw, 28, bufferChoices[a.bufferIdx].label)

	// Level meter + stats
	my := rowY0 + rowGap*3 + 6
	a.round(hdc, p.line, padX, my, winW-padX*2, 8, 8)
	if lvl := a.meter; lvl > 0.005 {
		w := int(float64(winW-padX*2) * math.Min(1, lvl))
		a.meterFill(hdc, padX, my, w, 8, lvl) // gradient, amber near clipping
	}
	stats := "No audio yet"
	if peer != "" {
		buf := a.eng.Buffer()
		und, drops := buf.Stats()
		stats = fmt.Sprintf("Buffer %.0f ms   ·   %.0f kbit/s   ·   dropouts %d   ·   catch-ups %d   ·   lost %d",
			buf.LevelMs(), a.kbps, und, drops, a.srv.Lost())
	}
	a.text(hdc, stats, a.fSmall, p.dim, padX, my+12, winW-padX*2, 20, dtSingleLine|dtVCenter)

	// Step 2 / status box
	by := boxY
	switch {
	case serverErr != "":
		a.round(hdc, p.badL, 14, by, winW-28, 66, 12)
		a.text(hdc, serverErr, a.fBody, p.bad, padX, by+8, winW-padX*2, 50, dtWordBreak|dtVCenter)
	case audioErr != "":
		a.round(hdc, p.badL, 14, by, winW-28, 66, 12)
		a.text(hdc, audioErr, a.fBody, p.bad, padX, by+8, winW-padX*2, 50, dtWordBreak)
	case virtual:
		a.round(hdc, p.accentL, 14, by, winW-28, 66, 12)
		a.text(hdc, "2   In Discord, Zoom, OBS or Windows settings, pick this mic:\n     CABLE Output (VB-Audio Virtual Cable)",
			a.fBody, p.text, padX, by+10, winW-padX*2, 48, dtWordBreak)
	default:
		a.round(hdc, p.warnL, 14, by, winW-28, 66, 12)
		a.text(hdc, "Test mode: playing to \""+devName+"\".\nInstall the free VB-Cable driver to use your phone as a real mic.",
			a.fSmall, p.warn, padX, by+8, winW-padX*2-160, 52, dtWordBreak|dtEndEllipsi)
		a.button(hdc, idGetVB, "Download VB-Cable", winW-padX-150, by+18, 150, 30, true)
	}
}

// ---------------------------------------------------------------- popup menus

// popup shows a menu under the given (96-DPI) point and returns the chosen index or -1.
func (a *App) popup(items []string, checked int, x, y int) int {
	hm, _, _ := procCreatePopupMenu.Call()
	for i, it := range items {
		flags := uintptr(0) // MF_STRING
		if i == checked {
			flags |= 0x8 // MF_CHECKED
		}
		procAppendMenuW.Call(hm, flags, uintptr(i+1), uintptr(unsafe.Pointer(u16(it))))
	}
	pt := [2]int32{a.S(x), a.S(y)}
	procClientToScreen.Call(a.hwnd, uintptr(unsafe.Pointer(&pt)))
	procSetForegroundWind.Call(a.hwnd)
	r, _, _ := procTrackPopupMenu.Call(hm, 0x0100|0x0080, uintptr(pt[0]), uintptr(pt[1]), 0, a.hwnd, 0) // TPM_RETURNCMD|TPM_NONOTIFY
	procDestroyMenu.Call(hm)
	return int(r) - 1
}

func (a *App) hitAt(px, py int32) int {
	x, y := int(px)*96/a.dpi, int(py)*96/a.dpi
	for _, h := range a.hits {
		if x >= h.x && x < h.x+h.w && y >= h.y && y < h.y+h.h {
			return h.id
		}
	}
	return 0
}

func (a *App) hitRect(id int) hitRect {
	for _, h := range a.hits {
		if h.id == id {
			return h
		}
	}
	return hitRect{}
}

func (a *App) onClick(id int) {
	r := a.hitRect(id)
	below := r.y + r.h + 2
	switch id {
	case idTheme:
		cur := 0
		for i, c := range themeChoices {
			if c.key == a.cfg.Theme {
				cur = i
			}
		}
		labels := make([]string, len(themeChoices))
		for i, c := range themeChoices {
			labels[i] = c.label
		}
		if i := a.popup(labels, cur, r.x, below); i >= 0 {
			a.cfg.Theme = themeChoices[i].key
			a.cfg.save()
			a.applyTheme()
		}
	case idAddress:
		cur := 0
		for i, ip := range a.ips {
			if ip == a.ip {
				cur = i
			}
		}
		ipLabels := a.ips
		if a.cfg.SafeMode {
			ipLabels = make([]string, len(a.ips))
			for i := range a.ips {
				ipLabels[i] = fmt.Sprintf("Network %d   %s", i+1, maskedIP)
			}
		}
		if i := a.popup(ipLabels, cur, r.x, below); i >= 0 {
			a.ip = a.ips[i]
			a.cfg.IP = a.ip
			a.cfg.save()
			a.makeQR()
		}
	case idDevice:
		curID := ""
		if a.deviceIdx >= 0 && a.deviceIdx < len(a.devices) {
			curID = a.devices[a.deviceIdx].ID
		}
		if devs, _, err := ListOutputDevices(); err == nil && len(devs) > 0 { // pick up newly added devices
			a.devices = devs
		}
		names := make([]string, len(a.devices))
		cur := -1
		for i, d := range a.devices {
			names[i] = d.Name
			if d.ID == curID {
				cur = i
			}
		}
		if i := a.popup(names, cur, r.x, below); i >= 0 {
			a.deviceIdx = i
			a.startAudio()
		} else {
			a.deviceIdx = cur
		}
	case idBuffer:
		labels := make([]string, len(bufferChoices))
		for i, c := range bufferChoices {
			labels[i] = c.label
		}
		if i := a.popup(labels, a.bufferIdx, r.x, below); i >= 0 {
			a.bufferIdx = i
			a.eng.SetTarget(bufferChoices[i].ms)
			a.cfg.BufferMs = bufferChoices[i].ms
			a.cfg.save()
		}
	case idGetVB:
		procShellExecuteW.Call(a.hwnd, uintptr(unsafe.Pointer(u16("open"))), uintptr(unsafe.Pointer(u16("https://vb-audio.com/Cable/"))), 0, 0, 1)
	case idCopy:
		copyToClipboard(a.hwnd, a.qrURL())
		a.copiedUntil = time.Now().Add(1500 * time.Millisecond)
	case idSafe:
		a.cfg.SafeMode = !a.cfg.SafeMode
		a.revealUntil = time.Time{}
		a.cfg.save()
	case idReveal:
		a.revealUntil = time.Now().Add(20 * time.Second)
	case idWidget:
		a.setWidget(true)
		return
	case idExpand:
		a.setWidget(false)
		return
	case idClose:
		procPostMessageW.Call(a.hwnd, wmClose, 0, 0)
		return
	}
	procInvalidateRect.Call(a.hwnd, 0, 0)
}

// ---------------------------------------------------------------- events

func (a *App) onTimer() {
	pk := float64(a.eng.TakePeak())
	lvl := 0.0
	if pk > 0 {
		lvl = math.Max(0, (20*math.Log10(pk)+60)/60)
	}
	a.meter = math.Max(lvl, a.meter*0.82)
	if peer, _ := a.srv.PeerInfo(); peer == "" {
		a.meter = 0
	}
	if dt := time.Since(a.lastT).Seconds(); dt >= 1 {
		b := a.srv.BytesIn()
		a.kbps = float64(b-a.lastBytes) * 8 / 1000 / dt
		a.lastBytes, a.lastT = b, time.Now()
	}
	if !a.copiedUntil.IsZero() && time.Now().After(a.copiedUntil) {
		a.copiedUntil = time.Time{}
	}
	if !a.revealUntil.IsZero() && time.Now().After(a.revealUntil) {
		a.revealUntil = time.Time{}
	}
	procInvalidateRect.Call(a.hwnd, 0, 0)
}

func wndProc(hwnd, msg, wParam, lParam uintptr) uintptr {
	a := app
	switch msg {
	case wmEraseBkgnd:
		return 1
	case wmPaint:
		var ps paintStruct
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc rect
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		mem, _, _ := procCreateCompatibleDC.Call(hdc)
		bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(rc.R), uintptr(rc.B))
		old, _, _ := procSelectObject.Call(mem, bmp)
		a.paint(mem)
		procBitBlt.Call(hdc, 0, 0, uintptr(rc.R), uintptr(rc.B), mem, 0, 0, 0x00CC0020)
		procSelectObject.Call(mem, old)
		procDeleteObject.Call(bmp)
		procDeleteDC.Call(mem)
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case wmTimer:
		a.onTimer()
		return 0
	case wmMouseMove:
		h := a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		if !a.tracking {
			t := trackMouseEventT{dwFlags: 0x2, hwndTrack: hwnd} // TME_LEAVE
			t.cbSize = uint32(unsafe.Sizeof(t))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&t)))
			a.tracking = true
		}
		if h != a.hover {
			a.hover = h
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case wmMouseLeave:
		a.tracking = false
		if a.hover != 0 {
			a.hover = 0
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case wmLButtonDown:
		a.pressed = a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		return 0
	case wmLButtonUp:
		h := a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		if h != 0 && h == a.pressed {
			a.onClick(h)
		}
		a.pressed = 0
		return 0
	case wmSetCursor:
		if lParam&0xFFFF == 1 { // HTCLIENT
			if a.hover != 0 {
				procSetCursor.Call(a.cursorHand)
			} else {
				procSetCursor.Call(a.cursorArrow)
			}
			return 1
		}
	case wmSettingChange:
		if a.cfg.Theme == "auto" {
			a.applyTheme()
		}
	case wmNcHitTest:
		if a.widget { // the widget has no title bar: drag it by any spot that isn't a button
			pt := [2]int32{int32(int16(lParam)), int32(int16(lParam >> 16))}
			procScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
			if a.hitAt(pt[0], pt[1]) == 0 {
				return 2 // HTCAPTION
			}
			return 1 // HTCLIENT
		}
	case wmNcLButtonDbl:
		if a.widget && wParam == 2 { // double-click the widget: back to the full window
			a.setWidget(false)
			return 0
		}
	case wmExitSizeMove:
		if a.widget {
			a.saveWidgetPos()
		}
	case wmApp:
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case wmDestroy:
		if a.widget {
			a.saveWidgetPos()
		}
		procKillTimer.Call(hwnd, 1)
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, msg, wParam, lParam)
	return r
}

// ---------------------------------------------------------------- safe mode

const maskedIP = "•••.•••.•••.•••"

var (
	reIPv4 = regexp.MustCompile(`\b\d{1,3}(\.\d{1,3}){3}\b`)
	reIPv6 = regexp.MustCompile(`\b([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{1,4}\b`)
)

// mask hides IP addresses and the PC name in text shown on screen while safe mode is on.
func (a *App) mask(s string) string {
	if !a.cfg.SafeMode || s == "" {
		return s
	}
	s = reIPv4.ReplaceAllString(s, maskedIP)
	s = reIPv6.ReplaceAllString(s, maskedIP)
	if a.host != "" {
		s = strings.ReplaceAll(s, a.host, "this PC")
	}
	return s
}

// ---------------------------------------------------------------- widget mode

const widgetW, widgetH = 242, 48 // client size at 96 DPI

// setWidget switches between the full window and a small always-on-top icon bar.
func (a *App) setWidget(on bool) {
	if on {
		if !a.widget {
			procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&a.mainRect)))
		}
		a.widget = true
		w, h := a.S(widgetW), a.S(widgetH)
		vx, _, _ := procGetSystemMetrics.Call(76) // virtual screen (all monitors)
		vy, _, _ := procGetSystemMetrics.Call(77)
		vw, _, _ := procGetSystemMetrics.Call(78)
		vh, _, _ := procGetSystemMetrics.Call(79)
		l, t, r, b := int32(vx), int32(vy), int32(vx)+int32(vw), int32(vy)+int32(vh)
		x, y := a.cfg.WidgetX, a.cfg.WidgetY
		if !a.cfg.WidgetOK || x < l || y < t || x+w > r || y+h > b { // default: top-right corner
			sw, _, _ := procGetSystemMetrics.Call(0)
			x, y = int32(sw)-w-a.S(24), a.S(24)
		}
		procSetWindowLongPtrW.Call(a.hwnd, ^uintptr(15), uintptr(wsPopup|wsSysMenu|wsMinimizeBox|wsClipChildren)) // GWL_STYLE
		procSetWindowPos.Call(a.hwnd, ^uintptr(0), uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0x0020|0x0040) // HWND_TOPMOST, FRAMECHANGED|SHOWWINDOW
	} else {
		a.widget = false
		mr := a.mainRect
		procSetWindowLongPtrW.Call(a.hwnd, ^uintptr(15), uintptr(wsOverlapped|wsCaption|wsSysMenu|wsMinimizeBox|wsClipChildren))
		procSetWindowPos.Call(a.hwnd, ^uintptr(1), uintptr(mr.L), uintptr(mr.T), uintptr(mr.R-mr.L), uintptr(mr.B-mr.T), 0x0020|0x0040) // HWND_NOTOPMOST
	}
	if procDwmSetWindowAttribute.Find() == nil {
		pref := int32(0) // default corners
		if on {
			pref = 2 // round (Windows 11)
		}
		r, _, _ := procDwmSetWindowAttribute.Call(a.hwnd, 33, uintptr(unsafe.Pointer(&pref)), 4) // DWMWA_WINDOW_CORNER_PREFERENCE
		a.dwmRound = on && r == 0
		border := uint32(0xFFFFFFFF) // DWMWA_COLOR_DEFAULT
		if a.dwmRound {
			border = uint32(a.pal.cardLine)
		}
		procDwmSetWindowAttribute.Call(a.hwnd, 34, uintptr(unsafe.Pointer(&border)), 4) // DWMWA_BORDER_COLOR
	}
	a.cfg.Widget = on
	a.cfg.save()
	a.hover, a.pressed = 0, 0
	a.hits = a.hits[:0]
	procInvalidateRect.Call(a.hwnd, 0, 0)
}

func (a *App) saveWidgetPos() {
	var r rect
	procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&r)))
	a.cfg.WidgetX, a.cfg.WidgetY, a.cfg.WidgetOK = r.L, r.T, true
	a.cfg.save()
}

// paintWidget draws the compact bar: status mic, level meter, safe mode, expand, close.
func (a *App) paintWidget(hdc uintptr) {
	p := a.pal
	if a.dwmRound { // Windows 11 draws the rounded border in our colour
		a.fill(hdc, p.card, 0, 0, widgetW, widgetH)
	} else {
		a.fill(hdc, p.cardLine, 0, 0, widgetW, widgetH)
		a.fill(hdc, p.card, 1, 1, widgetW-2, widgetH-2)
	}

	peer, _ := a.srv.PeerInfo()
	a.errMu.Lock()
	serverErr := a.serverErr
	a.errMu.Unlock()
	_, _, virtual, _, audioErr := a.eng.Snapshot()
	col := p.dim
	switch {
	case serverErr != "" || audioErr != "":
		col = p.bad
	case peer != "" && !virtual:
		col = p.warn // test mode: playing to speakers
	case peer != "":
		col = p.accent
	}
	a.statusMic(hdc, col, peer != "", 26, 24)

	// Level meter
	a.round(hdc, p.line, 52, 22, 70, 4, 8)
	if lvl := a.meter; lvl > 0.005 {
		a.meterFill(hdc, 52, 22, int(70*math.Min(1, lvl)), 4, lvl)
	}

	a.fill(hdc, p.cardLine, 132, 14, 1, 20) // divider

	a.ghostButton(hdc, idSafe, 140, 9, 30, 30, a.cfg.SafeMode)
	a.eyeIcon(hdc, a.iconColor(a.cfg.SafeMode), 155, 24, a.cfg.SafeMode)
	a.ghostButton(hdc, idExpand, 172, 9, 30, 30, false)
	a.expandIcon(hdc, p.text, 187, 24)
	a.ghostButton(hdc, idClose, 204, 9, 30, 30, false)
	closeCol := p.text
	if a.hover == idClose {
		closeCol = p.bad
	}
	a.closeIcon(hdc, closeCol, 219, 24)
}

// ---------------------------------------------------------------- icons
// Icons are drawn as anti-aliased strokes (1.6 px, round caps) on a 16 px grid.

const iconStroke = 1.6

// mix blends two colours; t = 0 gives a, t = 1 gives b.
func mix(a, b uintptr, t float64) uintptr {
	ch := func(sh uint) uintptr {
		x, y := float64((a>>sh)&0xFF), float64((b>>sh)&0xFF)
		return uintptr(math.Round(x+(y-x)*t)) << sh
	}
	return ch(0) | ch(8) | ch(16)
}

// iconGroup draws a segmented toolbar: one rounded container, a slot per id, thin dividers.
// The slot for an id in active is tinted with the accent colour.
func (a *App) iconGroup(hdc uintptr, x, y, h int, ids []int, active map[int]bool) {
	p := a.pal
	const slot = 34
	w := slot*len(ids) + len(ids) - 1
	a.roundB(hdc, p.button, p.fieldLine, x, y, w, h, 16)
	for i, id := range ids {
		sx := x + i*(slot+1)
		if i > 0 {
			a.fill(hdc, p.fieldLine, sx-1, y+7, 1, h-14)
		}
		switch {
		case active[id]:
			a.round(hdc, p.accentL, sx+3, y+3, slot-6, h-6, 12)
		case a.hover == id:
			a.round(hdc, p.buttonHover, sx+3, y+3, slot-6, h-6, 12)
		}
		a.addHit(id, sx, y, slot, h)
	}
}

// ghostButton is a borderless icon button: tinted on hover, accent when active.
func (a *App) ghostButton(hdc uintptr, id int, x, y, w, h int, active bool) {
	p := a.pal
	switch {
	case active:
		a.round(hdc, p.accentL, x, y, w, h, 14)
	case a.hover == id && id == idClose:
		a.round(hdc, p.badL, x, y, w, h, 14)
	case a.hover == id:
		a.round(hdc, p.buttonHover, x, y, w, h, 14)
	}
	a.addHit(id, x, y, w, h)
}

// iconButton draws an empty bordered button; active ones are tinted with the accent colour.
func (a *App) iconButton(hdc uintptr, id int, x, y, w, h int, active bool) {
	if !active {
		a.button(hdc, id, "", x, y, w, h, false)
		return
	}
	a.roundB(hdc, a.pal.accentL, a.pal.accent, x, y, w, h, 8)
	a.addHit(id, x, y, w, h)
}

func (a *App) iconColor(active bool) uintptr {
	if active {
		return a.pal.accentText
	}
	return a.pal.text
}

// iconBg is the colour behind an icon in its button, used to cut gaps in strokes.
func (a *App) iconBg(id int, active bool) uintptr {
	p := a.pal
	switch {
	case active:
		return p.accentL
	case a.hover == id:
		return p.buttonHover
	case a.widget:
		return p.card
	}
	return p.button
}

// meterFill draws the level bar with a soft gradient (amber when close to clipping).
func (a *App) meterFill(hdc uintptr, x, y, w, h int, lvl float64) {
	p := a.pal
	to := p.accent
	if lvl > 0.92 {
		to = p.warn
	}
	if !gdipReady {
		a.round(hdc, to, x, y, w, h, h)
		return
	}
	c := a.gpBegin(hdc)
	c.gradientRound(mix(p.accent, p.card, 0.45), to, float64(x), float64(y), float64(w), float64(h), float64(h)/2)
	c.end()
}

// eyeIcon draws an eye; slashed means "hidden" (safe mode on).
func (a *App) eyeIcon(hdc uintptr, col uintptr, cx, cy float64, slashed bool) {
	var pts []float64
	for i := 0; i <= 24; i++ { // upper lid, left to right
		t := float64(i)/12 - 1
		pts = append(pts, cx+t*8, cy-5.2*math.Cos(t*math.Pi/2))
	}
	for i := 23; i >= 0; i-- { // lower lid, back to the start
		t := float64(i)/12 - 1
		pts = append(pts, cx+t*8, cy+5.2*math.Cos(t*math.Pi/2))
	}
	if !gdipReady {
		a.polyline(hdc, col, 1.5, pts...)
		a.circle(hdc, col, cx, cy, 2.3)
		if slashed {
			a.polyline(hdc, col, 1.6, cx-7, cy-6, cx+7, cy+6)
		}
		return
	}
	c := a.gpBegin(hdc)
	c.lines(col, iconStroke, pts...)
	c.strokeCircle(col, iconStroke, cx, cy, 2.3)
	if slashed {
		id := idSafe
		c.lines(a.iconBg(id, a.cfg.SafeMode), 4.4, cx-7, cy-7, cx+7, cy+7) // gap around the slash
		c.lines(col, iconStroke, cx-7, cy-7, cx+7, cy+7)
	}
	c.end()
}

// compactIcon: a window with a small floating panel - "switch to widget".
func (a *App) compactIcon(hdc uintptr, col uintptr, cx, cy float64) {
	if !gdipReady {
		a.polyline(hdc, col, 1.4, cx-8, cy-6, cx+8, cy-6, cx+8, cy+6, cx-8, cy+6, cx-8, cy-6)
		a.fill(hdc, col, int(cx)+1, int(cy)+1, 5, 3)
		return
	}
	c := a.gpBegin(hdc)
	c.strokeRound(col, iconStroke, cx-7.5, cy-6, 15, 12, 2.6)
	c.roundRect(col, 255, ^uintptr(0), cx+0.2, cy+0.4, 5.2, 3.4, 1.1)
	c.end()
}

// expandIcon: four corner brackets - "back to the full window".
func (a *App) expandIcon(hdc uintptr, col uintptr, cx, cy float64) {
	d, l := 6.5, 4.2
	a.polyline(hdc, col, iconStroke, cx-d, cy-d+l, cx-d, cy-d, cx-d+l, cy-d)
	a.polyline(hdc, col, iconStroke, cx+d-l, cy-d, cx+d, cy-d, cx+d, cy-d+l)
	a.polyline(hdc, col, iconStroke, cx+d, cy+d-l, cx+d, cy+d, cx+d-l, cy+d)
	a.polyline(hdc, col, iconStroke, cx-d+l, cy+d, cx-d, cy+d, cx-d, cy+d-l)
}

func (a *App) closeIcon(hdc uintptr, col uintptr, cx, cy float64) {
	a.polyline(hdc, col, iconStroke, cx-4.8, cy-4.8, cx+4.8, cy+4.8)
	a.polyline(hdc, col, iconStroke, cx-4.8, cy+4.8, cx+4.8, cy-4.8)
}

// statusMic draws the microphone inside a soft halo in the status colour;
// while live the halo breathes with the input level.
func (a *App) statusMic(hdc uintptr, col uintptr, live bool, cx, cy float64) {
	if !gdipReady {
		a.circle(hdc, mix(col, a.pal.card, 0.8), cx, cy, 14)
		a.micIcon(hdc, col, cx, cy)
		return
	}
	c := a.gpBegin(hdc)
	if live {
		c.fillCircle(col, 34, cx, cy, 15+4*math.Min(1, a.meter))
	}
	c.fillCircle(col, 46, cx, cy, 15)
	c.end()
	a.micIcon(hdc, col, cx, cy)
}

func (a *App) micIcon(hdc uintptr, col uintptr, cx, cy float64) {
	if !gdipReady {
		a.round(hdc, col, int(cx)-3, int(cy)-9, 7, 11, 7)
	} else {
		c := a.gpBegin(hdc)
		c.roundRect(col, 255, ^uintptr(0), cx-3.2, cy-8.6, 6.4, 10.6, 3.2)
		c.end()
	}
	var arc []float64
	for i := 0; i <= 16; i++ {
		t := float64(i) * math.Pi / 16
		arc = append(arc, cx+6*math.Cos(t), cy-2.4+6*math.Sin(t))
	}
	a.polyline(hdc, col, iconStroke, append([]float64{cx + 6, cy - 4.6}, arc...)...)
	a.polyline(hdc, col, iconStroke, cx-6, cy-2.4, cx-6, cy-4.6)
	a.polyline(hdc, col, iconStroke, cx, cy+3.6, cx, cy+7.6)
}

// ---------------------------------------------------------------- clipboard

var (
	procOpenClipboard    = user32.NewProc("OpenClipboard")
	procEmptyClipboard   = user32.NewProc("EmptyClipboard")
	procSetClipboardData = user32.NewProc("SetClipboardData")
	procCloseClipboard   = user32.NewProc("CloseClipboard")
	procGlobalAlloc      = kernel32.NewProc("GlobalAlloc")
	procGlobalLock       = kernel32.NewProc("GlobalLock")
	procGlobalUnlock     = kernel32.NewProc("GlobalUnlock")
)

func copyToClipboard(hwnd uintptr, s string) {
	p, _ := syscall.UTF16FromString(s)
	if r, _, _ := procOpenClipboard.Call(hwnd); r == 0 {
		return
	}
	defer procCloseClipboard.Call()
	procEmptyClipboard.Call()
	h, _, _ := procGlobalAlloc.Call(0x0002, uintptr(len(p)*2)) // GMEM_MOVEABLE
	if h == 0 {
		return
	}
	dst, _, _ := procGlobalLock.Call(h)
	copy(unsafe.Slice((*uint16)(unsafe.Pointer(dst)), len(p)), p)
	procGlobalUnlock.Call(h)
	procSetClipboardData.Call(13, h) // CF_UNICODETEXT
}
