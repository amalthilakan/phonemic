//go:build windows

// Native Win32 window for PhoneMic (no frameworks, no runtime to install).
// Every control is drawn by hand so the light and dark themes look consistent.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	qrcode "github.com/skip2/go-qrcode"
)

var (
	user32                = syscall.NewLazyDLL("user32.dll")
	procRegisterClassExW  = user32.NewProc("RegisterClassExW")
	procCreateWindowExW   = user32.NewProc("CreateWindowExW")
	procDefWindowProcW    = user32.NewProc("DefWindowProcW")
	procGetMessageW       = user32.NewProc("GetMessageW")
	procTranslateMessage  = user32.NewProc("TranslateMessage")
	procDispatchMessageW  = user32.NewProc("DispatchMessageW")
	procPostQuitMessage   = user32.NewProc("PostQuitMessage")
	procPostMessageW      = user32.NewProc("PostMessageW")
	procShowWindow        = user32.NewProc("ShowWindow")
	procUpdateWindow      = user32.NewProc("UpdateWindow")
	procBeginPaint        = user32.NewProc("BeginPaint")
	procEndPaint          = user32.NewProc("EndPaint")
	procGetClientRect     = user32.NewProc("GetClientRect")
	procInvalidateRect    = user32.NewProc("InvalidateRect")
	procFillRect          = user32.NewProc("FillRect")
	procDrawTextW         = user32.NewProc("DrawTextW")
	procSetTimer          = user32.NewProc("SetTimer")
	procKillTimer         = user32.NewProc("KillTimer")
	procLoadCursorW       = user32.NewProc("LoadCursorW")
	procSetCursor         = user32.NewProc("SetCursor")
	procLoadIconW         = user32.NewProc("LoadIconW")
	procAdjustWindowRect  = user32.NewProc("AdjustWindowRect")
	procGetSystemMetrics  = user32.NewProc("GetSystemMetrics")
	procGetDC             = user32.NewProc("GetDC")
	procReleaseDC         = user32.NewProc("ReleaseDC")
	procSetProcessDPIAwa  = user32.NewProc("SetProcessDPIAware")
	procCreatePopupMenu   = user32.NewProc("CreatePopupMenu")
	procAppendMenuW       = user32.NewProc("AppendMenuW")
	procTrackPopupMenu    = user32.NewProc("TrackPopupMenu")
	procDestroyMenu       = user32.NewProc("DestroyMenu")
	procClientToScreen    = user32.NewProc("ClientToScreen")
	procTrackMouseEvent   = user32.NewProc("TrackMouseEvent")
	procSetWindowPos      = user32.NewProc("SetWindowPos")
	procSetForegroundWind = user32.NewProc("SetForegroundWindow")

	gdi32                      = syscall.NewLazyDLL("gdi32.dll")
	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procCreatePen              = gdi32.NewProc("CreatePen")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procGetDeviceCaps          = gdi32.NewProc("GetDeviceCaps")
	procRoundRect              = gdi32.NewProc("RoundRect")
	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procMoveToEx               = gdi32.NewProc("MoveToEx")
	procLineTo                 = gdi32.NewProc("LineTo")
	procEllipse                = gdi32.NewProc("Ellipse")

	shell32           = syscall.NewLazyDLL("shell32.dll")
	procShellExecuteW = shell32.NewProc("ShellExecuteW")

	advapi32         = syscall.NewLazyDLL("advapi32.dll")
	procRegGetValueW = advapi32.NewProc("RegGetValueW")

	dwmapi                    = syscall.NewLazyDLL("dwmapi.dll")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")

	procGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
	procLoadLibraryW     = kernel32.NewProc("LoadLibraryW")
	procGetProcAddress   = kernel32.NewProc("GetProcAddress")
)

const (
	wsOverlapped   = 0x00000000
	wsCaption      = 0x00C00000
	wsSysMenu      = 0x00080000
	wsMinimizeBox  = 0x00020000
	wsClipChildren = 0x02000000

	wmDestroy       = 0x0002
	wmPaint         = 0x000F
	wmEraseBkgnd    = 0x0014
	wmSettingChange = 0x001A
	wmSetCursor     = 0x0020
	wmTimer         = 0x0113
	wmMouseMove     = 0x0200
	wmLButtonDown   = 0x0201
	wmLButtonUp     = 0x0202
	wmMouseLeave    = 0x02A3
	wmApp           = 0x8000

	dtCenter     = 0x01
	dtVCenter    = 0x04
	dtWordBreak  = 0x10
	dtSingleLine = 0x20
	dtNoPrefix   = 0x800
	dtEndEllipsi = 0x8000

	idAddress = 101
	idDevice  = 102
	idBuffer  = 103
	idGetVB   = 104
	idCopy    = 105
	idTheme   = 106
)

type rect struct{ L, T, R, B int32 }

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type msgT struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      [2]int32
	private uint32
}

type paintStruct struct {
	hdc         uintptr
	fErase      int32
	rcPaint     rect
	fRestore    int32
	fIncUpdate  int32
	rgbReserved [32]byte
}

type trackMouseEventT struct {
	cbSize      uint32
	dwFlags     uint32
	hwndTrack   uintptr
	dwHoverTime uint32
}

func rgb(r, g, b uint8) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

// ---------------------------------------------------------------- themes

type palette struct {
	bg, card, cardLine, text, dim, line        uintptr
	accent, accentText, accentL                uintptr
	warn, warnL, bad, badL, grayL              uintptr
	field, fieldHover, fieldLine               uintptr
	button, buttonHover, primary, primaryHover uintptr
	primaryText                                uintptr
}

var lightPal = palette{
	bg: rgb(0xF4, 0xF5, 0xF8), card: rgb(0xFF, 0xFF, 0xFF), cardLine: rgb(0xE6, 0xE8, 0xEC),
	text: rgb(0x1B, 0x1F, 0x27), dim: rgb(0x6B, 0x72, 0x80), line: rgb(0xE3, 0xE6, 0xEB),
	accent: rgb(0x12, 0xA1, 0x6B), accentText: rgb(0x0E, 0x8A, 0x5B), accentL: rgb(0xDF, 0xF6, 0xEC),
	warn: rgb(0xB4, 0x5A, 0x00), warnL: rgb(0xFF, 0xF1, 0xDC), bad: rgb(0xC6, 0x28, 0x28), badL: rgb(0xFD, 0xE7, 0xE7),
	grayL: rgb(0xEA, 0xEC, 0xF0),
	field: rgb(0xFF, 0xFF, 0xFF), fieldHover: rgb(0xF3, 0xF5, 0xF8), fieldLine: rgb(0xD5, 0xD9, 0xE0),
	button: rgb(0xFF, 0xFF, 0xFF), buttonHover: rgb(0xF0, 0xF2, 0xF5),
	primary: rgb(0x12, 0xA1, 0x6B), primaryHover: rgb(0x0F, 0x8F, 0x5F), primaryText: rgb(0xFF, 0xFF, 0xFF),
}

var darkPal = palette{
	bg: rgb(0x11, 0x13, 0x18), card: rgb(0x1A, 0x1D, 0x24), cardLine: rgb(0x26, 0x2A, 0x33),
	text: rgb(0xE8, 0xEA, 0xF0), dim: rgb(0x8B, 0x93, 0xA5), line: rgb(0x2A, 0x2F, 0x3A),
	accent: rgb(0x3D, 0xDC, 0x97), accentText: rgb(0x3D, 0xDC, 0x97), accentL: rgb(0x13, 0x3A, 0x2B),
	warn: rgb(0xFF, 0xB5, 0x47), warnL: rgb(0x36, 0x29, 0x14), bad: rgb(0xFF, 0x6B, 0x6B), badL: rgb(0x3A, 0x18, 0x18),
	grayL: rgb(0x23, 0x27, 0x30),
	field: rgb(0x20, 0x24, 0x2C), fieldHover: rgb(0x27, 0x2C, 0x36), fieldLine: rgb(0x33, 0x39, 0x45),
	button: rgb(0x23, 0x27, 0x30), buttonHover: rgb(0x2C, 0x31, 0x3C),
	primary: rgb(0x3D, 0xDC, 0x97), primaryHover: rgb(0x5A, 0xE6, 0xA9), primaryText: rgb(0x06, 0x2A, 0x1B),
}

var themeChoices = []struct{ key, label string }{
	{"auto", "Auto (match Windows)"},
	{"light", "Light"},
	{"dark", "Dark"},
}

// windowsUsesDark reads the "Choose your app mode" setting.
func windowsUsesDark() bool {
	var v uint32
	size := uint32(4)
	r, _, _ := procRegGetValueW.Call(0x80000001, // HKEY_CURRENT_USER
		uintptr(unsafe.Pointer(u16(`Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`))),
		uintptr(unsafe.Pointer(u16("AppsUseLightTheme"))), 0x10, // RRF_RT_REG_DWORD
		0, uintptr(unsafe.Pointer(&v)), uintptr(unsafe.Pointer(&size)))
	return r == 0 && v == 0
}

// setMenuDarkMode makes popup menus follow our theme (undocumented uxtheme
// ordinals used by Explorer/Notepad; silently skipped where unavailable).
func setMenuDarkMode(dark bool) {
	h, _, _ := procLoadLibraryW.Call(uintptr(unsafe.Pointer(u16("uxtheme.dll"))))
	if h == 0 {
		return
	}
	setPreferredAppMode, _, _ := procGetProcAddress.Call(h, 135)
	flushMenuThemes, _, _ := procGetProcAddress.Call(h, 136)
	if setPreferredAppMode == 0 {
		return
	}
	mode := uintptr(3) // ForceLight
	if dark {
		mode = 2 // ForceDark
	}
	syscall.SyscallN(setPreferredAppMode, mode)
	if flushMenuThemes != 0 {
		syscall.SyscallN(flushMenuThemes)
	}
}

func (a *App) applyTheme() {
	a.dark = a.cfg.Theme == "dark" || (a.cfg.Theme != "light" && windowsUsesDark())
	if a.dark {
		a.pal = &darkPal
	} else {
		a.pal = &lightPal
	}
	setMenuDarkMode(a.dark)
	if a.hwnd != 0 && procDwmSetWindowAttribute.Find() == nil {
		v := int32(0)
		if a.dark {
			v = 1
		}
		r, _, _ := procDwmSetWindowAttribute.Call(a.hwnd, 20, uintptr(unsafe.Pointer(&v)), 4) // DWMWA_USE_IMMERSIVE_DARK_MODE
		if r != 0 {
			procDwmSetWindowAttribute.Call(a.hwnd, 19, uintptr(unsafe.Pointer(&v)), 4) // older Windows 10 builds
		}
		procSetWindowPos.Call(a.hwnd, 0, 0, 0, 0, 0, 0x0001|0x0002|0x0004|0x0020) // redraw the title bar
	}
	if a.hwnd != 0 {
		procInvalidateRect.Call(a.hwnd, 0, 0)
	}
}

// ---------------------------------------------------------------- settings

const winW, winH = 460, 660 // client size at 96 DPI

type settings struct {
	DeviceID string  `json:"device_id"`
	BufferMs float64 `json:"buffer_ms"`
	IP       string  `json:"ip"`
	Theme    string  `json:"theme"`
}

func settingsPath() string { return filepath.Join(configDir(), "settings.json") }

func loadSettings() settings {
	s := settings{BufferMs: 30, Theme: "auto"}
	if b, err := os.ReadFile(settingsPath()); err == nil {
		json.Unmarshal(b, &s)
	}
	if s.BufferMs <= 0 {
		s.BufferMs = 30
	}
	if s.Theme == "" {
		s.Theme = "auto"
	}
	return s
}

func (s settings) save() {
	b, _ := json.MarshalIndent(s, "", "  ")
	os.WriteFile(settingsPath(), b, 0o644)
}

// ---------------------------------------------------------------- app state

type hitRect struct{ id, x, y, w, h int }

type App struct {
	hwnd, hinst                  uintptr
	dpi                          int
	fTitle, fBody, fBold, fSmall uintptr
	fURL                         uintptr
	eng                          *Engine
	srv                          *Server
	port                         int
	ips                          []string
	ip                           string
	host                         string
	qr                           [][]bool
	devices                      []AudioDevice
	deviceIdx                    int
	bufferIdx                    int
	renderer                     *Renderer
	cfg                          settings
	errMu                        sync.Mutex
	serverErr                    string
	meter                        float64
	kbps                         float64
	lastBytes                    int64
	lastT                        time.Time
	copiedUntil                  time.Time
	dark                         bool
	pal                          *palette
	hits                         []hitRect
	hover, pressed               int
	tracking                     bool
	cursorArrow, cursorHand      uintptr
}

var app *App

var bufferChoices = []struct {
	ms    float64
	label string
}{
	{15, "15 ms  -  lowest delay"},
	{20, "20 ms"},
	{30, "30 ms  -  recommended"},
	{50, "50 ms"},
	{80, "80 ms  -  weak Wi-Fi"},
}

func (a *App) S(v int) int32 { return int32(v * a.dpi / 96) }

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func (a *App) font(pt int, weight int) uintptr {
	h, _, _ := procCreateFontW.Call(uintptr(-int32(pt*a.dpi/72)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0,
		uintptr(unsafe.Pointer(u16("Segoe UI"))))
	return h
}

func main() {
	runtime.LockOSThread()
	port := flag.Int("port", 8443, "network port")
	flag.Parse()

	procSetProcessDPIAwa.Call()
	procCoInitializeEx.Call(0, 2) // STA for the UI thread

	a := &App{port: *port, cfg: loadSettings(), lastT: time.Now()}
	app = a
	a.applyTheme()
	a.hinst, _, _ = procGetModuleHandleW.Call(0)
	hdc, _, _ := procGetDC.Call(0)
	d, _, _ := procGetDeviceCaps.Call(hdc, 90) // LOGPIXELSY
	procReleaseDC.Call(0, hdc)
	a.dpi = int(d)
	if a.dpi <= 0 {
		a.dpi = 96
	}
	a.fTitle = a.font(17, 700)
	a.fURL = a.font(13, 600)
	a.fBody = a.font(10, 400)
	a.fBold = a.font(10, 600)
	a.fSmall = a.font(9, 400)
	a.cursorArrow, _, _ = procLoadCursorW.Call(0, 32512)
	a.cursorHand, _, _ = procLoadCursorW.Call(0, 32649)

	a.eng = NewEngine(a.cfg.BufferMs)
	a.ips = LocalIPs()
	a.host = hostName()
	a.ip = a.ips[0]
	for _, ip := range a.ips {
		if ip == a.cfg.IP {
			a.ip = ip
		}
	}
	a.srv = NewServer(a.eng, a.port)
	a.makeQR()

	a.bufferIdx = 2
	for i, c := range bufferChoices {
		if c.ms == a.cfg.BufferMs {
			a.bufferIdx = i
		}
	}
	a.eng.SetTarget(bufferChoices[a.bufferIdx].ms)

	className := u16("PhoneMicWindow")
	icon, _, _ := procLoadIconW.Call(a.hinst, 2)
	wc := wndClassEx{
		lpfnWndProc: syscall.NewCallback(wndProc), hInstance: a.hinst, hIcon: icon, hIconSm: icon,
		hCursor: a.cursorArrow, lpszClassName: className,
	}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	style := uintptr(wsOverlapped | wsCaption | wsSysMenu | wsMinimizeBox | wsClipChildren)
	rc := rect{0, 0, a.S(winW), a.S(winH)}
	procAdjustWindowRect.Call(uintptr(unsafe.Pointer(&rc)), style, 0)
	w, h := rc.R-rc.L, rc.B-rc.T
	sw, _, _ := procGetSystemMetrics.Call(0)
	sh, _, _ := procGetSystemMetrics.Call(1)
	x, y := (int32(sw)-w)/2, (int32(sh)-h)/2
	if y < 0 {
		y = 0
	}
	a.hwnd, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(u16("PhoneMic"))),
		style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, a.hinst, 0)
	a.applyTheme() // now that the window exists: dark title bar

	a.fillDevices()
	a.startAudio()

	go func() {
		err := a.srv.Run(a.ips)
		msg := fmt.Sprint(err)
		if strings.Contains(strings.ToLower(msg), "only one usage") || strings.Contains(msg, "address already in use") {
			msg = fmt.Sprintf("Ports %d-%d are already in use. Is PhoneMic already open?", a.port-1, a.port+1)
		}
		a.errMu.Lock()
		a.serverErr = msg
		a.errMu.Unlock()
		procPostMessageW.Call(a.hwnd, wmApp, 0, 0)
	}()

	procSetTimer.Call(a.hwnd, 1, 80, 0)
	procShowWindow.Call(a.hwnd, 1)
	procUpdateWindow.Call(a.hwnd)

	var m msgT
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	a.renderer.Stop()
}

func (a *App) qrURL() string { return a.srv.LandingURL(a.ip) }

func (a *App) makeQR() {
	q, err := qrcode.New(a.qrURL(), qrcode.Medium)
	if err != nil {
		a.qr = nil
		return
	}
	q.DisableBorder = true
	a.qr = q.Bitmap()
}

// ---------------------------------------------------------------- audio devices

func (a *App) fillDevices() {
	devs, def, err := ListOutputDevices()
	if err != nil {
		a.eng.SetAudioError(err.Error())
	}
	a.devices = devs
	pick := -1
	for i, d := range devs {
		if d.ID == a.cfg.DeviceID {
			pick = i
		}
	}
	if pick < 0 { // first run: prefer the virtual cable, else the default speakers
		for i, d := range devs {
			if IsVirtualCable(d.Name) && strings.Contains(strings.ToLower(d.Name), "cable input") {
				pick = i
				break
			}
		}
	}
	if pick < 0 {
		for i, d := range devs {
			if IsVirtualCable(d.Name) {
				pick = i
				break
			}
		}
	}
	if pick < 0 {
		for i, d := range devs {
			if d.ID == def {
				pick = i
			}
		}
	}
	if pick < 0 && len(devs) > 0 {
		pick = 0
	}
	a.deviceIdx = pick
}

func (a *App) startAudio() {
	a.renderer.Stop()
	a.renderer = nil
	if a.deviceIdx < 0 || a.deviceIdx >= len(a.devices) {
		a.eng.SetAudioError("No audio output devices found.")
		return
	}
	d := a.devices[a.deviceIdx]
	r, err := StartRenderer(d.ID, a.eng)
	if err != nil {
		a.eng.SetAudioError("Could not open " + d.Name + ": " + err.Error())
		return
	}
	a.renderer = r
	a.cfg.DeviceID = d.ID
	a.cfg.save()
}

// ---------------------------------------------------------------- drawing primitives
// All coordinates are at 96 DPI and scaled with S().

const (
	padX      = 24
	rowLabelW = 120
	rowY0     = 412
	rowGap    = 38
	boxY      = 578
)

func (a *App) text(hdc uintptr, s string, font uintptr, color uintptr, x, y, w, h int, flags uintptr) {
	procSelectObject.Call(hdc, font)
	procSetTextColor.Call(hdc, color)
	rc := rect{a.S(x), a.S(y), a.S(x + w), a.S(y + h)}
	p, _ := syscall.UTF16FromString(s)
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(&p[0])), uintptr(len(p)-1), uintptr(unsafe.Pointer(&rc)), flags|dtNoPrefix)
}

func fillPx(hdc uintptr, color uintptr, l, t, r, b int32) {
	br, _, _ := procCreateSolidBrush.Call(color)
	rc := rect{l, t, r, b}
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), br)
	procDeleteObject.Call(br)
}

func (a *App) fill(hdc uintptr, color uintptr, x, y, w, h int) {
	fillPx(hdc, color, a.S(x), a.S(y), a.S(x+w), a.S(y+h))
}

// round draws a filled rounded rectangle; border < 0 means no outline.
func (a *App) round(hdc uintptr, color uintptr, x, y, w, h, r int) {
	a.roundB(hdc, color, ^uintptr(0), x, y, w, h, r)
}

func (a *App) roundB(hdc uintptr, color, border uintptr, x, y, w, h, r int) {
	br, _, _ := procCreateSolidBrush.Call(color)
	var pen uintptr
	if border == ^uintptr(0) {
		pen, _, _ = procGetStockObject.Call(8) // NULL_PEN
	} else {
		pen, _, _ = procCreatePen.Call(0, uintptr(a.S(1)), border)
	}
	ob, _, _ := procSelectObject.Call(hdc, br)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procRoundRect.Call(hdc, uintptr(a.S(x)), uintptr(a.S(y)), uintptr(a.S(x+w)+1), uintptr(a.S(y+h)+1), uintptr(a.S(r)), uintptr(a.S(r)))
	procSelectObject.Call(hdc, ob)
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(br)
	if border != ^uintptr(0) {
		procDeleteObject.Call(pen)
	}
}

// px converts a 96-DPI float coordinate to device pixels.
func (a *App) px(v float64) uintptr { return uintptr(int32(math.Round(v * float64(a.dpi) / 96))) }

func (a *App) polyline(hdc uintptr, color uintptr, width float64, pts ...float64) {
	pen, _, _ := procCreatePen.Call(0, uintptr(math.Max(1, math.Round(width*float64(a.dpi)/96))), color)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procMoveToEx.Call(hdc, a.px(pts[0]), a.px(pts[1]), 0)
	for i := 2; i+1 < len(pts); i += 2 {
		procLineTo.Call(hdc, a.px(pts[i]), a.px(pts[i+1]))
	}
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(pen)
}

func (a *App) circle(hdc uintptr, color uintptr, cx, cy, r float64) {
	br, _, _ := procCreateSolidBrush.Call(color)
	pen, _, _ := procGetStockObject.Call(8) // NULL_PEN
	ob, _, _ := procSelectObject.Call(hdc, br)
	op, _, _ := procSelectObject.Call(hdc, pen)
	procEllipse.Call(hdc, a.px(cx-r), a.px(cy-r), a.px(cx+r)+1, a.px(cy+r)+1)
	procSelectObject.Call(hdc, ob)
	procSelectObject.Call(hdc, op)
	procDeleteObject.Call(br)
}

// themeIcon draws a moon (switch to dark) or a sun (switch to light).
func (a *App) themeIcon(hdc uintptr, cx, cy float64) {
	p := a.pal
	bg := p.button
	if a.hover == idTheme {
		bg = p.buttonHover
	}
	if a.dark {
		a.circle(hdc, p.text, cx, cy, 3.6)
		for i := 0; i < 8; i++ {
			ang := float64(i) * math.Pi / 4
			a.polyline(hdc, p.text, 1.4, cx+math.Cos(ang)*5.8, cy+math.Sin(ang)*5.8, cx+math.Cos(ang)*8, cy+math.Sin(ang)*8)
		}
	} else {
		a.circle(hdc, p.text, cx, cy, 7)
		a.circle(hdc, bg, cx+3.6, cy-3, 6.2)
	}
}

func (a *App) addHit(id, x, y, w, h int) { a.hits = append(a.hits, hitRect{id, x, y, w, h}) }

// field draws a dropdown-style selector.
func (a *App) field(hdc uintptr, id int, x, y, w, h int, label string) {
	p := a.pal
	bg := p.field
	if a.hover == id {
		bg = p.fieldHover
	}
	a.roundB(hdc, bg, p.fieldLine, x, y, w, h, 8)
	a.text(hdc, label, a.fBody, p.text, x+10, y, w-36, h, dtSingleLine|dtVCenter|dtEndEllipsi)
	cy := float64(y) + float64(h)/2
	cxr := float64(x+w) - 17
	a.polyline(hdc, p.dim, 1.6, cxr-5, cy-2.5, cxr, cy+2.5, cxr+5, cy-2.5)
	a.addHit(id, x, y, w, h)
}

func (a *App) button(hdc uintptr, id int, label string, x, y, w, h int, primary bool) {
	p := a.pal
	bg, fg, border := p.button, p.text, p.fieldLine
	if a.hover == id {
		bg = p.buttonHover
	}
	if primary {
		bg, fg, border = p.primary, p.primaryText, ^uintptr(0)
		if a.hover == id {
			bg = p.primaryHover
		}
	}
	a.roundB(hdc, bg, border, x, y, w, h, 8)
	a.text(hdc, label, a.fBold, fg, x, y, w, h, dtSingleLine|dtVCenter|dtCenter)
	a.addHit(id, x, y, w, h)
}

// ---------------------------------------------------------------- painting

func (a *App) paint(hdc uintptr) {
	p := a.pal
	a.hits = a.hits[:0]
	a.fill(hdc, p.bg, 0, 0, winW, winH)
	procSetBkMode.Call(hdc, 1)

	// Header: title, theme button, status pill
	a.text(hdc, "PhoneMic", a.fTitle, p.text, padX, 16, 120, 34, dtSingleLine|dtVCenter)
	a.button(hdc, idTheme, "", 140, 20, 32, 26, false)
	a.themeIcon(hdc, 156, 33)

	peer, via := a.srv.PeerInfo()
	a.errMu.Lock()
	serverErr := a.serverErr
	a.errMu.Unlock()
	_, devName, virtual, _, audioErr := a.eng.Snapshot()
	pillText, pillBg, pillFg := "Waiting for phone", p.grayL, p.dim
	switch {
	case serverErr != "":
		pillText, pillBg, pillFg = "Not running", p.badL, p.bad
	case peer != "":
		pillText, pillBg, pillFg = "Live  "+peer, p.accentL, p.accentText
		if via == "browser" {
			pillText += "  (browser)"
		}
	}
	a.round(hdc, pillBg, winW-padX-250, 20, 250, 26, 26)
	a.text(hdc, "●  "+pillText, a.fBold, pillFg, winW-padX-242, 20, 234, 26, dtSingleLine|dtVCenter|dtCenter|dtEndEllipsi)

	// Step 1 card: QR code
	a.roundB(hdc, p.card, p.cardLine, 14, 60, winW-28, 336, 14)
	a.text(hdc, "1   Scan with your phone's camera", a.fBold, p.text, padX, 64, 316, 22, dtSingleLine|dtVCenter)
	copyLabel := "Copy link"
	if !a.copiedUntil.IsZero() {
		copyLabel = "Copied!"
	}
	a.button(hdc, idCopy, copyLabel, winW-padX-86, 63, 86, 24, false)
	a.text(hdc, a.host+"   ·   "+a.ip, a.fURL, p.accentText, padX, 92, winW-padX*2, 26, dtSingleLine|dtVCenter|dtCenter|dtEndEllipsi)
	a.text(hdc, "Opens the PhoneMic app and asks to connect - or offers to download it.", a.fSmall, p.dim,
		padX, 116, winW-padX*2, 18, dtSingleLine|dtVCenter|dtCenter)
	if a.qr != nil {
		n := len(a.qr)
		total := a.S(184)
		mod := total / int32(n+4)
		size := mod * int32(n+4)
		ox := (a.S(winW) - size) / 2
		oy := a.S(140)
		// QR codes must stay dark-on-white to scan reliably, also in dark mode.
		fillPx(hdc, rgb(0xFF, 0xFF, 0xFF), ox, oy, ox+size, oy+size)
		qz := mod * 2
		ink := rgb(0x11, 0x13, 0x18)
		for yy, row := range a.qr {
			for xx := 0; xx < n; {
				if !row[xx] {
					xx++
					continue
				}
				start := xx
				for xx < n && row[xx] {
					xx++
				}
				l := ox + qz + int32(start)*mod
				t := oy + qz + int32(yy)*mod
				fillPx(hdc, ink, l, t, l+int32(xx-start)*mod, t+mod)
			}
		}
	}
	a.text(hdc, "Already have the app? Just open it - it finds this PC by itself.\nNo Android phone? The same QR code lets you use the browser.",
		a.fSmall, p.dim, padX, 334, winW-padX*2, 60, dtCenter|dtWordBreak)

	// Settings rows
	cx, cw := padX+rowLabelW, winW-padX*2-rowLabelW
	labels := []string{"PC address", "Send audio to", "Delay buffer"}
	for i, l := range labels {
		a.text(hdc, l, a.fBody, p.dim, padX, rowY0+rowGap*i, rowLabelW-8, 28, dtSingleLine|dtVCenter)
	}
	a.field(hdc, idAddress, cx, rowY0, cw, 28, a.ip)
	devLabel := "No audio outputs found"
	if a.deviceIdx >= 0 && a.deviceIdx < len(a.devices) {
		devLabel = a.devices[a.deviceIdx].Name
	}
	a.field(hdc, idDevice, cx, rowY0+rowGap, cw, 28, devLabel)
	a.field(hdc, idBuffer, cx, rowY0+rowGap*2, cw, 28, bufferChoices[a.bufferIdx].label)

	// Level meter + stats
	my := rowY0 + rowGap*3 + 6
	a.round(hdc, p.line, padX, my, winW-padX*2, 8, 8)
	if lvl := a.meter; lvl > 0.005 {
		w := int(float64(winW-padX*2) * math.Min(1, lvl))
		col := p.accent
		if lvl > 0.92 {
			col = p.warn
		}
		a.round(hdc, col, padX, my, w, 8, 8)
	}
	stats := "No audio yet"
	if peer != "" {
		buf := a.eng.Buffer()
		und, drops := buf.Stats()
		stats = fmt.Sprintf("Buffer %.0f ms   ·   %.0f kbit/s   ·   dropouts %d   ·   catch-ups %d   ·   lost %d",
			buf.LevelMs(), a.kbps, und, drops, a.srv.Lost())
	}
	a.text(hdc, stats, a.fSmall, p.dim, padX, my+12, winW-padX*2, 20, dtSingleLine|dtVCenter)

	// Step 2 / status box
	by := boxY
	switch {
	case serverErr != "":
		a.round(hdc, p.badL, 14, by, winW-28, 66, 12)
		a.text(hdc, serverErr, a.fBody, p.bad, padX, by+8, winW-padX*2, 50, dtWordBreak|dtVCenter)
	case audioErr != "":
		a.round(hdc, p.badL, 14, by, winW-28, 66, 12)
		a.text(hdc, audioErr, a.fBody, p.bad, padX, by+8, winW-padX*2, 50, dtWordBreak)
	case virtual:
		a.round(hdc, p.accentL, 14, by, winW-28, 66, 12)
		a.text(hdc, "2   In Discord, Zoom, OBS or Windows settings, pick this mic:\n     CABLE Output (VB-Audio Virtual Cable)",
			a.fBody, p.text, padX, by+10, winW-padX*2, 48, dtWordBreak)
	default:
		a.round(hdc, p.warnL, 14, by, winW-28, 66, 12)
		a.text(hdc, "Test mode: playing to \""+devName+"\".\nInstall the free VB-Cable driver to use your phone as a real mic.",
			a.fSmall, p.warn, padX, by+8, winW-padX*2-160, 52, dtWordBreak|dtEndEllipsi)
		a.button(hdc, idGetVB, "Download VB-Cable", winW-padX-150, by+18, 150, 30, true)
	}
}

// ---------------------------------------------------------------- popup menus

// popup shows a menu under the given (96-DPI) point and returns the chosen index or -1.
func (a *App) popup(items []string, checked int, x, y int) int {
	hm, _, _ := procCreatePopupMenu.Call()
	for i, it := range items {
		flags := uintptr(0) // MF_STRING
		if i == checked {
			flags |= 0x8 // MF_CHECKED
		}
		procAppendMenuW.Call(hm, flags, uintptr(i+1), uintptr(unsafe.Pointer(u16(it))))
	}
	pt := [2]int32{a.S(x), a.S(y)}
	procClientToScreen.Call(a.hwnd, uintptr(unsafe.Pointer(&pt)))
	procSetForegroundWind.Call(a.hwnd)
	r, _, _ := procTrackPopupMenu.Call(hm, 0x0100|0x0080, uintptr(pt[0]), uintptr(pt[1]), 0, a.hwnd, 0) // TPM_RETURNCMD|TPM_NONOTIFY
	procDestroyMenu.Call(hm)
	return int(r) - 1
}

func (a *App) hitAt(px, py int32) int {
	x, y := int(px)*96/a.dpi, int(py)*96/a.dpi
	for _, h := range a.hits {
		if x >= h.x && x < h.x+h.w && y >= h.y && y < h.y+h.h {
			return h.id
		}
	}
	return 0
}

func (a *App) hitRect(id int) hitRect {
	for _, h := range a.hits {
		if h.id == id {
			return h
		}
	}
	return hitRect{}
}

func (a *App) onClick(id int) {
	r := a.hitRect(id)
	below := r.y + r.h + 2
	switch id {
	case idTheme:
		cur := 0
		for i, c := range themeChoices {
			if c.key == a.cfg.Theme {
				cur = i
			}
		}
		labels := make([]string, len(themeChoices))
		for i, c := range themeChoices {
			labels[i] = c.label
		}
		if i := a.popup(labels, cur, r.x, below); i >= 0 {
			a.cfg.Theme = themeChoices[i].key
			a.cfg.save()
			a.applyTheme()
		}
	case idAddress:
		cur := 0
		for i, ip := range a.ips {
			if ip == a.ip {
				cur = i
			}
		}
		if i := a.popup(a.ips, cur, r.x, below); i >= 0 {
			a.ip = a.ips[i]
			a.cfg.IP = a.ip
			a.cfg.save()
			a.makeQR()
		}
	case idDevice:
		curID := ""
		if a.deviceIdx >= 0 && a.deviceIdx < len(a.devices) {
			curID = a.devices[a.deviceIdx].ID
		}
		if devs, _, err := ListOutputDevices(); err == nil && len(devs) > 0 { // pick up newly added devices
			a.devices = devs
		}
		names := make([]string, len(a.devices))
		cur := -1
		for i, d := range a.devices {
			names[i] = d.Name
			if d.ID == curID {
				cur = i
			}
		}
		if i := a.popup(names, cur, r.x, below); i >= 0 {
			a.deviceIdx = i
			a.startAudio()
		} else {
			a.deviceIdx = cur
		}
	case idBuffer:
		labels := make([]string, len(bufferChoices))
		for i, c := range bufferChoices {
			labels[i] = c.label
		}
		if i := a.popup(labels, a.bufferIdx, r.x, below); i >= 0 {
			a.bufferIdx = i
			a.eng.SetTarget(bufferChoices[i].ms)
			a.cfg.BufferMs = bufferChoices[i].ms
			a.cfg.save()
		}
	case idGetVB:
		procShellExecuteW.Call(a.hwnd, uintptr(unsafe.Pointer(u16("open"))), uintptr(unsafe.Pointer(u16("https://vb-audio.com/Cable/"))), 0, 0, 1)
	case idCopy:
		copyToClipboard(a.hwnd, a.qrURL())
		a.copiedUntil = time.Now().Add(1500 * time.Millisecond)
	}
	procInvalidateRect.Call(a.hwnd, 0, 0)
}

// ---------------------------------------------------------------- events

func (a *App) onTimer() {
	pk := float64(a.eng.TakePeak())
	lvl := 0.0
	if pk > 0 {
		lvl = math.Max(0, (20*math.Log10(pk)+60)/60)
	}
	a.meter = math.Max(lvl, a.meter*0.82)
	if peer, _ := a.srv.PeerInfo(); peer == "" {
		a.meter = 0
	}
	if dt := time.Since(a.lastT).Seconds(); dt >= 1 {
		b := a.srv.BytesIn()
		a.kbps = float64(b-a.lastBytes) * 8 / 1000 / dt
		a.lastBytes, a.lastT = b, time.Now()
	}
	if !a.copiedUntil.IsZero() && time.Now().After(a.copiedUntil) {
		a.copiedUntil = time.Time{}
	}
	procInvalidateRect.Call(a.hwnd, 0, 0)
}

func wndProc(hwnd, msg, wParam, lParam uintptr) uintptr {
	a := app
	switch msg {
	case wmEraseBkgnd:
		return 1
	case wmPaint:
		var ps paintStruct
		hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		var rc rect
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		mem, _, _ := procCreateCompatibleDC.Call(hdc)
		bmp, _, _ := procCreateCompatibleBitmap.Call(hdc, uintptr(rc.R), uintptr(rc.B))
		old, _, _ := procSelectObject.Call(mem, bmp)
		a.paint(mem)
		procBitBlt.Call(hdc, 0, 0, uintptr(rc.R), uintptr(rc.B), mem, 0, 0, 0x00CC0020)
		procSelectObject.Call(mem, old)
		procDeleteObject.Call(bmp)
		procDeleteDC.Call(mem)
		procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case wmTimer:
		a.onTimer()
		return 0
	case wmMouseMove:
		h := a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		if !a.tracking {
			t := trackMouseEventT{dwFlags: 0x2, hwndTrack: hwnd} // TME_LEAVE
			t.cbSize = uint32(unsafe.Sizeof(t))
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&t)))
			a.tracking = true
		}
		if h != a.hover {
			a.hover = h
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case wmMouseLeave:
		a.tracking = false
		if a.hover != 0 {
			a.hover = 0
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case wmLButtonDown:
		a.pressed = a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		return 0
	case wmLButtonUp:
		h := a.hitAt(int32(int16(lParam)), int32(int16(lParam>>16)))
		if h != 0 && h == a.pressed {
			a.onClick(h)
		}
		a.pressed = 0
		return 0
	case wmSetCursor:
		if lParam&0xFFFF == 1 { // HTCLIENT
			if a.hover != 0 {
				procSetCursor.Call(a.cursorHand)
			} else {
				procSetCursor.Call(a.cursorArrow)
			}
			return 1
		}
	case wmSettingChange:
		if a.cfg.Theme == "auto" {
			a.applyTheme()
		}
	case wmApp:
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case wmDestroy:
		procKillTimer.Call(hwnd, 1)
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, msg, wParam, lParam)
	return r
}

// ---------------------------------------------------------------- clipboard

var (
	procOpenClipboard    = user32.NewProc("OpenClipboard")
	procEmptyClipboard   = user32.NewProc("EmptyClipboard")
	procSetClipboardData = user32.NewProc("SetClipboardData")
	procCloseClipboard   = user32.NewProc("CloseClipboard")
	procGlobalAlloc      = kernel32.NewProc("GlobalAlloc")
	procGlobalLock       = kernel32.NewProc("GlobalLock")
	procGlobalUnlock     = kernel32.NewProc("GlobalUnlock")
)

func copyToClipboard(hwnd uintptr, s string) {
	p, _ := syscall.UTF16FromString(s)
	if r, _, _ := procOpenClipboard.Call(hwnd); r == 0 {
		return
	}
	defer procCloseClipboard.Call()
	procEmptyClipboard.Call()
	h, _, _ := procGlobalAlloc.Call(0x0002, uintptr(len(p)*2)) // GMEM_MOVEABLE
	if h == 0 {
		return
	}
	dst, _, _ := procGlobalLock.Call(h)
	copy(unsafe.Slice((*uint16)(unsafe.Pointer(dst)), len(p)), p)
	procGlobalUnlock.Call(h)
	procSetClipboardData.Call(13, h) // CF_UNICODETEXT
}
