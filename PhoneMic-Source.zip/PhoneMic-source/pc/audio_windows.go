//go:build windows

// Low-latency audio output through WASAPI (shared mode, event driven),
// called directly via COM vtables - no external libraries or DLLs needed.
package main

import (
	"errors"
	"fmt"
	"math"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

var (
	ole32                = syscall.NewLazyDLL("ole32.dll")
	procCoInitializeEx   = ole32.NewProc("CoInitializeEx")
	procCoUninitialize   = ole32.NewProc("CoUninitialize")
	procCoCreateInstance = ole32.NewProc("CoCreateInstance")
	procCoTaskMemFree    = ole32.NewProc("CoTaskMemFree")
	procPropVariantClear = ole32.NewProc("PropVariantClear")

	kernel32                = syscall.NewLazyDLL("kernel32.dll")
	procCreateEventW        = kernel32.NewProc("CreateEventW")
	procWaitForSingleObject = kernel32.NewProc("WaitForSingleObject")
	procCloseHandle         = kernel32.NewProc("CloseHandle")

	avrt                         = syscall.NewLazyDLL("avrt.dll")
	procAvSetMmThreadCharacteris = avrt.NewProc("AvSetMmThreadCharacteristicsW")
	procAvRevertMmThreadCharacte = avrt.NewProc("AvRevertMmThreadCharacteristics")
)

type GUID struct {
	Data1        uint32
	Data2, Data3 uint16
	Data4        [8]byte
}

func mustGUID(s string) *GUID {
	var g GUID
	var d4 [8]uint32
	_, err := fmt.Sscanf(s, "%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x",
		&g.Data1, &g.Data2, &g.Data3, &d4[0], &d4[1], &d4[2], &d4[3], &d4[4], &d4[5], &d4[6], &d4[7])
	if err != nil {
		panic(err)
	}
	for i, v := range d4 {
		g.Data4[i] = byte(v)
	}
	return &g
}

type propertyKey struct {
	fmtid GUID
	pid   uint32
}

type propVariant struct {
	vt       uint16
	_        [3]uint16
	val      uintptr
	_reserve uintptr
}

var (
	clsidMMDeviceEnumerator = mustGUID("bcde0395-e52f-467c-8e3d-c4579291692e")
	iidIMMDeviceEnumerator  = mustGUID("a95664d2-9614-4f35-a746-de8db63617e6")
	iidIAudioClient         = mustGUID("1cb9ad4c-dbfa-4c32-b178-c2f568a703b2")
	iidIAudioRenderClient   = mustGUID("f294acfc-3146-4483-a7bf-addca7c260e2")
	subtypeIEEEFloat        = mustGUID("00000003-0000-0010-8000-00aa00389b71")
	pkeyFriendlyName        = &propertyKey{*mustGUID("a45c254e-df1c-4efd-8020-67d146a850e0"), 14}
)

const (
	clsctxAll         = 0x17
	eRender           = 0
	eConsole          = 0
	deviceStateActive = 1
	streamFlagsEvent  = 0x00040000
	bufferFlagsSilent = 2
)

// vt returns method #idx from a COM object's vtable.
func vt(obj uintptr, idx int) uintptr {
	vtbl := *(*uintptr)(unsafe.Pointer(obj))
	return *(*uintptr)(unsafe.Pointer(vtbl + uintptr(idx)*unsafe.Sizeof(uintptr(0))))
}

func release(obj uintptr) {
	if obj != 0 {
		syscall.SyscallN(vt(obj, 2), obj)
	}
}

func hresult(r uintptr, what string) error {
	if int32(r) < 0 {
		return fmt.Errorf("%s failed (0x%08X)", what, uint32(r))
	}
	return nil
}

func wstr(p uintptr) string {
	if p == 0 {
		return ""
	}
	var s []uint16
	for i := uintptr(0); ; i += 2 {
		c := *(*uint16)(unsafe.Pointer(p + i))
		if c == 0 {
			break
		}
		s = append(s, c)
	}
	return syscall.UTF16ToString(s)
}

func newEnumerator() (uintptr, error) {
	var en uintptr
	r, _, _ := procCoCreateInstance.Call(uintptr(unsafe.Pointer(clsidMMDeviceEnumerator)), 0, clsctxAll,
		uintptr(unsafe.Pointer(iidIMMDeviceEnumerator)), uintptr(unsafe.Pointer(&en)))
	return en, hresult(r, "CoCreateInstance(MMDeviceEnumerator)")
}

func deviceID(dev uintptr) string {
	var p uintptr
	if r, _, _ := syscall.SyscallN(vt(dev, 5), dev, uintptr(unsafe.Pointer(&p))); int32(r) < 0 {
		return ""
	}
	s := wstr(p)
	procCoTaskMemFree.Call(p)
	return s
}

func friendlyName(dev uintptr) string {
	var store uintptr
	if r, _, _ := syscall.SyscallN(vt(dev, 4), dev, 0, uintptr(unsafe.Pointer(&store))); int32(r) < 0 {
		return "Unknown device"
	}
	defer release(store)
	pv := new(propVariant)
	name := "Unknown device"
	if r, _, _ := syscall.SyscallN(vt(store, 5), store, uintptr(unsafe.Pointer(pkeyFriendlyName)), uintptr(unsafe.Pointer(pv))); int32(r) >= 0 {
		if pv.vt == 31 { // VT_LPWSTR
			name = wstr(pv.val)
		}
		procPropVariantClear.Call(uintptr(unsafe.Pointer(pv)))
	}
	return name
}

type AudioDevice struct{ ID, Name string }

func IsVirtualCable(name string) bool {
	n := strings.ToLower(name)
	for _, h := range []string{"cable input", "vb-audio", "voicemeeter", "virtual audio cable", "line 1 (virtual"} {
		if strings.Contains(n, h) {
			return true
		}
	}
	return false
}

// ListOutputDevices returns active playback devices and the default device's ID.
// The calling thread must have COM initialised.
func ListOutputDevices() ([]AudioDevice, string, error) {
	en, err := newEnumerator()
	if err != nil {
		return nil, "", err
	}
	defer release(en)
	var coll uintptr
	r, _, _ := syscall.SyscallN(vt(en, 3), en, eRender, deviceStateActive, uintptr(unsafe.Pointer(&coll)))
	if err := hresult(r, "EnumAudioEndpoints"); err != nil {
		return nil, "", err
	}
	defer release(coll)
	var count uint32
	syscall.SyscallN(vt(coll, 3), coll, uintptr(unsafe.Pointer(&count)))
	var out []AudioDevice
	for i := uint32(0); i < count; i++ {
		var dev uintptr
		if r, _, _ := syscall.SyscallN(vt(coll, 4), coll, uintptr(i), uintptr(unsafe.Pointer(&dev))); int32(r) < 0 {
			continue
		}
		out = append(out, AudioDevice{ID: deviceID(dev), Name: friendlyName(dev)})
		release(dev)
	}
	def := ""
	var dev uintptr
	if r, _, _ := syscall.SyscallN(vt(en, 4), en, eRender, eConsole, uintptr(unsafe.Pointer(&dev))); int32(r) >= 0 {
		def = deviceID(dev)
		release(dev)
	}
	return out, def, nil
}

// Renderer plays the engine's jitter buffer to one output device.
type Renderer struct {
	stop chan struct{}
	done chan struct{}
}

func StartRenderer(id string, eng *Engine) (*Renderer, error) {
	r := &Renderer{stop: make(chan struct{}), done: make(chan struct{})}
	ready := make(chan error, 1)
	go r.run(id, eng, ready)
	if err := <-ready; err != nil {
		<-r.done
		return nil, err
	}
	return r, nil
}

func (r *Renderer) Stop() {
	if r == nil {
		return
	}
	close(r.stop)
	<-r.done
}

type sampleKind int

const (
	kindFloat32 sampleKind = iota
	kindInt16
	kindInt24
	kindInt32
)

func (r *Renderer) run(id string, eng *Engine, ready chan<- error) {
	defer close(r.done)
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	procCoInitializeEx.Call(0, 0) // multithreaded apartment
	defer procCoUninitialize.Call()

	started := false
	fail := func(err error) {
		if !started {
			ready <- err
		} else {
			eng.SetAudioError(err.Error())
		}
	}

	en, err := newEnumerator()
	if err != nil {
		fail(err)
		return
	}
	defer release(en)

	var dev uintptr
	var hr uintptr
	if id == "" {
		hr, _, _ = syscall.SyscallN(vt(en, 4), en, eRender, eConsole, uintptr(unsafe.Pointer(&dev)))
	} else {
		idp, _ := syscall.UTF16PtrFromString(id)
		hr, _, _ = syscall.SyscallN(vt(en, 5), en, uintptr(unsafe.Pointer(idp)), uintptr(unsafe.Pointer(&dev)))
	}
	if err := hresult(hr, "Open audio device"); err != nil {
		fail(err)
		return
	}
	defer release(dev)
	name := friendlyName(dev)

	var client uintptr
	hr, _, _ = syscall.SyscallN(vt(dev, 3), dev, uintptr(unsafe.Pointer(iidIAudioClient)), clsctxAll, 0, uintptr(unsafe.Pointer(&client)))
	if err := hresult(hr, "Activate IAudioClient"); err != nil {
		fail(err)
		return
	}
	defer release(client)

	var wfx uintptr
	hr, _, _ = syscall.SyscallN(vt(client, 8), client, uintptr(unsafe.Pointer(&wfx)))
	if err := hresult(hr, "GetMixFormat"); err != nil {
		fail(err)
		return
	}
	defer procCoTaskMemFree.Call(wfx)
	tag := *(*uint16)(unsafe.Pointer(wfx))
	channels := int(*(*uint16)(unsafe.Pointer(wfx + 2)))
	rate := int(*(*uint32)(unsafe.Pointer(wfx + 4)))
	blockAlign := int(*(*uint16)(unsafe.Pointer(wfx + 12)))
	bits := *(*uint16)(unsafe.Pointer(wfx + 14))
	isFloat := tag == 3 || (tag == 0xFFFE && *(*GUID)(unsafe.Pointer(wfx + 24)) == *subtypeIEEEFloat)
	var kind sampleKind
	switch {
	case isFloat && bits == 32:
		kind = kindFloat32
	case !isFloat && bits == 16:
		kind = kindInt16
	case !isFloat && bits == 24:
		kind = kindInt24
	case !isFloat && bits == 32:
		kind = kindInt32
	default:
		fail(fmt.Errorf("unsupported device format (%d-bit)", bits))
		return
	}

	hr, _, _ = syscall.SyscallN(vt(client, 3), client, 0, streamFlagsEvent, 0, 0, wfx, 0)
	if err := hresult(hr, "IAudioClient.Initialize"); err != nil {
		fail(err)
		return
	}
	event, _, _ := procCreateEventW.Call(0, 0, 0, 0)
	if event == 0 {
		fail(errors.New("CreateEvent failed"))
		return
	}
	defer procCloseHandle.Call(event)
	syscall.SyscallN(vt(client, 13), client, event)

	var bufFrames uint32
	syscall.SyscallN(vt(client, 4), client, uintptr(unsafe.Pointer(&bufFrames)))
	var render uintptr
	hr, _, _ = syscall.SyscallN(vt(client, 14), client, uintptr(unsafe.Pointer(iidIAudioRenderClient)), uintptr(unsafe.Pointer(&render)))
	if err := hresult(hr, "GetService(IAudioRenderClient)"); err != nil {
		fail(err)
		return
	}
	defer release(render)

	var streamLat int64
	syscall.SyscallN(vt(client, 5), client, uintptr(unsafe.Pointer(&streamLat)))
	eng.outLatencyUs.Store(streamLat/10 + int64(bufFrames)*1_000_000/int64(rate))
	eng.Configure(rate, name, IsVirtualCable(name))

	// Start with one buffer of silence so the first period doesn't glitch.
	var data uintptr
	if r, _, _ := syscall.SyscallN(vt(render, 3), render, uintptr(bufFrames), uintptr(unsafe.Pointer(&data))); int32(r) >= 0 {
		syscall.SyscallN(vt(render, 4), render, uintptr(bufFrames), bufferFlagsSilent)
	}

	if procAvSetMmThreadCharacteris.Find() == nil {
		task, _ := syscall.UTF16PtrFromString("Pro Audio")
		var idx uint32
		h, _, _ := procAvSetMmThreadCharacteris.Call(uintptr(unsafe.Pointer(task)), uintptr(unsafe.Pointer(&idx)))
		if h != 0 {
			defer procAvRevertMmThreadCharacte.Call(h)
		}
	}

	hr, _, _ = syscall.SyscallN(vt(client, 10), client)
	if err := hresult(hr, "IAudioClient.Start"); err != nil {
		fail(err)
		return
	}
	defer syscall.SyscallN(vt(client, 11), client)
	started = true
	ready <- nil

	mono := make([]float32, bufFrames)
	var padding uint32
	for {
		select {
		case <-r.stop:
			return
		default:
		}
		procWaitForSingleObject.Call(event, 200)
		hr, _, _ = syscall.SyscallN(vt(client, 6), client, uintptr(unsafe.Pointer(&padding)))
		if int32(hr) < 0 {
			fail(errors.New("audio device was disconnected - pick it again"))
			return
		}
		avail := int(bufFrames - padding)
		if avail <= 0 {
			continue
		}
		hr, _, _ = syscall.SyscallN(vt(render, 3), render, uintptr(avail), uintptr(unsafe.Pointer(&data)))
		if int32(hr) < 0 {
			continue
		}
		eng.Buffer().Read(mono[:avail])
		out := unsafe.Slice((*byte)(unsafe.Pointer(data)), avail*blockAlign)
		writeFrames(out, mono[:avail], channels, blockAlign, kind)
		syscall.SyscallN(vt(render, 4), render, uintptr(avail), 0)
	}
}

func writeFrames(out []byte, mono []float32, channels, blockAlign int, kind sampleKind) {
	bps := blockAlign / channels
	for i, v := range mono {
		if v > 1 {
			v = 1
		} else if v < -1 {
			v = -1
		}
		frame := out[i*blockAlign:]
		for c := 0; c < channels; c++ {
			p := frame[c*bps:]
			switch kind {
			case kindFloat32:
				b := math.Float32bits(v)
				p[0], p[1], p[2], p[3] = byte(b), byte(b>>8), byte(b>>16), byte(b>>24)
			case kindInt16:
				s := int16(v * 32767)
				p[0], p[1] = byte(s), byte(s>>8)
			case kindInt24:
				s := int32(v * 8388607)
				p[0], p[1], p[2] = byte(s), byte(s>>8), byte(s>>16)
			case kindInt32:
				s := int32(float64(v) * 2147483647)
				p[0], p[1], p[2], p[3] = byte(s), byte(s>>8), byte(s>>16), byte(s>>24)
			}
		}
	}
}
