package main

import (
	"math"
	"testing"
)

func TestResampler(t *testing.T) {
	r := NewResampler(44100, 48000)
	var out []float32
	x := make([]float32, 44100)
	for i := range x {
		x[i] = float32(math.Sin(2 * math.Pi * 1000 * float64(i) / 44100))
	}
	for i := 0; i < len(x); i += 256 {
		e := i + 256
		if e > len(x) {
			e = len(x)
		}
		out = append(out, r.Process(x[i:e])...)
	}
	maxErr := 0.0
	for i, v := range out {
		want := math.Sin(2 * math.Pi * 1000 * float64(i) / 48000)
		maxErr = math.Max(maxErr, math.Abs(float64(v)-want))
	}
	t.Logf("len=%d maxErr=%.4f", len(out), maxErr)
	if len(out) < 47990 || len(out) > 48010 || maxErr > 0.01 {
		t.Fatal("bad resample")
	}
}

func TestBurst(t *testing.T) {
	j := NewJitterBuffer(48000, 30, 80)
	j.Write(make([]float32, 9600))
	if l := j.LevelMs(); l != 30 {
		t.Fatal(l)
	}
	j = NewJitterBuffer(48000, 30, 80)
	for i := 0; i < 40; i++ {
		j.Write(make([]float32, 256))
	}
	if l := j.LevelMs(); l > 80 {
		t.Fatal(l)
	}
}
