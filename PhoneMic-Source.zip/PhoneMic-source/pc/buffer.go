package main

import (
	"math"
	"sync"
	"sync/atomic"
)

// JitterBuffer is a small mono ring buffer that never lets delay pile up.
//   - It waits until `target` samples are queued before playing (absorbs Wi-Fi jitter).
//   - If more than `maximum` samples pile up (a Wi-Fi burst), it skips ahead to
//     `target` so the delay snaps back down instead of growing.
type JitterBuffer struct {
	mu        sync.Mutex
	rate      int
	buf       []float32
	r, w, n   int
	target    int
	maximum   int
	primed    bool
	underruns int64
	drops     int64
}

func NewJitterBuffer(rate int, targetMs, maxMs float64) *JitterBuffer {
	size := rate * 2
	target := int(float64(rate) * targetMs / 1000)
	if target < 1 {
		target = 1
	}
	maximum := int(float64(rate) * maxMs / 1000)
	if maximum <= target {
		maximum = target + 1
	}
	if maximum > size/2 {
		maximum = size / 2
	}
	return &JitterBuffer{rate: rate, buf: make([]float32, size), target: target, maximum: maximum}
}

func (j *JitterBuffer) Reset() {
	j.mu.Lock()
	j.r, j.w, j.n, j.primed = 0, 0, 0, false
	j.underruns, j.drops = 0, 0
	j.mu.Unlock()
}

func (j *JitterBuffer) LevelMs() float64 {
	j.mu.Lock()
	defer j.mu.Unlock()
	return float64(j.n) * 1000 / float64(j.rate)
}

func (j *JitterBuffer) Stats() (underruns, drops int64) {
	j.mu.Lock()
	defer j.mu.Unlock()
	return j.underruns, j.drops
}

func (j *JitterBuffer) Write(x []float32) {
	if len(x) == 0 {
		return
	}
	j.mu.Lock()
	defer j.mu.Unlock()
	if len(x) > j.maximum { // one giant burst: keep only the newest audio
		x = x[len(x)-j.target:]
		j.r, j.w, j.n = 0, 0, 0
		j.drops++
	}
	size := len(j.buf)
	k := copy(j.buf[j.w:], x)
	if k < len(x) {
		copy(j.buf, x[k:])
	}
	j.w = (j.w + len(x)) % size
	j.n += len(x)
	if j.n > j.maximum { // too far behind -> jump forward
		skip := j.n - j.target
		j.r = (j.r + skip) % size
		j.n -= skip
		j.drops++
	}
}

// Read fills out with audio, or silence when there is nothing to play.
func (j *JitterBuffer) Read(out []float32) {
	j.mu.Lock()
	defer j.mu.Unlock()
	if !j.primed {
		if j.n >= j.target {
			j.primed = true
		} else {
			clear(out)
			return
		}
	}
	m := len(out)
	if m > j.n {
		m = j.n
	}
	k := copy(out[:m], j.buf[j.r:])
	if k < m {
		copy(out[k:m], j.buf)
	}
	j.r = (j.r + m) % len(j.buf)
	j.n -= m
	if m < len(out) {
		clear(out[m:])
		j.primed = false // re-prime so we don't stutter sample-by-sample
		j.underruns++
	}
}

// Resampler is a streaming linear resampler, used only if phone and PC rates differ.
type Resampler struct {
	step float64
	pos  float64
	last float32
	src  int
	dst  int
}

func NewResampler(src, dst int) *Resampler {
	return &Resampler{step: float64(src) / float64(dst), pos: 1, src: src, dst: dst}
}

func (r *Resampler) Process(x []float32) []float32 {
	n := len(x)
	if n == 0 {
		return x
	}
	at := func(i int) float32 { // y[0] = previous chunk's last sample, y[i] = x[i-1]
		if i == 0 {
			return r.last
		}
		return x[i-1]
	}
	out := make([]float32, 0, int(float64(n)/r.step)+2)
	p := r.pos
	for p <= float64(n) {
		i := int(p)
		f := float32(p - float64(i))
		if i >= n {
			out = append(out, at(n))
		} else {
			out = append(out, at(i)+(at(i+1)-at(i))*f)
		}
		p += r.step
	}
	r.pos = p - float64(n)
	r.last = x[n-1]
	return out
}

// Engine is the shared state between the network side and the audio output.
type Engine struct {
	mu       sync.Mutex
	rate     int
	targetMs float64
	buf      *JitterBuffer
	device   string
	virtual  bool
	audioErr string

	outLatencyUs atomic.Int64
	peakBits     atomic.Uint32
}

func NewEngine(targetMs float64) *Engine {
	e := &Engine{rate: 48000, targetMs: targetMs}
	e.buf = NewJitterBuffer(e.rate, targetMs, targetMs+50)
	return e
}

func (e *Engine) Configure(rate int, device string, virtual bool) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if rate != e.rate {
		e.rate = rate
		e.buf = NewJitterBuffer(rate, e.targetMs, e.targetMs+50)
	}
	e.device, e.virtual, e.audioErr = device, virtual, ""
}

func (e *Engine) SetTarget(ms float64) {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.targetMs = ms
	e.buf = NewJitterBuffer(e.rate, ms, ms+50)
}

func (e *Engine) SetAudioError(msg string) {
	e.mu.Lock()
	e.audioErr = msg
	e.mu.Unlock()
}

func (e *Engine) Snapshot() (rate int, device string, virtual bool, targetMs float64, audioErr string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.rate, e.device, e.virtual, e.targetMs, e.audioErr
}

func (e *Engine) Buffer() *JitterBuffer {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.buf
}

func (e *Engine) Rate() int {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.rate
}

func (e *Engine) OutLatencyMs() float64 { return float64(e.outLatencyUs.Load()) / 1000 }

func (e *Engine) notePeak(p float32) {
	if p > math.Float32frombits(e.peakBits.Load()) {
		e.peakBits.Store(math.Float32bits(p))
	}
}

// TakePeak returns the loudest sample since the last call (for the level meter).
func (e *Engine) TakePeak() float32 { return math.Float32frombits(e.peakBits.Swap(0)) }
