package main

// UDP protocol used by the PhoneMic Android app (lower delay than the browser path:
// no TLS, no TCP retransmission stalls). All integers are little-endian.
//
//   every packet:  "PMIC" (4 bytes) + type (1 byte) + body
//   1 DISCOVER  phone -> broadcast        (empty)
//   2 OFFER     PC -> phone               JSON {"name","rate","port","version","device"}
//   3 HELLO     phone -> PC               JSON {"session","rate","name"}
//   4 WELCOME   PC -> phone               JSON {"name","rate","device","virtual"}
//   5 AUDIO     phone -> PC               session u32 + seq u32 + int16 mono PCM
//   6 PING      phone -> PC               session u32 + t f64 (phone clock, ms)
//   7 KICK      PC -> phone               another phone took over
//   8 PONG      PC -> phone               t f64 + buffer f32 + output f32 + underruns u32 + drops u32 + lost u32
//   9 BYE       phone -> PC               session u32
//  10 REHELLO   PC -> phone               PC doesn't know this session (e.g. it restarted)

import (
	"encoding/binary"
	"encoding/json"
	"math"
	"net"
	"os"
	"time"
)

const (
	pktDiscover = 1
	pktOffer    = 2
	pktHello    = 3
	pktWelcome  = 4
	pktAudio    = 5
	pktPing     = 6
	pktKick     = 7
	pktPong     = 8
	pktBye      = 9
	pktRehello  = 10

	UDPPortOffset = 1 // UDP port = HTTPS port + 1 (8444 by default)
)

var magic = []byte("PMIC")

type udpPeer struct {
	addr     *net.UDPAddr
	session  uint32
	name     string
	lastSeen time.Time
	lastSeq  uint32
	gotSeq   bool
	in       ingester
}

func (s *Server) UDPPort() int { return s.port + UDPPortOffset }

func (s *Server) sendUDP(addr *net.UDPAddr, typ byte, body []byte) {
	if s.udpConn == nil || addr == nil {
		return
	}
	pkt := make([]byte, 0, 5+len(body))
	pkt = append(pkt, magic...)
	pkt = append(pkt, typ)
	pkt = append(pkt, body...)
	s.udpConn.WriteToUDP(pkt, addr)
}

func (s *Server) startUDP() error {
	conn, err := net.ListenUDP("udp4", &net.UDPAddr{Port: s.UDPPort()})
	if err != nil {
		return err
	}
	conn.SetReadBuffer(1 << 20)
	s.udpConn = conn
	go s.udpLoop()
	return nil
}

func hostName() string {
	h, err := os.Hostname()
	if err != nil || h == "" {
		return "PC"
	}
	return h
}

func (s *Server) udpLoop() {
	buf := make([]byte, 65536)
	lastRehello := map[string]time.Time{}
	for {
		s.udpConn.SetReadDeadline(time.Now().Add(500 * time.Millisecond))
		n, addr, err := s.udpConn.ReadFromUDP(buf)
		s.udpTimeoutCheck()
		if err != nil {
			continue // timeouts, and Windows' spurious "connection reset" on UDP
		}
		if n < 5 || string(buf[:4]) != "PMIC" {
			continue
		}
		typ, body := buf[4], buf[5:n]
		switch typ {
		case pktDiscover:
			rate, device, virtual, _, _ := s.eng.Snapshot()
			reply, _ := json.Marshal(map[string]any{"name": hostName(), "rate": rate, "port": s.UDPPort(),
				"version": 1, "device": device, "virtual": virtual})
			s.sendUDP(addr, pktOffer, reply)

		case pktHello:
			var m struct {
				Session uint32 `json:"session"`
				Rate    int    `json:"rate"`
				Name    string `json:"name"`
			}
			if json.Unmarshal(body, &m) != nil || m.Session == 0 {
				continue
			}
			s.mu.Lock()
			cur := s.udp
			s.mu.Unlock()
			if cur != nil && cur.session == m.Session {
				cur.addr, cur.lastSeen = addr, time.Now() // repeated hello (e.g. phone changed IP)
			} else {
				p := &udpPeer{addr: addr, session: m.Session, name: m.Name, lastSeen: time.Now()}
				p.in = ingester{clientRate: m.Rate, samples: make([]float32, 0, 2048)}
				label := addr.IP.String()
				if m.Name != "" {
					label = m.Name + "  " + label
				}
				s.claim(p, label, "app")
			}
			rate, device, virtual, _, _ := s.eng.Snapshot()
			reply, _ := json.Marshal(map[string]any{"name": hostName(), "rate": rate, "device": device, "virtual": virtual})
			s.sendUDP(addr, pktWelcome, reply)

		case pktAudio, pktPing, pktBye:
			if len(body) < 4 {
				continue
			}
			session := binary.LittleEndian.Uint32(body)
			s.mu.Lock()
			p := s.udp
			active := p != nil && p.session == session
			s.mu.Unlock()
			if !active {
				if typ != pktBye && time.Since(lastRehello[addr.String()]) > 500*time.Millisecond {
					lastRehello[addr.String()] = time.Now()
					s.sendUDP(addr, pktRehello, nil)
				}
				continue
			}
			p.lastSeen = time.Now()
			p.addr = addr
			switch typ {
			case pktAudio:
				if len(body) < 8 {
					continue
				}
				seq := binary.LittleEndian.Uint32(body[4:])
				if p.gotSeq {
					d := int32(seq - p.lastSeq)
					if d <= 0 {
						continue // late or duplicate packet: playing it now would only add delay
					}
					if d > 1 {
						s.lost.Add(int64(d - 1))
					}
				}
				p.lastSeq, p.gotSeq = seq, true
				s.ingest(&p.in, body[8:])
			case pktPing:
				if len(body) < 12 {
					continue
				}
				buf := s.eng.Buffer()
				und, drops := buf.Stats()
				out := make([]byte, 0, 28)
				out = append(out, body[4:12]...) // echo phone timestamp
				out = binary.LittleEndian.AppendUint32(out, math.Float32bits(float32(buf.LevelMs())))
				out = binary.LittleEndian.AppendUint32(out, math.Float32bits(float32(s.eng.OutLatencyMs())))
				out = binary.LittleEndian.AppendUint32(out, uint32(und))
				out = binary.LittleEndian.AppendUint32(out, uint32(drops))
				out = binary.LittleEndian.AppendUint32(out, uint32(s.lost.Load()))
				s.sendUDP(addr, pktPong, out)
			case pktBye:
				s.dropUDP(p)
			}
		}
	}
}

func (s *Server) dropUDP(p *udpPeer) {
	s.mu.Lock()
	if s.udp == p {
		s.udp, s.peer, s.peerVia = nil, "", ""
		s.eng.Buffer().Reset()
	}
	s.mu.Unlock()
}

// udpTimeoutCheck forgets an app connection that has gone quiet (phone left Wi-Fi, app killed).
func (s *Server) udpTimeoutCheck() {
	s.mu.Lock()
	p := s.udp
	s.mu.Unlock()
	if p != nil && time.Since(p.lastSeen) > 4*time.Second {
		s.dropUDP(p)
	}
}
