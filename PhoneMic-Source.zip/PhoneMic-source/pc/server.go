package main

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha1"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	_ "embed"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed web/index.html
var indexHTML []byte

//go:embed web/PhoneMic.apk
var apkFile []byte

// ---------------------------------------------------------------- WebSocket

type wsConn struct {
	conn net.Conn
	br   *bufio.Reader
	wmu  sync.Mutex
}

func wsUpgrade(w http.ResponseWriter, r *http.Request) (*wsConn, error) {
	if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
		http.Error(w, "websocket only", http.StatusBadRequest)
		return nil, errors.New("not a websocket request")
	}
	key := r.Header.Get("Sec-WebSocket-Key")
	h := sha1.Sum([]byte(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
	hj, ok := w.(http.Hijacker)
	if !ok {
		return nil, errors.New("hijack unsupported")
	}
	conn, brw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	if tc, ok := conn.(*tls.Conn); ok {
		if raw, ok := tc.NetConn().(*net.TCPConn); ok {
			raw.SetNoDelay(true)
		}
	}
	conn.SetDeadline(time.Time{})
	brw.WriteString("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: " + base64.StdEncoding.EncodeToString(h[:]) + "\r\n\r\n")
	if err := brw.Flush(); err != nil {
		conn.Close()
		return nil, err
	}
	return &wsConn{conn: conn, br: brw.Reader}, nil
}

func (c *wsConn) writeFrame(op byte, payload []byte) error {
	c.wmu.Lock()
	defer c.wmu.Unlock()
	hdr := make([]byte, 0, 10)
	hdr = append(hdr, 0x80|op)
	switch n := len(payload); {
	case n < 126:
		hdr = append(hdr, byte(n))
	case n <= 0xFFFF:
		hdr = append(hdr, 126, byte(n>>8), byte(n))
	default:
		hdr = append(hdr, 127)
		hdr = binary.BigEndian.AppendUint64(hdr, uint64(n))
	}
	c.conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
	_, err := c.conn.Write(append(hdr, payload...))
	return err
}

func (c *wsConn) closeWith(code uint16, reason string) {
	p := binary.BigEndian.AppendUint16(nil, code)
	c.writeFrame(8, append(p, reason...))
	c.conn.Close()
}

// readMessage returns the next text (1) or binary (2) message, answering pings itself.
func (c *wsConn) readMessage() (byte, []byte, error) {
	var msg []byte
	var msgOp byte
	var hdr [2]byte
	for {
		c.conn.SetReadDeadline(time.Now().Add(15 * time.Second))
		if _, err := io.ReadFull(c.br, hdr[:]); err != nil {
			return 0, nil, err
		}
		fin, op := hdr[0]&0x80 != 0, hdr[0]&0x0F
		masked, n := hdr[1]&0x80 != 0, uint64(hdr[1]&0x7F)
		switch n {
		case 126:
			var b [2]byte
			if _, err := io.ReadFull(c.br, b[:]); err != nil {
				return 0, nil, err
			}
			n = uint64(binary.BigEndian.Uint16(b[:]))
		case 127:
			var b [8]byte
			if _, err := io.ReadFull(c.br, b[:]); err != nil {
				return 0, nil, err
			}
			n = binary.BigEndian.Uint64(b[:])
		}
		if n > 1<<20 {
			return 0, nil, errors.New("frame too large")
		}
		var mask [4]byte
		if masked {
			if _, err := io.ReadFull(c.br, mask[:]); err != nil {
				return 0, nil, err
			}
		}
		payload := make([]byte, n)
		if _, err := io.ReadFull(c.br, payload); err != nil {
			return 0, nil, err
		}
		if masked {
			for i := range payload {
				payload[i] ^= mask[i&3]
			}
		}
		switch op {
		case 8: // close
			c.writeFrame(8, nil)
			return 8, payload, io.EOF
		case 9: // ping
			c.writeFrame(10, payload)
			continue
		case 10: // pong
			continue
		case 0: // continuation
			msg = append(msg, payload...)
		default:
			msgOp, msg = op, payload
		}
		if fin {
			return msgOp, msg, nil
		}
	}
}

// ---------------------------------------------------------------- Server

type Server struct {
	eng     *Engine
	port    int
	mu      sync.Mutex
	client  *wsConn
	peer    string
	peerVia string
	udp     *udpPeer
	udpConn *net.UDPConn
	bytesIn atomic.Int64
	lost    atomic.Int64
}

// ingester converts raw int16 PCM from a phone into the engine's buffer.
type ingester struct {
	clientRate int
	rs         *Resampler
	samples    []float32
}

func (s *Server) ingest(in *ingester, data []byte) {
	s.bytesIn.Add(int64(len(data)))
	in.samples = in.samples[:0]
	var peak float32
	for i := 0; i+1 < len(data); i += 2 {
		v := float32(int16(binary.LittleEndian.Uint16(data[i:]))) / 32768
		in.samples = append(in.samples, v)
		if v < 0 {
			v = -v
		}
		if v > peak {
			peak = v
		}
	}
	s.eng.notePeak(peak)
	out := in.samples
	if dst := s.eng.Rate(); in.clientRate != 0 && in.clientRate != dst {
		if in.rs == nil || in.rs.src != in.clientRate || in.rs.dst != dst {
			in.rs = NewResampler(in.clientRate, dst)
		}
		out = in.rs.Process(in.samples)
	}
	s.eng.Buffer().Write(out)
}

// claim makes src (a *wsConn or *udpPeer) the active phone, kicking any previous one.
func (s *Server) claim(src any, peer, via string) {
	s.mu.Lock()
	oldWS, oldUDP := s.client, s.udp
	s.client, s.udp = nil, nil
	switch v := src.(type) {
	case *wsConn:
		s.client = v
	case *udpPeer:
		s.udp = v
	}
	s.peer, s.peerVia = peer, via
	s.lost.Store(0)
	s.mu.Unlock()
	if oldWS != nil && any(oldWS) != src {
		oldWS.closeWith(4000, "Another phone connected")
	}
	if oldUDP != nil && any(oldUDP) != src {
		s.sendUDP(oldUDP.addr, pktKick, nil)
	}
	s.eng.Buffer().Reset()
}

// PeerInfo describes the connected phone for the UI: name/address and "app" or "browser".
func (s *Server) PeerInfo() (peer, via string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.peer, s.peerVia
}

func (s *Server) Lost() int64 { return s.lost.Load() }

func NewServer(eng *Engine, port int) *Server { return &Server{eng: eng, port: port} }

// Peer returns the connected phone's address, or "" if none.
func (s *Server) Peer() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.peer
}

func (s *Server) BytesIn() int64 { return s.bytesIn.Load() }

func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Write(indexHTML)
}

func (s *Server) handleAPK(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/vnd.android.package-archive")
	w.Header().Set("Content-Disposition", `attachment; filename="PhoneMic.apk"`)
	w.Write(apkFile)
}

func (s *Server) handleConfig(w http.ResponseWriter, r *http.Request) {
	rate, device, virtual, target, _ := s.eng.Snapshot()
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(map[string]any{"rate": rate, "device": device, "virtual": virtual, "target_ms": target})
}

func (s *Server) handleWS(w http.ResponseWriter, r *http.Request) {
	ws, err := wsUpgrade(w, r)
	if err != nil {
		return
	}
	host, _, _ := net.SplitHostPort(r.RemoteAddr)

	s.claim(ws, host, "browser")

	defer func() {
		s.mu.Lock()
		if s.client == ws {
			s.client, s.peer, s.peerVia = nil, "", ""
			s.eng.Buffer().Reset()
		}
		s.mu.Unlock()
		ws.conn.Close()
	}()

	in := &ingester{samples: make([]float32, 0, 2048)}
	for {
		op, data, err := ws.readMessage()
		if err != nil {
			return
		}
		switch op {
		case 2: // raw little-endian int16 mono PCM
			s.mu.Lock()
			active := s.client == ws
			s.mu.Unlock()
			if !active {
				continue
			}
			s.ingest(in, data)
		case 1:
			var m struct {
				Type string  `json:"type"`
				Rate int     `json:"rate"`
				T    float64 `json:"t"`
			}
			if json.Unmarshal(data, &m) != nil {
				continue
			}
			switch m.Type {
			case "hello":
				in.clientRate, in.rs = m.Rate, nil
				s.eng.Buffer().Reset()
			case "ping":
				buf := s.eng.Buffer()
				und, drops := buf.Stats()
				reply, _ := json.Marshal(map[string]any{
					"type": "pong", "t": m.T,
					"buffer_ms": math.Round(buf.LevelMs()*10) / 10,
					"output_ms": math.Round(s.eng.OutLatencyMs()*10) / 10,
					"underruns": und, "drops": drops,
				})
				ws.writeFrame(1, reply)
			}
		}
	}
}

// Run starts the HTTPS server; it only returns on error.
func (s *Server) Run(ips []string) error {
	cert, err := loadOrCreateCert(ips)
	if err != nil {
		return fmt.Errorf("certificate: %w", err)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handleIndex)
	mux.HandleFunc("/config", s.handleConfig)
	mux.HandleFunc("/ws", s.handleWS)
	mux.HandleFunc("/PhoneMic.apk", s.handleAPK)
	srv := &http.Server{
		Addr:      fmt.Sprintf(":%d", s.port),
		Handler:   mux,
		TLSConfig: &tls.Config{Certificates: []tls.Certificate{cert}, NextProtos: []string{"http/1.1"}},
		// An empty (non-nil) map turns HTTP/2 off so WebSockets can use the plain upgrade.
		TLSNextProto:      map[string]func(*http.Server, *tls.Conn, http.Handler){},
		ReadHeaderTimeout: 10 * time.Second,
		ErrorLog:          nil,
	}
	ln, err := net.Listen("tcp", srv.Addr)
	if err != nil {
		return err
	}
	if err := s.startUDP(); err != nil {
		ln.Close()
		return err
	}
	if err := s.runLanding(); err != nil {
		ln.Close()
		return err
	}
	return srv.ServeTLS(ln, "", "")
}

// ---------------------------------------------------------------- Network helpers

func configDir() string {
	d, err := os.UserConfigDir()
	if err != nil {
		d = "."
	}
	d = filepath.Join(d, "PhoneMic")
	os.MkdirAll(d, 0o755)
	return d
}

// LocalIPs lists this PC's LAN IPv4 addresses, most likely Wi-Fi/Ethernet one first.
func LocalIPs() []string {
	type cand struct {
		ip    string
		score int
	}
	primary := ""
	if c, err := net.Dial("udp4", "8.8.8.8:80"); err == nil { // no packet is sent
		primary = c.LocalAddr().(*net.UDPAddr).IP.String()
		c.Close()
	}
	var cs []cand
	seen := map[string]bool{}
	ifaces, _ := net.Interfaces()
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagUp == 0 || ifc.Flags&net.FlagLoopback != 0 {
			continue
		}
		name := strings.ToLower(ifc.Name)
		addrs, _ := ifc.Addrs()
		for _, a := range addrs {
			ipn, ok := a.(*net.IPNet)
			if !ok || ipn.IP.To4() == nil || ipn.IP.IsLinkLocalUnicast() {
				continue
			}
			ip := ipn.IP.To4().String()
			if seen[ip] {
				continue
			}
			seen[ip] = true
			score := 0
			switch {
			case ip == primary:
				score = 100
			case strings.HasPrefix(ip, "192.168."):
				score = 50
			case strings.HasPrefix(ip, "10."):
				score = 40
			default:
				score = 30
			}
			for _, bad := range []string{"vethernet", "virtualbox", "vmware", "hyper-v", "wsl", "docker", "bluetooth", "tailscale", "zerotier", "vpn"} {
				if strings.Contains(name, bad) {
					score -= 25
				}
			}
			cs = append(cs, cand{ip, score})
		}
	}
	if primary != "" && !seen[primary] {
		cs = append(cs, cand{primary, 100})
	}
	sort.SliceStable(cs, func(i, j int) bool { return cs[i].score > cs[j].score })
	out := make([]string, 0, len(cs))
	for _, c := range cs {
		out = append(out, c.ip)
	}
	if len(out) == 0 {
		out = append(out, "127.0.0.1")
	}
	return out
}

func loadOrCreateCert(ips []string) (tls.Certificate, error) {
	dir := configDir()
	certFile, keyFile, metaFile := filepath.Join(dir, "cert.pem"), filepath.Join(dir, "key.pem"), filepath.Join(dir, "ips.txt")
	sorted := append([]string(nil), ips...)
	sort.Strings(sorted)
	want := strings.Join(sorted, ",")
	if meta, err := os.ReadFile(metaFile); err == nil && string(meta) == want {
		if c, err := tls.LoadX509KeyPair(certFile, keyFile); err == nil {
			if c.Leaf == nil || time.Now().Before(c.Leaf.NotAfter.Add(-24*time.Hour)) {
				return c, nil
			}
		}
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	tmpl := &x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: "PhoneMic"},
		NotBefore:             time.Now().Add(-24 * time.Hour),
		NotAfter:              time.Now().Add(800 * 24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		DNSNames:              []string{"localhost"},
		IPAddresses:           []net.IP{net.ParseIP("127.0.0.1")},
	}
	for _, ip := range ips {
		if p := net.ParseIP(ip); p != nil && ip != "127.0.0.1" {
			tmpl.IPAddresses = append(tmpl.IPAddresses, p)
		}
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, err
	}
	keyDer, _ := x509.MarshalPKCS8PrivateKey(key)
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDer})
	os.WriteFile(certFile, certPEM, 0o644)
	os.WriteFile(keyFile, keyPEM, 0o600)
	os.WriteFile(metaFile, []byte(want), 0o644)
	return tls.X509KeyPair(certPEM, keyPEM)
}
