#!/bin/bash
# Builds PhoneMic.apk without Gradle: aapt2 -> javac -> dx -> zipalign -> apksigner
set -euo pipefail
cd "$(dirname "$0")"
JAR=${ANDROID_JAR:-/tmp/sable/android-34/android.jar}
BT=/usr/lib/android-sdk/build-tools/29.0.3
VERSION_CODE=3; VERSION_NAME=1.2
rm -rf out && mkdir -p out/gen out/classes out/dex
aapt2 compile --dir res -o out/res.zip
aapt2 link -I "$JAR" --manifest AndroidManifest.xml --java out/gen \
  --min-sdk-version 24 --target-sdk-version 34 \
  --version-code $VERSION_CODE --version-name $VERSION_NAME \
  -o out/base.apk out/res.zip
javac -nowarn -Xlint:-options -source 8 -target 8 -encoding UTF-8 -bootclasspath "$JAR" -d out/classes \
  $(find src out/gen -name '*.java') 2>&1 | grep -v "^Picked up" || true
test -f out/classes/app/phonemic/mic/MainActivity.class
$BT/dx --dex --min-sdk-version=24 --output=out/dex/classes.dex out/classes
cp out/base.apk out/unsigned.apk
(cd out/dex && zip -q -X ../unsigned.apk classes.dex)
zipalign -p -f 4 out/unsigned.apk out/aligned.apk
if [ ! -f phonemic.jks ]; then
  keytool -genkeypair -keystore phonemic.jks -alias phonemic -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass phonemic -keypass phonemic -dname "CN=PhoneMic" 2>&1 | grep -v "^Picked up" || true
fi
apksigner sign --ks phonemic.jks --ks-pass pass:phonemic --key-pass pass:phonemic --out PhoneMic.apk out/aligned.apk
apksigner verify --print-certs PhoneMic.apk | head -2
ls -la PhoneMic.apk
