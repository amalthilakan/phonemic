package app.phonemic.mic;
import java.util.*;
public class TestClient {
  public static void main(String[] a) throws Exception {
    List<Discovery.Pc> pcs = Discovery.find(8444, 1200, Arrays.asList("127.0.0.1"));
    for (Discovery.Pc p : pcs) System.out.println("FOUND " + p.name + " " + p.ip + ":" + p.port + " rate=" + p.rate + " virtual=" + p.virtual + " dev=" + p.device);
    StreamClient c = new StreamClient("127.0.0.1", 8444, "Test Phone", 48000, cl -> System.out.println("STATE " + cl.getState() + " " + cl.getProblem()));
    c.open();
    short[] buf = new short[256]; long start = System.nanoTime(); long n = 0; double ph = 0;
    for (int k = 0; k < 1500; k++) { // 8 s
      for (int i = 0; i < 256; i++) { buf[i] = (short)(Math.sin(ph) * 12000); ph += 2*Math.PI*1000/48000; }
      c.sendAudio(buf, 256); n += 256;
      long due = start + n * 1_000_000_000L / 48000; long w = due - System.nanoTime();
      if (w > 0) Thread.sleep(w / 1_000_000, (int)(w % 1_000_000));
      if (k == 600) System.out.printf("STATS rtt=%.2f pcbuf=%.1f out=%.1f und=%d drops=%d lost=%d sent=%d pc=%s%n", c.getRttMs(), c.getPcBufferMs(), c.getPcOutputMs(), c.getUnderruns(), c.getDrops(), c.getLost(), c.getSent(), c.getPcName());
      if (k == 99999) { // second phone takes over
        StreamClient c2 = new StreamClient("127.0.0.1", 8444, "Phone B", 48000, cl -> System.out.println("STATE-B " + cl.getState()));
        c2.open(); Thread.sleep(300); short[] z = new short[256]; c2.sendAudio(z,256); Thread.sleep(300); c2.close(); start = System.nanoTime(); n = 0;
      }
    }
    System.out.println("FINAL state=" + c.getState() + " problem=" + c.getProblem());
    c.close();
  }
}
