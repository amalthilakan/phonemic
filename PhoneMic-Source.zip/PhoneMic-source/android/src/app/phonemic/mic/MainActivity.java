package app.phonemic.mic;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    static final int BG = 0xFF0F1115, PANEL = 0xFF171A21, LINE = 0xFF262B35, TEXT = 0xFFE8EAF0, DIM = 0xFF8B93A5;
    static final int ACCENT = 0xFF3DDC97, ACCENT_DARK = 0xFF133A2B, WARN = 0xFFFFB547, BAD = 0xFFFF5D5D;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private LinearLayout pcList;
    private TextView chip, searchHint, stateText, hintText, muteBtn;
    private TextView statDelay, statNet, statBuf, statLost;
    private TextView gainLabel;
    private MicButton micBtn;

    private final List<Discovery.Pc> found = new ArrayList<>();
    private String selHost, selName;
    private int selPort = Proto.DEFAULT_PORT;
    private boolean searching, resumed, wasRunning;
    private String note = "";

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            refreshLive();
            h.postDelayed(this, 80);
        }
    };

    private final Runnable autoSearch = new Runnable() {
        @Override public void run() {
            if (resumed && MicService.instance == null && found.isEmpty()) search();
            if (resumed) h.postDelayed(this, 5000);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = Prefs.get(this);
        selHost = prefs.getString(Prefs.LAST_HOST, null);
        selPort = prefs.getInt(Prefs.LAST_PORT, Proto.DEFAULT_PORT);
        selName = prefs.getString(Prefs.LAST_NAME, selHost);
        setContentView(buildUi());
        renderPcs();
        if (saved == null && handleLink(getIntent())) return; // opened from the PC's QR code
        if (saved == null && Prefs.autoConnect(prefs) && selHost != null && MicService.instance == null) {
            h.postDelayed(new Runnable() {
                @Override public void run() { onMicTap(); }
            }, 400);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleLink(intent);
    }

    /** Handles phonemic://connect?host=..&port=..&name=.. by asking the user to confirm. */
    private boolean handleLink(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return false;
        Uri u = intent.getData();
        if (u == null || !"phonemic".equals(u.getScheme())) return false;
        intent.setData(null);
        final String host = u.getQueryParameter("host");
        if (host == null || !host.matches("[0-9A-Za-z.:\\-]{1,64}")) return false;
        int port = Proto.DEFAULT_PORT;
        try {
            String p = u.getQueryParameter("port");
            if (p != null) port = Integer.parseInt(p);
        } catch (NumberFormatException ignored) { }
        String n = u.getQueryParameter("name");
        final Discovery.Pc pc = new Discovery.Pc();
        pc.ip = host;
        pc.port = port;
        pc.name = n == null || n.trim().isEmpty() ? host : n.trim();
        if (pc.name.length() > 60) pc.name = pc.name.substring(0, 60);

        final MicService s = MicService.instance;
        boolean sameLive = s != null && host.equals(selHost) && port == selPort;
        if (sameLive) {
            note = "";
            Toast.makeText(this, "Already connected to " + pc.name, Toast.LENGTH_SHORT).show();
            return true;
        }
        // A PC you've streamed to before: connect right away, no questions.
        if (s == null && host.equals(selHost) && port == selPort) {
            select(pc);
            onMicTap();
            return true;
        }
        String msg = "Your phone's microphone will be streamed to this computer:\n\n"
                + pc.name + "\n" + host
                + (s != null ? "\n\nThis will stop the current stream to " + label(selName, selHost) + "." : "");
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Connect to this PC?")
                .setMessage(msg)
                .setPositiveButton("Connect", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        select(pc);
                        if (MicService.instance != null) startStream();
                        else onMicTap();
                        search(); // refresh name / virtual-mic status
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        h.post(poll);
        search();
        h.postDelayed(autoSearch, 5000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(poll);
        h.removeCallbacks(autoSearch);
    }

    // ------------------------------------------------------------------ actions

    private void onMicTap() {
        if (MicService.instance != null) {
            startService(new Intent(this, MicService.class).setAction(MicService.ACTION_STOP));
            note = "";
            return;
        }
        if (selHost == null) {
            if (found.size() == 1) {
                select(found.get(0));
            } else {
                note = found.isEmpty() ? "No PC selected yet. Open PhoneMic on your PC, or tap Enter IP."
                        : "Pick your PC in the list above first.";
                return;
            }
        }
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), 1);
            return;
        }
        startStream();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startStream();
        } else if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            note = "Microphone permission is off. Tap here to open settings and allow it.";
            hintText.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                }
            });
        } else {
            note = "PhoneMic needs the microphone permission to send your voice to the PC.";
        }
    }

    private void startStream() {
        note = "";
        MicService.lastMessage = "";
        Intent i = new Intent(this, MicService.class).setAction(MicService.ACTION_START)
                .putExtra(MicService.EXTRA_HOST, selHost)
                .putExtra(MicService.EXTRA_PORT, selPort)
                .putExtra(MicService.EXTRA_NAME, selName);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void select(Discovery.Pc pc) {
        selHost = pc.ip;
        selPort = pc.port;
        selName = pc.name;
        prefs.edit().putString(Prefs.LAST_HOST, selHost).putInt(Prefs.LAST_PORT, selPort)
                .putString(Prefs.LAST_NAME, selName).apply();
        renderPcs();
    }

    private void search() {
        if (searching) return;
        searching = true;
        renderPcs();
        final List<String> extra = selHost != null ? Collections.singletonList(selHost) : Collections.<String>emptyList();
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Discovery.Pc> r = Discovery.find(Proto.DEFAULT_PORT, 1600, extra);
                h.post(new Runnable() {
                    @Override public void run() {
                        searching = false;
                        found.clear();
                        found.addAll(r);
                        for (Discovery.Pc pc : r) { // refresh the saved PC's name
                            if (pc.ip.equals(selHost) && !pc.name.equals(selName)) select(pc);
                        }
                        if (selHost == null && r.size() == 1) select(r.get(0));
                        renderPcs();
                    }
                });
            }
        }, "phonemic-discovery").start();
    }

    private void askForIp() {
        final EditText et = new EditText(this);
        et.setHint("e.g. 192.168.1.5");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setSingleLine();
        if (selHost != null) et.setText(selPort == Proto.DEFAULT_PORT ? selHost : selHost + ":" + selPort);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("PC address")
                .setMessage("Type the address shown in the PhoneMic window on your PC.")
                .setView(box)
                .setPositiveButton("Use", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String t = et.getText().toString().trim().replace("https://", "").replace("http://", "");
                        if (t.endsWith("/")) t = t.substring(0, t.length() - 1);
                        if (t.isEmpty()) return;
                        Discovery.Pc pc = new Discovery.Pc();
                        pc.ip = t;
                        pc.port = Proto.DEFAULT_PORT;
                        int c = t.lastIndexOf(':');
                        if (c > 0) {
                            pc.ip = t.substring(0, c);
                            try {
                                pc.port = Integer.parseInt(t.substring(c + 1));
                                if (pc.port == 8443) pc.port = Proto.DEFAULT_PORT; // the browser port was typed
                            } catch (NumberFormatException ignored) { }
                        }
                        pc.name = pc.ip;
                        select(pc);
                        search();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ------------------------------------------------------------------ live refresh

    private void refreshLive() {
        MicService s = MicService.instance;
        boolean running = s != null;
        StreamClient c = running ? s.client : null;
        int st = c == null ? (running ? StreamClient.CONNECTING : 0) : c.getState();
        boolean live = st == StreamClient.LIVE;
        boolean muted = running && s.muted;
        float p = running ? s.takePeak() : 0;
        float lvl = p > 0 ? (float) Math.max(0, (20 * Math.log10(p) + 60) / 60) : 0;
        micBtn.setState(live, running && !live, muted, lvl);
        if (wasRunning && !running && !MicService.lastMessage.isEmpty()) note = MicService.lastMessage;
        wasRunning = running;

        String chipText;
        int chipColor;
        String hint;
        if (!running) {
            stateText.setText("Tap to start");
            chipText = "Off";
            chipColor = DIM;
            hint = !note.isEmpty() ? note
                    : selHost != null ? "Will stream to " + label(selName, selHost) : "Choose your PC above";
        } else if (live) {
            stateText.setText(muted ? "Muted" : "Live - your PC is hearing you");
            chipText = muted ? "Muted" : "Live";
            chipColor = muted ? WARN : ACCENT;
            String extra = s.micProblem.isEmpty() ? "" : "\n" + s.micProblem;
            if (!c.isPcVirtual() && !c.getPcDevice().isEmpty()) {
                extra += "\nThe PC is playing you on its speakers. Install VB-Cable on the PC to use it as a mic.";
            }
            hint = "Streaming to " + c.getPcName() + " · 48 kHz · "
                    + Prefs.CHUNK_NAMES[Prefs.chunk(prefs)].split(" \\(")[0] + " packets" + extra;
        } else if (st == StreamClient.RECONNECTING) {
            stateText.setText("Reconnecting...");
            chipText = "Reconnecting";
            chipColor = WARN;
            hint = c.getProblem();
        } else {
            stateText.setText("Connecting to " + label(selName, selHost) + "...");
            chipText = "Connecting";
            chipColor = WARN;
            hint = c != null ? c.getProblem() : "";
        }
        hintText.setText(hint);
        hintText.setTextColor(!running && !note.isEmpty() ? WARN : DIM);
        if (!(!running && note.startsWith("Microphone permission is off"))) hintText.setOnClickListener(null);
        chip.setText("●  " + chipText);
        chip.setTextColor(chipColor);
        muteBtn.setVisibility(running ? View.VISIBLE : View.INVISIBLE);
        muteBtn.setText(muted ? "Unmute" : "Mute");
        muteBtn.setBackground(rounded(muted ? 0xFF3A2A12 : PANEL, 22, muted ? WARN : LINE));
        muteBtn.setTextColor(muted ? WARN : TEXT);

        if (live) {
            float rtt = c.getRttMs();
            float chunkMs = Prefs.CHUNKS[Prefs.chunk(prefs)] * 1000f / MicService.RATE;
            float total = Math.max(0, rtt) / 2 + c.getPcBufferMs() + c.getPcOutputMs() + chunkMs + 10;
            statDelay.setText(String.valueOf(Math.round(total)));
            statNet.setText(rtt < 0 ? "-" : String.valueOf(Math.round(rtt / 2)));
            statBuf.setText(String.valueOf(Math.round(c.getPcBufferMs())));
            statLost.setText(String.valueOf(c.getLost()));
        } else {
            statDelay.setText("-");
            statNet.setText("-");
            statBuf.setText("-");
            statLost.setText("-");
        }
    }

    private static String label(String name, String host) {
        return name == null || name.isEmpty() ? host : name;
    }

    // ------------------------------------------------------------------ PC list

    private void renderPcs() {
        if (pcList == null) return;
        pcList.removeAllViews();
        List<Discovery.Pc> list = new ArrayList<>(found);
        boolean selInList = false;
        for (Discovery.Pc pc : list) if (pc.ip.equals(selHost)) selInList = true;
        if (selHost != null && !selInList) {
            Discovery.Pc saved = new Discovery.Pc();
            saved.ip = selHost;
            saved.port = selPort;
            saved.name = label(selName, selHost);
            saved.rate = -1; // marks "not seen right now"
            list.add(0, saved);
        }
        for (final Discovery.Pc pc : list) {
            boolean sel = pc.ip.equals(selHost);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(rounded(sel ? ACCENT_DARK : PANEL, 12, sel ? 0xFF23573F : 0));
            TextView dot = text(sel ? "◉" : "○", 20, sel ? ACCENT : DIM, false);
            dot.setPadding(0, 0, dp(12), 0);
            row.addView(dot);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(pc.name, 16, TEXT, true));
            String sub = pc.port == Proto.DEFAULT_PORT ? pc.ip : pc.ip + ":" + pc.port;
            if (pc.rate == -1) sub += searching ? "  ·  checking..." : "  ·  last used, not found right now";
            else sub += pc.virtual ? "  ·  virtual mic ready" : "  ·  VB-Cable not installed";
            col.addView(text(sub, 12.5f, pc.rate != -1 && !pc.virtual ? WARN : DIM, false));
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    boolean switching = MicService.instance != null && !pc.ip.equals(selHost);
                    select(pc);
                    if (switching) startStream(); // move the live stream to the newly picked PC
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(6);
            pcList.addView(row, lp);
        }
        if (searching) {
            searchHint.setText("Looking for PCs on this Wi-Fi...");
            searchHint.setVisibility(View.VISIBLE);
        } else if (found.isEmpty()) {
            searchHint.setText("No PC found yet. Open PhoneMic on your Windows PC, keep both on the same Wi-Fi, "
                    + "and allow it in Windows Firewall. Or tap Enter IP.");
            searchHint.setVisibility(View.VISIBLE);
        } else {
            searchHint.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------ UI building

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        scroll.addView(root);

        // header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("PhoneMic", 24, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        chip = text("●  Off", 13, DIM, true);
        chip.setPadding(dp(12), dp(5), dp(12), dp(5));
        chip.setBackground(rounded(PANEL, 20, LINE));
        head.addView(chip);
        root.addView(head);

        // PC chooser
        root.addView(sectionLabel("YOUR PC"));
        LinearLayout pcCard = card();
        pcList = new LinearLayout(this);
        pcList.setOrientation(LinearLayout.VERTICAL);
        pcCard.addView(pcList);
        searchHint = text("", 13, DIM, false);
        searchHint.setPadding(dp(4), dp(2), dp(4), dp(8));
        pcCard.addView(searchHint);
        LinearLayout btns = new LinearLayout(this);
        TextView again = pillButton("Search again");
        again.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { search(); }
        });
        TextView manual = pillButton("Enter IP");
        manual.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askForIp(); }
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(42), 1);
        btns.addView(again, half);
        View gap = new View(this);
        btns.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        btns.addView(manual, new LinearLayout.LayoutParams(0, dp(42), 1));
        pcCard.addView(btns);
        root.addView(pcCard);

        // big button
        micBtn = new MicButton(this);
        micBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onMicTap(); }
        });
        LinearLayout.LayoutParams mb = new LinearLayout.LayoutParams(dp(210), dp(210));
        mb.gravity = Gravity.CENTER_HORIZONTAL;
        mb.topMargin = dp(10);
        root.addView(micBtn, mb);
        stateText = text("Tap to start", 18, TEXT, true);
        stateText.setGravity(Gravity.CENTER);
        root.addView(stateText);
        hintText = text("", 13, DIM, false);
        hintText.setGravity(Gravity.CENTER);
        hintText.setPadding(dp(8), dp(4), dp(8), dp(4));
        hintText.setMinLines(2);
        root.addView(hintText);
        muteBtn = pillButton("Mute");
        muteBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                MicService s = MicService.instance;
                if (s != null) s.toggleMute();
            }
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(140), dp(42));
        mlp.gravity = Gravity.CENTER_HORIZONTAL;
        mlp.topMargin = dp(6);
        mlp.bottomMargin = dp(14);
        root.addView(muteBtn, mlp);

        // stats
        LinearLayout stats = new LinearLayout(this);
        statDelay = stat(stats, "est. delay ms");
        statNet = stat(stats, "Wi-Fi ms");
        statBuf = stat(stats, "PC buffer ms");
        statLost = stat(stats, "lost packets");
        root.addView(stats);

        // settings
        root.addView(sectionLabel("SOUND"));
        LinearLayout set = card();
        set.addView(subLabel("Microphone"));
        set.addView(spinner(Prefs.SOURCE_NAMES, Prefs.source(prefs), Prefs.SOURCE));
        set.addView(subLabel("Packet size (smaller = less delay)"));
        set.addView(spinner(Prefs.CHUNK_NAMES, Prefs.chunk(prefs), Prefs.CHUNK));
        gainLabel = subLabel("Volume  " + Prefs.gain(prefs) + "%");
        set.addView(gainLabel);
        SeekBar gain = new SeekBar(this);
        gain.setMax(400);
        gain.setProgress(Prefs.gain(prefs));
        gain.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean user) {
                v = Math.max(0, Math.round(v / 5f) * 5);
                gainLabel.setText("Volume  " + v + "%");
                prefs.edit().putInt(Prefs.GAIN, v).apply();
                settingsChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        set.addView(gain);
        set.addView(toggle("Noise suppression", "Removes background hiss and fan noise", Prefs.NS, Prefs.ns(prefs)));
        set.addView(toggle("Echo cancellation", "Use if the PC speakers leak into the phone", Prefs.AEC, Prefs.aec(prefs)));
        set.addView(toggle("Auto gain", "Evens out loud and quiet speech", Prefs.AGC, Prefs.agc(prefs)));
        root.addView(set);

        root.addView(sectionLabel("CONNECTION"));
        LinearLayout con = card();
        con.addView(toggle("Low-latency Wi-Fi", "Stops Wi-Fi power saving while streaming (less delay, a bit more battery)", Prefs.WIFI_LL, Prefs.wifiLowLatency(prefs)));
        con.addView(toggle("Auto-connect", "Start streaming as soon as you open the app", Prefs.AUTO, Prefs.autoConnect(prefs)));
        root.addView(con);

        TextView foot = text("Runs in the background - control it from the notification.\n"
                + "Your PC needs PhoneMic.exe running, on the same Wi-Fi or this phone's hotspot.", 12, DIM, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(16), 0, 0);
        root.addView(foot);
        return scroll;
    }

    private void settingsChanged() {
        MicService s = MicService.instance;
        if (s != null) s.applySettings();
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private GradientDrawable rounded(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private TextView sectionLabel(String s) {
        TextView t = text(s, 12, DIM, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(4), dp(20), 0, dp(8));
        return t;
    }

    private TextView subLabel(String s) {
        TextView t = text(s, 13, DIM, false);
        t.setPadding(dp(4), dp(10), 0, dp(2));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        c.setBackground(rounded(0xFF13161C, 16, LINE));
        return c;
    }

    private TextView pillButton(String s) {
        TextView b = text(s, 15, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(PANEL, 22, LINE));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private TextView stat(LinearLayout parent, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(10), dp(4), dp(10));
        box.setBackground(rounded(PANEL, 12, LINE));
        TextView v = text("-", 20, TEXT, true);
        v.setGravity(Gravity.CENTER);
        TextView l = text(label, 11, DIM, false);
        l.setGravity(Gravity.CENTER);
        box.addView(v);
        box.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (parent.getChildCount() > 0) lp.leftMargin = dp(6);
        parent.addView(box, lp);
        return v;
    }

    private Spinner spinner(String[] items, int sel, final String key) {
        Spinner sp = new Spinner(this, Spinner.MODE_DROPDOWN);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setSelection(Math.min(sel, items.length - 1));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (prefs.getInt(key, -1) == pos) return;
                prefs.edit().putInt(key, pos).apply();
                settingsChanged();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        return sp;
    }

    private View toggle(String title, String sub, final String key, boolean on) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(12), dp(2), dp(4));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(title, 15, TEXT, false));
        col.addView(text(sub, 12, DIM, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                prefs.edit().putBoolean(key, v).apply();
                settingsChanged();
            }
        });
        row.addView(sw);
        return row;
    }
}
