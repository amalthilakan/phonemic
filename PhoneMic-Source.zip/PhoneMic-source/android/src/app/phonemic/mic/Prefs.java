package app.phonemic.mic;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaRecorder;

/** Saved settings. */
final class Prefs {
    private Prefs() {}

    static final String FILE = "phonemic";
    static final String LAST_HOST = "last_host", LAST_PORT = "last_port", LAST_NAME = "last_name";
    static final String SOURCE = "source", CHUNK = "chunk", GAIN = "gain";
    static final String NS = "ns", AEC = "aec", AGC = "agc", WIFI_LL = "wifi_ll", AUTO = "auto_connect";

    static final int[] SOURCES = {
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.CAMCORDER,
    };
    static final String[] SOURCE_NAMES = {
            "Default microphone",
            "Raw (unprocessed, lowest delay)",
            "Voice recognition (clean)",
            "Voice call (phone's own noise cancelling)",
            "Camcorder (back mic)",
    };
    static final int[] CHUNKS = {128, 256, 512};
    static final String[] CHUNK_NAMES = {"2.7 ms (ultra low delay)", "5.3 ms (low delay)", "10.7 ms (most stable)"};

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static int source(SharedPreferences p) { return p.getInt(SOURCE, 0); }
    static int chunk(SharedPreferences p) { return p.getInt(CHUNK, 1); }
    static int gain(SharedPreferences p) { return p.getInt(GAIN, 100); }
    static boolean ns(SharedPreferences p) { return p.getBoolean(NS, false); }
    static boolean aec(SharedPreferences p) { return p.getBoolean(AEC, false); }
    static boolean agc(SharedPreferences p) { return p.getBoolean(AGC, false); }
    static boolean wifiLowLatency(SharedPreferences p) { return p.getBoolean(WIFI_LL, true); }
    static boolean autoConnect(SharedPreferences p) { return p.getBoolean(AUTO, false); }
}
