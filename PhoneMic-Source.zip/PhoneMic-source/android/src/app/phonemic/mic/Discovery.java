package app.phonemic.mic;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Finds computers running PhoneMic.exe on the local network (UDP broadcast). */
public final class Discovery {

    public static final class Pc {
        public String name, ip, device;
        public int port, rate;
        public boolean virtual;
    }

    private Discovery() {}

    /**
     * Broadcasts a few DISCOVER packets and collects answers for timeoutMs.
     * extraHosts are also asked directly (e.g. the last PC used), in case the
     * router blocks broadcasts.
     */
    public static List<Pc> find(int port, int timeoutMs, List<String> extraHosts) {
        Map<String, Pc> found = new LinkedHashMap<>();
        DatagramSocket s = null;
        try {
            s = new DatagramSocket();
            s.setBroadcast(true);
            s.setSoTimeout(150);
            Set<InetAddress> targets = new LinkedHashSet<>(broadcastAddresses());
            targets.add(InetAddress.getByName("255.255.255.255"));
            for (String h : extraHosts) {
                try {
                    if (h != null && !h.isEmpty()) targets.add(InetAddress.getByName(h));
                } catch (Exception ignored) {
                }
            }
            byte[] q = new byte[5];
            Proto.header(q, Proto.DISCOVER);
            byte[] buf = new byte[2048];
            DatagramPacket in = new DatagramPacket(buf, buf.length);
            long end = System.currentTimeMillis() + timeoutMs;
            long nextSend = 0;
            int sends = 0;
            while (System.currentTimeMillis() < end) {
                long now = System.currentTimeMillis();
                if (sends < 3 && now >= nextSend) {
                    for (InetAddress t : targets) {
                        try {
                            s.send(new DatagramPacket(q, q.length, t, port));
                        } catch (Exception ignored) {
                        }
                    }
                    sends++;
                    nextSend = now + 350;
                }
                try {
                    in.setLength(buf.length);
                    s.receive(in);
                } catch (SocketTimeoutException e) {
                    continue;
                }
                int len = in.getLength();
                if (!Proto.valid(buf, len) || buf[4] != Proto.OFFER) continue;
                String j = new String(buf, 5, len - 5, StandardCharsets.UTF_8);
                Pc pc = new Pc();
                pc.ip = in.getAddress().getHostAddress();
                pc.name = Proto.jsonStr(j, "name", pc.ip);
                pc.port = Proto.jsonInt(j, "port", port);
                pc.rate = Proto.jsonInt(j, "rate", 48000);
                pc.device = Proto.jsonStr(j, "device", "");
                pc.virtual = "true".equals(Proto.json(j, "virtual"));
                found.put(pc.ip, pc);
            }
        } catch (Exception ignored) {
        } finally {
            if (s != null) s.close();
        }
        List<Pc> list = new ArrayList<>(found.values());
        Collections.sort(list, new Comparator<Pc>() {
            @Override public int compare(Pc a, Pc b) { return a.name.compareToIgnoreCase(b.name); }
        });
        return list;
    }

    static List<InetAddress> broadcastAddresses() {
        List<InetAddress> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
            while (e != null && e.hasMoreElements()) {
                NetworkInterface ni = e.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getAddress() instanceof Inet4Address && ia.getBroadcast() != null) {
                        out.add(ia.getBroadcast());
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }
}
