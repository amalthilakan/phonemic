package app.phonemic.mic;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Random;

/**
 * Sends microphone audio to PhoneMic.exe over UDP and keeps the session alive.
 * Pure Java (no Android APIs) so it can be tested on a desktop JVM.
 */
public final class StreamClient {

    public interface Listener {
        void onStateChanged(StreamClient client);
    }

    public static final int CONNECTING = 1, LIVE = 2, RECONNECTING = 3, KICKED = 4, CLOSED = 5;

    private final String host;
    private final int port;
    private final String phoneName;
    private final int rate;
    private final Listener listener;
    private final int session;
    private final long t0 = System.nanoTime();

    private DatagramSocket socket;
    private InetAddress addr;
    private DatagramPacket audioPacket;
    private byte[] pkt = new byte[13 + 4096];
    private int seq;
    private Thread rx;
    private volatile boolean closed;

    private volatile int state = CONNECTING;
    private volatile String problem = "";
    private volatile String pcName = "", pcDevice = "";
    private volatile boolean pcVirtual;
    private volatile int pcRate;
    private volatile float rttMs = -1, pcBufferMs, pcOutputMs;
    private volatile long underruns, drops, lost, sent;
    private volatile long lastHelloNs, lastPingNs, lastPongNs, startNs;

    public StreamClient(String host, int port, String phoneName, int rate, Listener listener) {
        this.host = host;
        this.port = port;
        this.phoneName = phoneName;
        this.rate = rate;
        this.listener = listener;
        this.session = (new Random().nextInt() & 0x7FFFFFFF) | 1;
    }

    /** Resolves the PC address and starts the handshake. Call off the UI thread. */
    public void open() throws IOException {
        addr = InetAddress.getByName(host);
        socket = new DatagramSocket();
        socket.setSoTimeout(500);
        try {
            socket.setTrafficClass(0xB8); // DSCP "expedited forwarding" -> Wi-Fi voice priority queue
        } catch (Exception ignored) {
        }
        audioPacket = new DatagramPacket(pkt, pkt.length, addr, port);
        startNs = System.nanoTime();
        rx = new Thread(new Runnable() {
            @Override public void run() { receiveLoop(); }
        }, "phonemic-rx");
        rx.setDaemon(true);
        rx.start();
        sendHello();
    }

    public void close() {
        if (closed) return;
        closed = true;
        if (state == LIVE) {
            byte[] b = new byte[9];
            Proto.header(b, Proto.BYE);
            Proto.putInt(b, 5, session);
            send(b, 9);
        }
        state = CLOSED;
        if (socket != null) socket.close();
    }

    /** Called from the capture thread for every chunk of 16-bit mono samples. */
    public void sendAudio(short[] pcm, int n) {
        tick();
        if (state != LIVE || closed) return;
        int len = 13 + n * 2;
        if (pkt.length < len) {
            pkt = new byte[len];
            audioPacket = new DatagramPacket(pkt, len, addr, port);
        }
        Proto.header(pkt, Proto.AUDIO);
        Proto.putInt(pkt, 5, session);
        Proto.putInt(pkt, 9, seq++);
        for (int i = 0, o = 13; i < n; i++, o += 2) {
            short v = pcm[i];
            pkt[o] = (byte) v;
            pkt[o + 1] = (byte) (v >> 8);
        }
        audioPacket.setData(pkt, 0, len);
        try {
            socket.send(audioPacket);
            sent++;
        } catch (IOException e) {
            setProblem("Network error: " + e.getMessage());
        }
    }

    /** Keeps the handshake / keep-alive going. Safe to call often. */
    public void tick() {
        if (closed) return;
        long now = System.nanoTime();
        int st = state;
        if (st == LIVE) {
            if (now - lastPingNs > 1_000_000_000L) sendPing();
            if (now - lastPongNs > 4_000_000_000L) {
                setState(RECONNECTING, "Lost contact with the PC, retrying...");
            }
        } else if (st == CONNECTING || st == RECONNECTING) {
            if (now - lastHelloNs > 500_000_000L) sendHello();
            if (st == CONNECTING && now - startNs > 5_000_000_000L && problem.isEmpty()) {
                setProblem("The PC isn't answering. Is PhoneMic open on the PC and allowed in Windows Firewall?");
            }
        }
    }

    private void sendHello() {
        lastHelloNs = System.nanoTime();
        String json = "{\"session\":" + session + ",\"rate\":" + rate + ",\"name\":" + Proto.quote(phoneName) + "}";
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        byte[] b = new byte[5 + body.length];
        Proto.header(b, Proto.HELLO);
        System.arraycopy(body, 0, b, 5, body.length);
        send(b, b.length);
    }

    private void sendPing() {
        lastPingNs = System.nanoTime();
        byte[] b = new byte[17];
        Proto.header(b, Proto.PING);
        Proto.putInt(b, 5, session);
        Proto.putLong(b, 9, Double.doubleToRawLongBits(nowMs()));
        send(b, b.length);
    }

    private synchronized void send(byte[] b, int len) {
        if (socket == null || socket.isClosed()) return;
        try {
            socket.send(new DatagramPacket(b, len, addr, port));
        } catch (IOException e) {
            setProblem("Network error: " + e.getMessage());
        }
    }

    private double nowMs() { return (System.nanoTime() - t0) / 1e6; }

    private void receiveLoop() {
        byte[] buf = new byte[4096];
        DatagramPacket p = new DatagramPacket(buf, buf.length);
        while (!closed) {
            try {
                p.setLength(buf.length);
                socket.receive(p);
            } catch (SocketTimeoutException e) {
                continue;
            } catch (IOException e) {
                if (closed) break;
                try { Thread.sleep(100); } catch (InterruptedException ie) { break; }
                continue;
            }
            int len = p.getLength();
            if (!Proto.valid(buf, len) || !addr.equals(p.getAddress())) continue;
            switch (buf[4]) {
                case Proto.WELCOME: {
                    String j = new String(buf, 5, len - 5, StandardCharsets.UTF_8);
                    pcName = Proto.jsonStr(j, "name", host);
                    pcDevice = Proto.jsonStr(j, "device", "");
                    pcVirtual = "true".equals(Proto.json(j, "virtual"));
                    pcRate = Proto.jsonInt(j, "rate", 0);
                    lastPongNs = System.nanoTime();
                    if (state != LIVE) {
                        problem = "";
                        setState(LIVE, "");
                    }
                    break;
                }
                case Proto.PONG:
                    if (len >= 5 + 28) {
                        double t = Double.longBitsToDouble(Proto.getLong(buf, 5));
                        float rtt = (float) (nowMs() - t);
                        rttMs = rttMs < 0 ? rtt : rttMs * 0.7f + rtt * 0.3f;
                        pcBufferMs = Float.intBitsToFloat(Proto.getInt(buf, 13));
                        pcOutputMs = Float.intBitsToFloat(Proto.getInt(buf, 17));
                        underruns = Proto.getInt(buf, 21) & 0xFFFFFFFFL;
                        drops = Proto.getInt(buf, 25) & 0xFFFFFFFFL;
                        lost = Proto.getInt(buf, 29) & 0xFFFFFFFFL;
                        lastPongNs = System.nanoTime();
                        if (state == RECONNECTING) setState(LIVE, "");
                    }
                    break;
                case Proto.KICK:
                    setState(KICKED, "Another phone connected to this PC.");
                    break;
                case Proto.REHELLO:
                    if (state == LIVE) setState(RECONNECTING, "Reconnecting...");
                    sendHello();
                    break;
                default:
                    break;
            }
        }
    }

    private void setProblem(String msg) {
        if (msg.equals(problem)) return;
        problem = msg;
        if (listener != null) listener.onStateChanged(this);
    }

    private void setState(int st, String msg) {
        if (state == KICKED || state == CLOSED) return;
        state = st;
        problem = msg;
        if (listener != null) listener.onStateChanged(this);
    }

    public int getState() { return state; }
    public String getProblem() { return problem; }
    public String getPcName() { return pcName.isEmpty() ? host : pcName; }
    public String getPcDevice() { return pcDevice; }
    public boolean isPcVirtual() { return pcVirtual; }
    public int getPcRate() { return pcRate; }
    public float getRttMs() { return rttMs; }
    public float getPcBufferMs() { return pcBufferMs; }
    public float getPcOutputMs() { return pcOutputMs; }
    public long getUnderruns() { return underruns; }
    public long getDrops() { return drops; }
    public long getLost() { return lost; }
    public long getSent() { return sent; }
    public String getHost() { return host; }
    public int getPort() { return port; }
}
