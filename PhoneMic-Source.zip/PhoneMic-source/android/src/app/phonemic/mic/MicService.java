package app.phonemic.mic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.AutomaticGainControl;
import android.media.audiofx.NoiseSuppressor;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;

/**
 * Foreground service that records the microphone and streams it to the PC.
 * Keeps running with the screen off; controlled from the app or the notification.
 */
public class MicService extends Service implements StreamClient.Listener {

    static final String ACTION_START = "app.phonemic.mic.START";
    static final String ACTION_STOP = "app.phonemic.mic.STOP";
    static final String ACTION_MUTE = "app.phonemic.mic.MUTE";
    static final String EXTRA_HOST = "host", EXTRA_PORT = "port", EXTRA_NAME = "name";
    static final int RATE = 48000;
    private static final String CHANNEL = "stream";
    private static final int NOTIF_ID = 1;

    /** The running service, or null. The activity reads live state from here. */
    static volatile MicService instance;
    /** Last reason streaming stopped on its own (shown by the activity). */
    static volatile String lastMessage = "";

    volatile StreamClient client;
    volatile boolean muted;
    volatile String micProblem = "";
    volatile String targetName = "";
    private volatile float peak;

    // live settings read by the capture thread
    volatile float gain = 1f;
    volatile int chunk = 256;
    private volatile int source = MediaRecorder.AudioSource.MIC;
    private volatile boolean restartRecorder;
    private volatile boolean stopRequested;

    private Capture capture;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLockLL, wifiLockHP;
    private NoiseSuppressor ns;
    private AcousticEchoCanceler aec;
    private AutomaticGainControl agc;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action) || action == null) {
            shutdown();
            return START_NOT_STICKY;
        }
        if (ACTION_MUTE.equals(action)) {
            muted = !muted;
            updateNotification();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            String host = intent.getStringExtra(EXTRA_HOST);
            int port = intent.getIntExtra(EXTRA_PORT, Proto.DEFAULT_PORT);
            targetName = intent.getStringExtra(EXTRA_NAME);
            if (targetName == null || targetName.isEmpty()) targetName = host;
            if (!goForeground()) {
                lastMessage = "Android didn't allow the microphone in the background. Open the app and try again.";
                shutdown();
                return START_NOT_STICKY;
            }
            stopCapture();
            instance = this;
            lastMessage = "";
            muted = false;
            micProblem = "";
            applySettings();
            acquireLocks();
            stopRequested = false;
            capture = new Capture(host, port);
            capture.start();
            updateNotification();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopCapture();
        releaseLocks();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    /** Re-reads settings; called by the activity when the user changes something. */
    void applySettings() {
        SharedPreferences p = Prefs.get(this);
        gain = Prefs.gain(p) / 100f;
        chunk = Prefs.CHUNKS[Math.min(Prefs.chunk(p), Prefs.CHUNKS.length - 1)];
        int src = Prefs.SOURCES[Math.min(Prefs.source(p), Prefs.SOURCES.length - 1)];
        if (src != source) {
            source = src;
            restartRecorder = true;
        }
        setEffect(ns, Prefs.ns(p));
        setEffect(aec, Prefs.aec(p));
        setEffect(agc, Prefs.agc(p));
        if (locksHeld) { // locks follow the setting live
            releaseLocks();
            acquireLocks();
        }
    }

    void toggleMute() {
        muted = !muted;
        updateNotification();
    }

    /** Loudest sample since the last call, 0..1. */
    float takePeak() {
        float p = peak;
        peak = 0;
        return p;
    }

    private void shutdown() {
        stopCapture();
        releaseLocks();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        if (instance == this) instance = null;
        stopSelf();
    }

    private void stopCapture() {
        stopRequested = true;
        Capture c = capture;
        capture = null;
        if (c != null) {
            try { c.join(1500); } catch (InterruptedException ignored) { }
        }
        StreamClient cl = client;
        if (cl != null) cl.close();
        client = null;
    }

    // ------------------------------------------------------------------ capture

    private final class Capture extends Thread {
        private final String host;
        private final int port;

        Capture(String host, int port) {
            super("phonemic-capture");
            this.host = host;
            this.port = port;
        }

        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            StreamClient c = new StreamClient(host, port, phoneName(), RATE, MicService.this);
            client = c; // set before open() so a fast WELCOME isn't ignored
            try {
                c.open();
            } catch (Exception e) {
                fail("Can't reach " + host + ". Check the address and that both devices are on the same Wi-Fi.");
                return;
            }
            short[] buf = new short[2048];
            AudioRecord rec = null;
            try {
                while (!stopRequested) {
                    if (rec == null || restartRecorder) {
                        restartRecorder = false;
                        releaseRecorder(rec);
                        rec = openRecorder();
                        if (rec == null) {
                            fail("The microphone is busy or blocked. Close other apps using it and try again.");
                            return;
                        }
                    }
                    int n = rec.read(buf, 0, Math.min(chunk, buf.length));
                    if (n <= 0) {
                        if (n == AudioRecord.ERROR_DEAD_OBJECT) restartRecorder = true;
                        else c.tick();
                        continue;
                    }
                    float g = gain;
                    boolean m = muted;
                    int pk = 0;
                    for (int i = 0; i < n; i++) {
                        int v = m ? 0 : (int) (buf[i] * g);
                        if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
                        buf[i] = (short) v;
                        int a = v < 0 ? -v : v;
                        if (a > pk) pk = a;
                    }
                    float pf = pk / 32768f;
                    if (pf > peak) peak = pf;
                    c.sendAudio(buf, n);
                }
            } finally {
                releaseRecorder(rec);
                c.close();
            }
        }
    }

    private AudioRecord openRecorder() {
        int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int size = Math.max(min, 2048 * 2);
        int[] tries = {source, MediaRecorder.AudioSource.MIC};
        for (int src : tries) {
            AudioRecord r;
            try {
                r = new AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
            } catch (Exception e) {
                continue;
            }
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                continue;
            }
            try {
                r.startRecording();
            } catch (Exception e) {
                r.release();
                continue;
            }
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                r.release();
                continue;
            }
            micProblem = src == source ? "" : "That mic option isn't supported on this phone; using the default mic.";
            attachEffects(r.getAudioSessionId());
            return r;
        }
        return null;
    }

    private void releaseRecorder(AudioRecord r) {
        releaseEffects();
        if (r == null) return;
        try { r.stop(); } catch (Exception ignored) { }
        r.release();
    }

    private void attachEffects(int session) {
        SharedPreferences p = Prefs.get(this);
        try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(session); } catch (Exception ignored) { }
        try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(session); } catch (Exception ignored) { }
        try { if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(session); } catch (Exception ignored) { }
        setEffect(ns, Prefs.ns(p));
        setEffect(aec, Prefs.aec(p));
        setEffect(agc, Prefs.agc(p));
    }

    private static void setEffect(AudioEffect e, boolean on) {
        if (e == null) return;
        try { e.setEnabled(on); } catch (Exception ignored) { }
    }

    private void releaseEffects() {
        if (ns != null) { ns.release(); ns = null; }
        if (aec != null) { aec.release(); aec = null; }
        if (agc != null) { agc.release(); agc = null; }
    }

    private void fail(final String msg) {
        lastMessage = msg;
        main.post(new Runnable() {
            @Override public void run() { shutdown(); }
        });
    }

    private String phoneName() {
        try {
            String n = Settings.Global.getString(getContentResolver(), "device_name");
            if (n != null && !n.isEmpty()) return n;
        } catch (Exception ignored) { }
        String m = Build.MODEL;
        return m.toLowerCase().startsWith(Build.MANUFACTURER.toLowerCase()) ? m : Build.MANUFACTURER + " " + m;
    }

    // ------------------------------------------------------------------ StreamClient.Listener

    @Override
    public void onStateChanged(final StreamClient c) {
        main.post(new Runnable() {
            @Override public void run() {
                if (c != client) return;
                if (c.getState() == StreamClient.KICKED) {
                    lastMessage = c.getProblem();
                    shutdown();
                } else {
                    updateNotification();
                }
            }
        });
    }

    // ------------------------------------------------------------------ locks & notification

    private boolean locksHeld;

    private void acquireLocks() {
        if (locksHeld) releaseLocks();
        locksHeld = true;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PhoneMic:stream");
                wakeLock.setReferenceCounted(false);
            }
            wakeLock.acquire();
        } catch (Exception ignored) { }
        if (!Prefs.wifiLowLatency(Prefs.get(this))) return;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (Build.VERSION.SDK_INT >= 29) {
                wifiLockLL = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "PhoneMic:ll");
                wifiLockLL.setReferenceCounted(false);
                wifiLockLL.acquire();
            }
            @SuppressWarnings("deprecation")
            WifiManager.WifiLock hp = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "PhoneMic:hp");
            wifiLockHP = hp;
            wifiLockHP.setReferenceCounted(false);
            wifiLockHP.acquire();
        } catch (Exception ignored) { }
    }

    private void releaseLocks() {
        locksHeld = false;
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        try { if (wifiLockLL != null && wifiLockLL.isHeld()) wifiLockLL.release(); } catch (Exception ignored) { }
        try { if (wifiLockHP != null && wifiLockHP.isHeld()) wifiLockHP.release(); } catch (Exception ignored) { }
        wifiLockLL = null;
        wifiLockHP = null;
    }

    private boolean goForeground() {
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NOTIF_ID, n);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void updateNotification() {
        if (instance != this) return;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, buildNotification());
        } catch (Exception ignored) { }
    }

    private PendingIntent servicePI(String action, int code) {
        Intent i = new Intent(this, MicService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Microphone streaming", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        StreamClient c = client;
        String title, text;
        int st = c == null ? StreamClient.CONNECTING : c.getState();
        if (st == StreamClient.LIVE) {
            title = muted ? "Muted" : "Live - your PC is hearing you";
            text = "Streaming to " + c.getPcName();
        } else if (st == StreamClient.RECONNECTING) {
            title = "Reconnecting...";
            text = targetName;
        } else {
            title = "Connecting...";
            text = targetName;
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPI = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat_mic);
        b.setSmallIcon(R.drawable.ic_stat_mic)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setColor(0xFF3DDC97)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openPI)
                .addAction(new Notification.Action.Builder(icon, muted ? "Unmute" : "Mute", servicePI(ACTION_MUTE, 1)).build())
                .addAction(new Notification.Action.Builder(icon, "Stop", servicePI(ACTION_STOP, 2)).build());
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }
}
