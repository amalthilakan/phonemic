package app.phonemic.mic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** The big round start/stop button with a live level ring. */
public class MicButton extends View {
    static final int ACCENT = 0xFF3DDC97, PANEL = 0xFF171A21, LINE = 0xFF2A303B, INK = 0xFF062A1B, MUTED = 0xFF5A6270;

    private boolean live, muted, connecting;
    private float level, shown;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float spin;

    public MicButton(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        glyph.setStrokeCap(Paint.Cap.ROUND);
        setClickable(true);
        setFocusable(true);
        setContentDescription("Start or stop the microphone");
    }

    public void setState(boolean live, boolean connecting, boolean muted, float level) {
        this.live = live;
        this.connecting = connecting;
        this.muted = muted;
        this.level = level;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = h / 2, max = Math.min(w, h) / 2, rad = max * 0.74f;
        shown = Math.max(level, shown * 0.85f);

        if (live && !muted && shown > 0.01f) {
            fill.setColor(ACCENT);
            fill.setAlpha(50);
            c.drawCircle(cx, cy, rad + (max - rad) * Math.min(1f, shown), fill);
        }
        fill.setAlpha(255);
        fill.setColor(live ? (muted ? MUTED : ACCENT) : PANEL);
        c.drawCircle(cx, cy, rad, fill);
        if (!live) {
            stroke.setColor(LINE);
            stroke.setStrokeWidth(max * 0.025f);
            c.drawCircle(cx, cy, rad, stroke);
        }
        if (connecting) {
            stroke.setColor(ACCENT);
            stroke.setStrokeWidth(max * 0.035f);
            r.set(cx - rad, cy - rad, cx + rad, cy + rad);
            spin = (spin + 9) % 360;
            c.drawArc(r, spin, 80, false, stroke);
            postInvalidateOnAnimation();
        }

        int gc = live && !muted ? INK : 0xFFE8EAF0;
        glyph.setColor(gc);
        glyph.setStyle(Paint.Style.FILL);
        float s = rad;
        r.set(cx - s * 0.17f, cy - s * 0.50f, cx + s * 0.17f, cy + s * 0.10f);
        c.drawRoundRect(r, s * 0.17f, s * 0.17f, glyph);
        glyph.setStyle(Paint.Style.STROKE);
        glyph.setStrokeWidth(s * 0.07f);
        r.set(cx - s * 0.32f, cy - s * 0.42f, cx + s * 0.32f, cy + s * 0.24f);
        c.drawArc(r, 0, 180, false, glyph);
        c.drawLine(cx, cy + s * 0.24f, cx, cy + s * 0.44f, glyph);
        c.drawLine(cx - s * 0.18f, cy + s * 0.44f, cx + s * 0.18f, cy + s * 0.44f, glyph);
        if (muted) {
            glyph.setColor(0xFFFF5D5D);
            c.drawLine(cx - s * 0.42f, cy - s * 0.52f, cx + s * 0.42f, cy + s * 0.52f, glyph);
        }
        if (live && shown > 0.01f) postInvalidateOnAnimation();
    }
}
