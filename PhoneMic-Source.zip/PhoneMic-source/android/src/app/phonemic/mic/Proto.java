package app.phonemic.mic;

/** Wire protocol shared with PhoneMic.exe (see udp.go on the PC side). Little-endian. */
final class Proto {
    private Proto() {}

    static final int DEFAULT_PORT = 8444;

    static final int DISCOVER = 1, OFFER = 2, HELLO = 3, WELCOME = 4, AUDIO = 5,
            PING = 6, KICK = 7, PONG = 8, BYE = 9, REHELLO = 10;

    static int header(byte[] b, int type) {
        b[0] = 'P'; b[1] = 'M'; b[2] = 'I'; b[3] = 'C'; b[4] = (byte) type;
        return 5;
    }

    static boolean valid(byte[] b, int len) {
        return len >= 5 && b[0] == 'P' && b[1] == 'M' && b[2] == 'I' && b[3] == 'C';
    }

    static void putInt(byte[] b, int off, int v) {
        b[off] = (byte) v; b[off + 1] = (byte) (v >> 8); b[off + 2] = (byte) (v >> 16); b[off + 3] = (byte) (v >> 24);
    }

    static int getInt(byte[] b, int off) {
        return (b[off] & 0xFF) | (b[off + 1] & 0xFF) << 8 | (b[off + 2] & 0xFF) << 16 | (b[off + 3] & 0xFF) << 24;
    }

    static void putLong(byte[] b, int off, long v) {
        for (int i = 0; i < 8; i++) b[off + i] = (byte) (v >> (8 * i));
    }

    static long getLong(byte[] b, int off) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[off + i] & 0xFFL);
        return v;
    }

    // ---- tiny JSON helpers (flat objects only) ----

    static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') sb.append('\\').append(c);
            else if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
            else sb.append(c);
        }
        return sb.append('"').toString();
    }

    /** Raw value text for key (string values are unescaped), or null. */
    static String json(String obj, String key) {
        String k = "\"" + key + "\"";
        int i = obj.indexOf(k);
        if (i < 0) return null;
        i = obj.indexOf(':', i + k.length());
        if (i < 0) return null;
        i++;
        while (i < obj.length() && Character.isWhitespace(obj.charAt(i))) i++;
        if (i >= obj.length()) return null;
        if (obj.charAt(i) == '"') {
            StringBuilder sb = new StringBuilder();
            for (i++; i < obj.length(); i++) {
                char c = obj.charAt(i);
                if (c == '"') return sb.toString();
                if (c == '\\' && i + 1 < obj.length()) {
                    char n = obj.charAt(++i);
                    if (n == 'u' && i + 4 < obj.length()) {
                        sb.append((char) Integer.parseInt(obj.substring(i + 1, i + 5), 16));
                        i += 4;
                    } else if (n == 'n') sb.append('\n');
                    else if (n == 't') sb.append('\t');
                    else sb.append(n);
                } else sb.append(c);
            }
            return sb.toString();
        }
        int j = i;
        while (j < obj.length() && ",}] \n\r\t".indexOf(obj.charAt(j)) < 0) j++;
        return obj.substring(i, j);
    }

    static int jsonInt(String obj, String key, int def) {
        try {
            String v = json(obj, key);
            return v == null ? def : (int) Double.parseDouble(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static String jsonStr(String obj, String key, String def) {
        String v = json(obj, key);
        return v == null ? def : v;
    }
}
